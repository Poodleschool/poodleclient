/*    */ package ladysnake.satin;
/*    */ 
/*    */ import ladysnake.satin.api.event.ResolutionChangeCallback;
/*    */ import ladysnake.satin.impl.ReloadableShaderEffectManager;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.apiguardian.api.API;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Satin
/*    */   implements ClientModInitializer
/*    */ {
/*    */   public static final String MOD_ID = "satin";
/* 32 */   public static final Logger LOGGER = LogManager.getLogger("Satin");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @API(status = API.Status.STABLE)
/*    */   public static boolean areShadersDisabled() {
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onInitializeClient() {
/* 46 */     ResolutionChangeCallback.EVENT.register(ReloadableShaderEffectManager.INSTANCE);
/* 47 */     if (FabricLoader.getInstance().isModLoaded("optifabric"))
/* 48 */       LOGGER.warn("[Satin] Optifine present in the instance, custom entity post process shaders will not work"); 
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/Satin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */