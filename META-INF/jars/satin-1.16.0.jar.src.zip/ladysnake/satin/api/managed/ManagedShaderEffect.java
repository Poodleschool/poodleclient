package ladysnake.satin.api.managed;

import java.io.IOException;
import javax.annotation.Nullable;
import ladysnake.satin.api.managed.uniform.SamplerUniform;
import ladysnake.satin.api.managed.uniform.SamplerUniformV2;
import ladysnake.satin.api.managed.uniform.UniformFinder;
import net.minecraft.class_1044;
import net.minecraft.class_276;
import net.minecraft.class_279;
import org.apiguardian.api.API;
import org.joml.Matrix4f;

public interface ManagedShaderEffect extends UniformFinder {
  @Nullable
  @API(status = API.Status.MAINTAINED, since = "1.0.0")
  class_279 getShaderEffect();
  
  @API(status = API.Status.MAINTAINED, since = "1.0.0")
  void initialize() throws IOException;
  
  @API(status = API.Status.MAINTAINED, since = "1.0.0")
  boolean isInitialized();
  
  @API(status = API.Status.MAINTAINED, since = "1.0.0")
  boolean isErrored();
  
  @API(status = API.Status.EXPERIMENTAL, since = "1.0.0")
  void release();
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void render(float paramFloat);
  
  @API(status = API.Status.EXPERIMENTAL, since = "1.4.0")
  ManagedFramebuffer getTarget(String paramString);
  
  @API(status = API.Status.EXPERIMENTAL, since = "1.0.0")
  void setupDynamicUniforms(Runnable paramRunnable);
  
  @API(status = API.Status.EXPERIMENTAL, since = "1.0.0")
  void setupDynamicUniforms(int paramInt, Runnable paramRunnable);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setUniformValue(String paramString, int paramInt);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setUniformValue(String paramString, int paramInt1, int paramInt2);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setUniformValue(String paramString, int paramInt1, int paramInt2, int paramInt3);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setUniformValue(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setUniformValue(String paramString, float paramFloat);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setUniformValue(String paramString, float paramFloat1, float paramFloat2);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setUniformValue(String paramString, float paramFloat1, float paramFloat2, float paramFloat3);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setUniformValue(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setUniformValue(String paramString, Matrix4f paramMatrix4f);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setSamplerUniform(String paramString, class_1044 paramclass_1044);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setSamplerUniform(String paramString, class_276 paramclass_276);
  
  @API(status = API.Status.STABLE, since = "1.0.0")
  void setSamplerUniform(String paramString, int paramInt);
  
  SamplerUniformV2 findSampler(String paramString);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/ManagedShaderEffect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */