package ladysnake.satin.api.managed.uniform;

import org.apiguardian.api.API;
import org.joml.Matrix4f;

public interface UniformMat4 {
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  void set(Matrix4f paramMatrix4f);
  
  @API(status = API.Status.MAINTAINED, since = "1.15.0")
  void setFromArray(float[] paramArrayOffloat);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/uniform/UniformMat4.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */