package ladysnake.satin.api.managed.uniform;

import java.util.function.IntSupplier;
import org.apiguardian.api.API;

public interface SamplerUniformV2 extends SamplerUniform {
  @API(status = API.Status.EXPERIMENTAL, since = "1.4.0")
  void set(IntSupplier paramIntSupplier);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/uniform/SamplerUniformV2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */