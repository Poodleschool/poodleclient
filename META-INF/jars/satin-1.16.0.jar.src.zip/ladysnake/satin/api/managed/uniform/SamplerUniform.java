package ladysnake.satin.api.managed.uniform;

import net.minecraft.class_1044;
import net.minecraft.class_276;
import org.apiguardian.api.API;

@API(status = API.Status.MAINTAINED)
public interface SamplerUniform {
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  void setDirect(int paramInt);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  void set(class_1044 paramclass_1044);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  void set(class_276 paramclass_276);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  void set(int paramInt);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/uniform/SamplerUniform.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */