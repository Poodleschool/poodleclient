package ladysnake.satin.api.managed.uniform;

import org.apiguardian.api.API;
import org.joml.Vector3f;

public interface Uniform3f {
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  void set(float paramFloat1, float paramFloat2, float paramFloat3);
  
  @API(status = API.Status.MAINTAINED, since = "1.12.0")
  void set(Vector3f paramVector3f);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/uniform/Uniform3f.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */