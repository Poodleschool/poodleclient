package ladysnake.satin.api.managed.uniform;

import org.apiguardian.api.API;
import org.joml.Vector2f;

public interface Uniform2f {
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  void set(float paramFloat1, float paramFloat2);
  
  @API(status = API.Status.MAINTAINED, since = "1.11.0")
  void set(Vector2f paramVector2f);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/uniform/Uniform2f.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */