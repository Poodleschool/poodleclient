package ladysnake.satin.api.managed.uniform;

import org.apiguardian.api.API;
import org.joml.Vector4f;

public interface Uniform4f {
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  void set(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  @API(status = API.Status.MAINTAINED, since = "1.12.0")
  void set(Vector4f paramVector4f);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/uniform/Uniform4f.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */