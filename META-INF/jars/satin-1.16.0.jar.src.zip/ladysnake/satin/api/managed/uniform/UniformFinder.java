package ladysnake.satin.api.managed.uniform;

import org.apiguardian.api.API;

public interface UniformFinder {
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  Uniform1i findUniform1i(String paramString);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  Uniform2i findUniform2i(String paramString);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  Uniform3i findUniform3i(String paramString);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  Uniform4i findUniform4i(String paramString);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  Uniform1f findUniform1f(String paramString);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  Uniform2f findUniform2f(String paramString);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  Uniform3f findUniform3f(String paramString);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  Uniform4f findUniform4f(String paramString);
  
  @API(status = API.Status.MAINTAINED, since = "1.4.0")
  UniformMat4 findUniformMat4(String paramString);
  
  @API(status = API.Status.EXPERIMENTAL, since = "1.4.0")
  SamplerUniform findSampler(String paramString);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/uniform/UniformFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */