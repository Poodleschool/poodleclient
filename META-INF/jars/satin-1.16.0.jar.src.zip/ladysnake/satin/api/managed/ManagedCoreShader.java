package ladysnake.satin.api.managed;

import ladysnake.satin.api.managed.uniform.UniformFinder;
import net.minecraft.class_1921;
import net.minecraft.class_5944;
import org.apiguardian.api.API;

@API(status = API.Status.EXPERIMENTAL, since = "1.6.0")
public interface ManagedCoreShader extends UniformFinder {
  class_5944 getProgram();
  
  void release();
  
  class_1921 getRenderLayer(class_1921 paramclass_1921);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/ManagedCoreShader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */