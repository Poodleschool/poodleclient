package ladysnake.satin.api.managed;

import javax.annotation.Nullable;
import net.minecraft.class_1921;
import net.minecraft.class_276;
import org.apiguardian.api.API;

@API(status = API.Status.EXPERIMENTAL, since = "1.4.0")
public interface ManagedFramebuffer {
  @Nullable
  class_276 getFramebuffer();
  
  void beginWrite(boolean paramBoolean);
  
  void copyDepthFrom(class_276 paramclass_276);
  
  void draw();
  
  void draw(int paramInt1, int paramInt2, boolean paramBoolean);
  
  void clear();
  
  void clear(boolean paramBoolean);
  
  class_1921 getRenderLayer(class_1921 paramclass_1921);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/ManagedFramebuffer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */