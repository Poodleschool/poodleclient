/*    */ package ladysnake.satin.api.managed;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import ladysnake.satin.impl.ReloadableShaderEffectManager;
/*    */ import net.minecraft.class_290;
/*    */ import net.minecraft.class_293;
/*    */ import net.minecraft.class_2960;
/*    */ import org.apiguardian.api.API;
/*    */ import org.jetbrains.annotations.ApiStatus.ScheduledForRemoval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ShaderEffectManager
/*    */ {
/*    */   @API(status = API.Status.STABLE)
/*    */   static ShaderEffectManager getInstance() {
/* 39 */     return (ShaderEffectManager)ReloadableShaderEffectManager.INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @API(status = API.Status.STABLE, since = "1.0.0")
/*    */   ManagedShaderEffect manage(class_2960 paramclass_2960);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @API(status = API.Status.STABLE, since = "1.0.0")
/*    */   ManagedShaderEffect manage(class_2960 paramclass_2960, Consumer<ManagedShaderEffect> paramConsumer);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(since = "1.6.0", forRemoval = true)
/*    */   @ScheduledForRemoval
/*    */   default ManagedCoreShader manageProgram(class_2960 location) {
/* 68 */     return manageCoreShader(location);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated(since = "1.6.0", forRemoval = true)
/*    */   @ScheduledForRemoval
/*    */   default ManagedCoreShader manageProgram(class_2960 location, Consumer<ManagedCoreShader> initCallback) {
/* 78 */     return manageCoreShader(location, class_290.field_1580, initCallback);
/*    */   }
/*    */   
/*    */   @API(status = API.Status.EXPERIMENTAL, since = "1.6.0")
/*    */   ManagedCoreShader manageCoreShader(class_2960 paramclass_2960);
/*    */   
/*    */   @API(status = API.Status.EXPERIMENTAL, since = "1.6.0")
/*    */   ManagedCoreShader manageCoreShader(class_2960 paramclass_2960, class_293 paramclass_293);
/*    */   
/*    */   @API(status = API.Status.EXPERIMENTAL, since = "1.6.0")
/*    */   ManagedCoreShader manageCoreShader(class_2960 paramclass_2960, class_293 paramclass_293, Consumer<ManagedCoreShader> paramConsumer);
/*    */   
/*    */   @API(status = API.Status.STABLE, since = "1.0.0")
/*    */   void dispose(ManagedShaderEffect paramManagedShaderEffect);
/*    */   
/*    */   @API(status = API.Status.EXPERIMENTAL, since = "1.4.0")
/*    */   void dispose(ManagedCoreShader paramManagedCoreShader);
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/managed/ShaderEffectManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */