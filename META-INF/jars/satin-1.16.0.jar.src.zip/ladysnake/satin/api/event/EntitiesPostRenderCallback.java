/*    */ package ladysnake.satin.api.event;
/*    */ 
/*    */ import net.fabricmc.fabric.api.event.Event;
/*    */ import net.fabricmc.fabric.api.event.EventFactory;
/*    */ import net.minecraft.class_4184;
/*    */ import net.minecraft.class_4604;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface EntitiesPostRenderCallback
/*    */ {
/* 30 */   public static final Event<EntitiesPostRenderCallback> EVENT = EventFactory.createArrayBacked(EntitiesPostRenderCallback.class, listeners -> ());
/*    */   
/*    */   void onEntitiesRendered(class_4184 paramclass_4184, class_4604 paramclass_4604, float paramFloat);
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/event/EntitiesPostRenderCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */