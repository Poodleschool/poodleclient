/*    */ package ladysnake.satin.api.event;
/*    */ 
/*    */ import net.fabricmc.fabric.api.event.Event;
/*    */ import net.fabricmc.fabric.api.event.EventFactory;
/*    */ import net.minecraft.class_4184;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface PostWorldRenderCallbackV2
/*    */ {
/* 30 */   public static final Event<PostWorldRenderCallbackV2> EVENT = EventFactory.createArrayBacked(PostWorldRenderCallbackV2.class, listeners -> ());
/*    */   
/*    */   void onWorldRendered(class_4587 paramclass_4587, class_4184 paramclass_4184, float paramFloat, long paramLong);
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/event/PostWorldRenderCallbackV2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */