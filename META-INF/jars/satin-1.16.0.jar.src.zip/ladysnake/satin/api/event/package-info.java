package ladysnake.satin.api.event;

import javax.annotation.ParametersAreNonnullByDefault;



/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/event/package-info.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */