/*    */ package ladysnake.satin.api.event;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ import javax.annotation.Nullable;
/*    */ import net.fabricmc.fabric.api.event.Event;
/*    */ import net.fabricmc.fabric.api.event.EventFactory;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_279;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PickEntityShaderCallback
/*    */ {
/* 34 */   public static final Event<PickEntityShaderCallback> EVENT = EventFactory.createArrayBacked(PickEntityShaderCallback.class, listeners -> ());
/*    */   
/*    */   void pickEntityShader(@Nullable class_1297 paramclass_1297, Consumer<class_2960> paramConsumer, Supplier<class_279> paramSupplier);
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/event/PickEntityShaderCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */