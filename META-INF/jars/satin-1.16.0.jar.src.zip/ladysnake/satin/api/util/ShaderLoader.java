/*    */ package ladysnake.satin.api.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.annotation.Nullable;
/*    */ import ladysnake.satin.impl.ValidatingShaderLoader;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_3300;
/*    */ import org.apiguardian.api.API;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ShaderLoader
/*    */ {
/*    */   @API(status = API.Status.MAINTAINED)
/*    */   static ShaderLoader getInstance() {
/* 38 */     return ValidatingShaderLoader.INSTANCE;
/*    */   }
/*    */   
/*    */   @API(status = API.Status.MAINTAINED)
/*    */   int loadShader(class_3300 paramclass_3300, @Nullable class_2960 paramclass_29601, @Nullable class_2960 paramclass_29602) throws IOException;
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/util/ShaderLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */