/*    */ package ladysnake.satin.api.util;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import ladysnake.satin.impl.BlockRenderLayerRegistry;
/*    */ import ladysnake.satin.impl.RenderLayerDuplicator;
/*    */ import ladysnake.satin.mixin.client.render.RenderPhaseAccessor;
/*    */ import net.minecraft.class_1921;
/*    */ import net.minecraft.class_4668;
/*    */ import org.apiguardian.api.API;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @API(status = API.Status.EXPERIMENTAL, since = "1.4.0")
/*    */ public final class RenderLayerHelper
/*    */ {
/*    */   @API(status = API.Status.EXPERIMENTAL, since = "1.5.0")
/*    */   public static String getName(class_4668 phase) {
/* 46 */     return ((RenderPhaseAccessor)phase).getName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @API(status = API.Status.EXPERIMENTAL, since = "1.4.0")
/*    */   public static class_1921 copy(class_1921 existing, String newName, Consumer<class_1921.class_4688.class_4689> phaseTransform) {
/* 69 */     return RenderLayerDuplicator.copy(existing, newName, phaseTransform);
/*    */   }
/*    */   
/*    */   @API(status = API.Status.EXPERIMENTAL, since = "1.4.0")
/*    */   public static class_1921.class_4688 copyPhaseParameters(class_1921 existing, Consumer<class_1921.class_4688.class_4689> phaseTransform) {
/* 74 */     return RenderLayerDuplicator.copyPhaseParameters(existing, phaseTransform);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   @API(status = API.Status.EXPERIMENTAL, since = "1.5.0")
/*    */   public static void registerBlockRenderLayer(class_1921 layer) {
/* 90 */     BlockRenderLayerRegistry.INSTANCE.registerRenderLayer(layer);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/util/RenderLayerHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */