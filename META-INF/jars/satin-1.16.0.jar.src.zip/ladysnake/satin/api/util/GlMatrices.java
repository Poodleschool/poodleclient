/*     */ package ladysnake.satin.api.util;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.util.Arrays;
/*     */ import javax.annotation.Nonnull;
/*     */ import org.apiguardian.api.API;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fc;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GlMatrices
/*     */ {
/*  38 */   private static final FloatBuffer buffer = BufferUtils.createFloatBuffer(16);
/*  39 */   private static final float[] inArray = new float[16];
/*  40 */   private static final float[] outArray = new float[16];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static FloatBuffer getTmpBuffer() {
/*  50 */     Buffer buffer = GlMatrices.buffer;
/*  51 */     buffer.clear();
/*  52 */     return GlMatrices.buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static FloatBuffer getProjectionMatrix(FloatBuffer outMat) {
/*  61 */     GL11.glGetFloatv(2983, outMat);
/*     */     
/*  63 */     Buffer buffer = outMat;
/*  64 */     buffer.rewind();
/*  65 */     return outMat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static FloatBuffer getProjectionMatrixInverse(FloatBuffer outMat) {
/*  74 */     getProjectionMatrix(outMat);
/*  75 */     invertMat4FB(outMat, outMat);
/*  76 */     return outMat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static FloatBuffer getModelViewMatrix(FloatBuffer outMat) {
/*  88 */     GL11.glGetFloatv(2982, outMat);
/*     */     
/*  90 */     Buffer buffer = outMat;
/*  91 */     buffer.rewind();
/*  92 */     return outMat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static FloatBuffer getModelViewMatrixInverse(FloatBuffer outMat) {
/* 101 */     getModelViewMatrix(outMat);
/* 102 */     invertMat4FB(outMat, outMat);
/* 103 */     return outMat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nonnull
/*     */   @API(status = API.Status.EXPERIMENTAL)
/*     */   public static Matrix4f getInverseTransformMatrix(Matrix4f outMat) {
/* 116 */     Matrix4f projection = RenderSystem.getProjectionMatrix();
/* 117 */     Matrix4f modelView = RenderSystem.getModelViewMatrix();
/* 118 */     outMat.identity();
/* 119 */     outMat.mul((Matrix4fc)projection);
/* 120 */     outMat.mul((Matrix4fc)modelView);
/* 121 */     outMat.invert();
/* 122 */     return outMat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @API(status = API.Status.DEPRECATED)
/*     */   public static FloatBuffer getProjectionMatrix() {
/* 131 */     return getProjectionMatrix(getTmpBuffer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @API(status = API.Status.DEPRECATED)
/*     */   public static FloatBuffer getProjectionMatrixInverse() {
/* 140 */     return getProjectionMatrixInverse(getTmpBuffer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @API(status = API.Status.DEPRECATED)
/*     */   public static FloatBuffer getModelViewMatrix() {
/* 149 */     return getModelViewMatrix(getTmpBuffer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @API(status = API.Status.DEPRECATED)
/*     */   public static FloatBuffer getModelViewMatrixInverse() {
/* 158 */     return getModelViewMatrixInverse(getTmpBuffer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static void invertMat4(float[] matOut, float[] m) {
/* 172 */     float m00 = m[5] * m[10] * m[15] - m[5] * m[11] * m[14] - m[9] * m[6] * m[15] + m[9] * m[7] * m[14] + m[13] * m[6] * m[11] - m[13] * m[7] * m[10];
/* 173 */     float m01 = -m[1] * m[10] * m[15] + m[1] * m[11] * m[14] + m[9] * m[2] * m[15] - m[9] * m[3] * m[14] - m[13] * m[2] * m[11] + m[13] * m[3] * m[10];
/* 174 */     float m02 = m[1] * m[6] * m[15] - m[1] * m[7] * m[14] - m[5] * m[2] * m[15] + m[5] * m[3] * m[14] + m[13] * m[2] * m[7] - m[13] * m[3] * m[6];
/* 175 */     float m03 = -m[1] * m[6] * m[11] + m[1] * m[7] * m[10] + m[5] * m[2] * m[11] - m[5] * m[3] * m[10] - m[9] * m[2] * m[7] + m[9] * m[3] * m[6];
/* 176 */     float m10 = -m[4] * m[10] * m[15] + m[4] * m[11] * m[14] + m[8] * m[6] * m[15] - m[8] * m[7] * m[14] - m[12] * m[6] * m[11] + m[12] * m[7] * m[10];
/* 177 */     float m11 = m[0] * m[10] * m[15] - m[0] * m[11] * m[14] - m[8] * m[2] * m[15] + m[8] * m[3] * m[14] + m[12] * m[2] * m[11] - m[12] * m[3] * m[10];
/* 178 */     float m12 = -m[0] * m[6] * m[15] + m[0] * m[7] * m[14] + m[4] * m[2] * m[15] - m[4] * m[3] * m[14] - m[12] * m[2] * m[7] + m[12] * m[3] * m[6];
/* 179 */     float m13 = m[0] * m[6] * m[11] - m[0] * m[7] * m[10] - m[4] * m[2] * m[11] + m[4] * m[3] * m[10] + m[8] * m[2] * m[7] - m[8] * m[3] * m[6];
/* 180 */     float m20 = m[4] * m[9] * m[15] - m[4] * m[11] * m[13] - m[8] * m[5] * m[15] + m[8] * m[7] * m[13] + m[12] * m[5] * m[11] - m[12] * m[7] * m[9];
/* 181 */     float m21 = -m[0] * m[9] * m[15] + m[0] * m[11] * m[13] + m[8] * m[1] * m[15] - m[8] * m[3] * m[13] - m[12] * m[1] * m[11] + m[12] * m[3] * m[9];
/* 182 */     float m22 = m[0] * m[5] * m[15] - m[0] * m[7] * m[13] - m[4] * m[1] * m[15] + m[4] * m[3] * m[13] + m[12] * m[1] * m[7] - m[12] * m[3] * m[5];
/* 183 */     float m23 = -m[0] * m[5] * m[11] + m[0] * m[7] * m[9] + m[4] * m[1] * m[11] - m[4] * m[3] * m[9] - m[8] * m[1] * m[7] + m[8] * m[3] * m[5];
/* 184 */     float m30 = -m[4] * m[9] * m[14] + m[4] * m[10] * m[13] + m[8] * m[5] * m[14] - m[8] * m[6] * m[13] - m[12] * m[5] * m[10] + m[12] * m[6] * m[9];
/* 185 */     float m31 = m[0] * m[9] * m[14] - m[0] * m[10] * m[13] - m[8] * m[1] * m[14] + m[8] * m[2] * m[13] + m[12] * m[1] * m[10] - m[12] * m[2] * m[9];
/* 186 */     float m32 = -m[0] * m[5] * m[14] + m[0] * m[6] * m[13] + m[4] * m[1] * m[14] - m[4] * m[2] * m[13] - m[12] * m[1] * m[6] + m[12] * m[2] * m[5];
/* 187 */     float m33 = m[0] * m[5] * m[10] - m[0] * m[6] * m[9] - m[4] * m[1] * m[10] + m[4] * m[2] * m[9] + m[8] * m[1] * m[6] - m[8] * m[2] * m[5];
/*     */     
/* 189 */     float det = m[0] * m00 + m[1] * m10 + m[2] * m20 + m[3] * m30;
/*     */     
/* 191 */     matOut[0] = m00;
/* 192 */     matOut[1] = m01;
/* 193 */     matOut[2] = m02;
/* 194 */     matOut[3] = m03;
/* 195 */     matOut[4] = m10;
/* 196 */     matOut[5] = m11;
/* 197 */     matOut[6] = m12;
/* 198 */     matOut[7] = m13;
/* 199 */     matOut[8] = m20;
/* 200 */     matOut[9] = m21;
/* 201 */     matOut[10] = m22;
/* 202 */     matOut[11] = m23;
/* 203 */     matOut[12] = m30;
/* 204 */     matOut[13] = m31;
/* 205 */     matOut[14] = m32;
/* 206 */     matOut[15] = m33;
/* 207 */     if (det != 0.0D) {
/* 208 */       for (int i = 0; i < 16; i++) {
/* 209 */         matOut[i] = matOut[i] / det;
/*     */       }
/*     */     } else {
/* 212 */       Arrays.fill(matOut, 0.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static void invertMat4FB(FloatBuffer fbInvOut, FloatBuffer fbMatIn) {
/* 227 */     invertMat4FBFA(fbInvOut, fbMatIn, outArray, inArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void invertMat4FBFA(FloatBuffer fbInvOut, FloatBuffer fbMatIn, float[] faInv, float[] faMat) {
/* 239 */     fbMatIn.get(faMat);
/* 240 */     invertMat4(faInv, faMat);
/* 241 */     fbInvOut.put(faInv);
/* 242 */     fbInvOut.rewind();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static float[] multiplyMat4(float[] dest, float[] left, float[] right) {
/* 257 */     float m00 = left[0] * right[0] + left[4] * right[1] + left[8] * right[2] + left[12] * right[3];
/* 258 */     float m01 = left[1] * right[0] + left[5] * right[1] + left[9] * right[2] + left[13] * right[3];
/* 259 */     float m02 = left[2] * right[0] + left[6] * right[1] + left[10] * right[2] + left[14] * right[3];
/* 260 */     float m03 = left[3] * right[0] + left[7] * right[1] + left[11] * right[2] + left[15] * right[3];
/* 261 */     float m10 = left[0] * right[4] + left[4] * right[5] + left[8] * right[6] + left[12] * right[7];
/* 262 */     float m11 = left[1] * right[4] + left[5] * right[5] + left[9] * right[6] + left[13] * right[7];
/* 263 */     float m12 = left[2] * right[4] + left[6] * right[5] + left[10] * right[6] + left[14] * right[7];
/* 264 */     float m13 = left[3] * right[4] + left[7] * right[5] + left[11] * right[6] + left[15] * right[7];
/* 265 */     float m20 = left[0] * right[8] + left[4] * right[9] + left[8] * right[10] + left[12] * right[11];
/* 266 */     float m21 = left[1] * right[8] + left[5] * right[9] + left[9] * right[10] + left[13] * right[11];
/* 267 */     float m22 = left[2] * right[8] + left[6] * right[9] + left[10] * right[10] + left[14] * right[11];
/* 268 */     float m23 = left[3] * right[8] + left[7] * right[9] + left[11] * right[10] + left[15] * right[11];
/* 269 */     float m30 = left[0] * right[12] + left[4] * right[13] + left[8] * right[14] + left[12] * right[15];
/* 270 */     float m31 = left[1] * right[12] + left[5] * right[13] + left[9] * right[14] + left[13] * right[15];
/* 271 */     float m32 = left[2] * right[12] + left[6] * right[13] + left[10] * right[14] + left[14] * right[15];
/* 272 */     float m33 = left[3] * right[12] + left[7] * right[13] + left[11] * right[14] + left[15] * right[15];
/*     */     
/* 274 */     dest[0] = m00;
/* 275 */     dest[1] = m01;
/* 276 */     dest[2] = m02;
/* 277 */     dest[3] = m03;
/* 278 */     dest[4] = m10;
/* 279 */     dest[5] = m11;
/* 280 */     dest[6] = m12;
/* 281 */     dest[7] = m13;
/* 282 */     dest[8] = m20;
/* 283 */     dest[9] = m21;
/* 284 */     dest[10] = m22;
/* 285 */     dest[11] = m23;
/* 286 */     dest[12] = m30;
/* 287 */     dest[13] = m31;
/* 288 */     dest[14] = m32;
/* 289 */     dest[15] = m33;
/*     */     
/* 291 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static void multiplyMat4FB(FloatBuffer fbInvOut, FloatBuffer fbMatLeft, FloatBuffer fbMatRight) {
/* 306 */     float[] matLeft = inArray;
/* 307 */     float[] matRight = outArray;
/* 308 */     fbMatLeft.get(matLeft);
/* 309 */     fbMatRight.get(matRight);
/* 310 */     multiplyMat4(matLeft, matLeft, matRight);
/* 311 */     fbInvOut.put(matLeft);
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/util/GlMatrices.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */