/*     */ package ladysnake.satin.api.util;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
/*     */ import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
/*     */ import it.unimi.dsi.fastutil.objects.Object2IntMap;
/*     */ import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
/*     */ import java.nio.FloatBuffer;
/*     */ import java.util.function.IntConsumer;
/*     */ import ladysnake.satin.Satin;
/*     */ import net.minecraft.class_284;
/*     */ import net.minecraft.class_285;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import org.apiguardian.api.API;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ShaderPrograms
/*     */ {
/*  48 */   private static final Int2ObjectMap<Object2IntMap<String>> uniformsCache = (Int2ObjectMap<Object2IntMap<String>>)new Int2ObjectOpenHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static void useShader(int program) {
/*  61 */     if (Satin.areShadersDisabled()) {
/*     */       return;
/*     */     }
/*     */     
/*  65 */     class_285.method_22094(program);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.EXPERIMENTAL)
/*     */   public static void setAttribValue(int program, String attribName, IntConsumer operation) {
/*  80 */     if (Satin.areShadersDisabled() || program == 0) {
/*     */       return;
/*     */     }
/*     */     
/*  84 */     int attrib = class_284.method_22097(program, attribName);
/*  85 */     if (attrib != -1) {
/*  86 */       operation.accept(attrib);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.EXPERIMENTAL)
/*     */   public static void setUniformValue(int program, String uniformName, IntConsumer operation) {
/* 102 */     if (Satin.areShadersDisabled() || program == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 106 */     int uniform = getUniformLocation(program, uniformName);
/* 107 */     if (uniform != -1) {
/* 108 */       operation.accept(uniform);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.STABLE)
/*     */   public static void setUniform(int program, String uniformName, int value) {
/* 121 */     if (Satin.areShadersDisabled() || program == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 125 */     int uniform = getUniformLocation(program, uniformName);
/* 126 */     if (uniform != -1) {
/* 127 */       GL20.glUniform1i(uniform, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.EXPERIMENTAL)
/*     */   public static void setUniform(int program, String uniformName, float value) {
/* 140 */     if (Satin.areShadersDisabled() || program == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 144 */     int uniform = getUniformLocation(program, uniformName);
/* 145 */     if (uniform != -1) {
/* 146 */       GL20.glUniform1f(uniform, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.EXPERIMENTAL)
/*     */   public static void setUniform(int program, String uniformName, FloatBuffer mat4) {
/* 159 */     if (Satin.areShadersDisabled() || program == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 163 */     int uniform = getUniformLocation(program, uniformName);
/* 164 */     if (uniform != -1) {
/* 165 */       GL20.glUniformMatrix4fv(uniform, false, mat4);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.MAINTAINED)
/*     */   public static int getUniformLocation(int program, String uniformName) {
/*     */     Object2IntOpenHashMap object2IntOpenHashMap;
/*     */     int uniform;
/* 193 */     Object2IntMap<String> shaderUniformsCache = (Object2IntMap<String>)uniformsCache.get(program);
/*     */     
/* 195 */     if (shaderUniformsCache == null) {
/* 196 */       object2IntOpenHashMap = new Object2IntOpenHashMap();
/* 197 */       uniformsCache.put(program, object2IntOpenHashMap);
/*     */     } 
/*     */ 
/*     */     
/* 201 */     if (object2IntOpenHashMap.containsKey(uniformName)) {
/* 202 */       uniform = object2IntOpenHashMap.getInt(uniformName);
/*     */     } else {
/*     */       
/* 205 */       uniform = class_284.method_22096(program, uniformName);
/* 206 */       object2IntOpenHashMap.put(uniformName, uniform);
/*     */     } 
/* 208 */     return uniform;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.EXPERIMENTAL)
/*     */   public static void bindAdditionalTextures(int program, class_2960... textures) {
/* 229 */     for (int i = 0; i < textures.length; i++) {
/* 230 */       class_2960 texture = textures[i];
/*     */       
/* 232 */       RenderSystem.activeTexture(i + 33986);
/* 233 */       class_310.method_1551().method_1531().method_22813(texture);
/*     */       
/* 235 */       setUniform(program, "texture" + i + 1, i + 2);
/*     */     } 
/* 237 */     RenderSystem.activeTexture(33984);
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/api/util/ShaderPrograms.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */