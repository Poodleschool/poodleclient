/*    */ package ladysnake.satin.mixin;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import net.fabricmc.loader.api.FabricLoader;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ import org.objectweb.asm.tree.ClassNode;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
/*    */ import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SatinMixinPlugin
/*    */   implements IMixinConfigPlugin
/*    */ {
/* 31 */   private static final Logger LOGGER = LogManager.getLogger("Satin");
/*    */   private static final boolean ALLOW_RENDER_LAYER_MIXINS;
/*    */   
/*    */   static {
/* 35 */     FabricLoader loader = FabricLoader.getInstance();
/* 36 */     if (loader.isModLoaded("canvas")) {
/* 37 */       LOGGER.warn("[Satin] Canvas is present, custom block renders will not work");
/* 38 */       ALLOW_RENDER_LAYER_MIXINS = false;
/* 39 */     } else if (loader.isModLoaded("iris")) {
/* 40 */       LOGGER.warn("[Satin] Iris is present, custom block renders will not work");
/* 41 */       ALLOW_RENDER_LAYER_MIXINS = false;
/*    */     } else {
/* 43 */       if (loader.isModLoaded("sodium")) {
/* 44 */         LOGGER.warn("[Satin] Sodium is present, custom block renders may not work");
/*    */       }
/* 46 */       ALLOW_RENDER_LAYER_MIXINS = true;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onLoad(String mixinPackage) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public String getRefMapperConfig() {
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
/* 62 */     if (mixinClassName.contains("blockrenderlayer")) {
/* 63 */       return ALLOW_RENDER_LAYER_MIXINS;
/*    */     }
/* 65 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getMixins() {
/* 75 */     return List.of();
/*    */   }
/*    */   
/*    */   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */   
/*    */   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/SatinMixinPlugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */