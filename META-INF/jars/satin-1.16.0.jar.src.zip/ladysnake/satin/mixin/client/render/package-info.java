package ladysnake.satin.mixin.client.render;

import javax.annotation.ParametersAreNonnullByDefault;
import org.jetbrains.annotations.ApiStatus.Internal;



/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/render/package-info.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */