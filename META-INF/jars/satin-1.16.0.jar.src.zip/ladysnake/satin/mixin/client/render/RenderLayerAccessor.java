/*    */ package ladysnake.satin.mixin.client.render;
/*    */ 
/*    */ import net.minecraft.class_1921;
/*    */ import net.minecraft.class_293;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.gen.Accessor;
/*    */ import org.spongepowered.asm.mixin.gen.Invoker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1921.class})
/*    */ public interface RenderLayerAccessor
/*    */ {
/*    */   @Accessor
/*    */   boolean isTranslucent();
/*    */   
/*    */   @Invoker("of")
/*    */   static class_1921.class_4687 satin$of(String name, class_293 vertexFormat, class_293.class_5596 drawMode, int expectedBufferSize, boolean hasCrumbling, boolean translucent, class_1921.class_4688 phases) {
/* 33 */     throw new IllegalStateException("Mixin not transformed");
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/render/RenderLayerAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */