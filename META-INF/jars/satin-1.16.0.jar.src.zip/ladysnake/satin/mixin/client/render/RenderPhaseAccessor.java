package ladysnake.satin.mixin.client.render;

import net.minecraft.class_4668;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_4668.class})
public interface RenderPhaseAccessor {
  @Accessor
  String getName();
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/render/RenderPhaseAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */