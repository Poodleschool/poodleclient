/*    */ package ladysnake.satin.mixin.client.gl;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import ladysnake.satin.impl.SamplerAccess;
/*    */ import net.minecraft.class_5944;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.gen.Accessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_5944.class})
/*    */ public abstract class CoreShaderMixin
/*    */   implements SamplerAccess
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private Map<String, Object> field_29487;
/*    */   
/*    */   public void satin$removeSampler(String name) {
/* 36 */     this.field_29487.remove(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean satin$hasSampler(String name) {
/* 41 */     return this.field_29487.containsKey(name);
/*    */   }
/*    */   
/*    */   @Accessor("samplerNames")
/*    */   public abstract List<String> satin$getSamplerNames();
/*    */   
/*    */   @Accessor("loadedSamplerIds")
/*    */   public abstract List<Integer> satin$getSamplerShaderLocs();
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/gl/CoreShaderMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */