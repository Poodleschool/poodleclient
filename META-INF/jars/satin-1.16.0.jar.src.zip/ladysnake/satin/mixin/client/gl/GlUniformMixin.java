/*    */ package ladysnake.satin.mixin.client.gl;
/*    */ 
/*    */ import net.minecraft.class_284;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_284.class})
/*    */ public abstract class GlUniformMixin
/*    */ {
/*    */   @Inject(method = {"upload"}, at = {@At(value = "JUMP", opcode = 154, ordinal = 0, shift = At.Shift.AFTER)}, cancellable = true)
/*    */   private void fixUploadEarlyReturn(CallbackInfo ci) {
/* 33 */     ci.cancel();
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/gl/GlUniformMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */