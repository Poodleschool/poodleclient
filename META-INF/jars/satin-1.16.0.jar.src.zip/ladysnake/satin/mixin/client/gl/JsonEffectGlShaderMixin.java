/*     */ package ladysnake.satin.mixin.client.gl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.IntSupplier;
/*     */ import ladysnake.satin.impl.SamplerAccess;
/*     */ import net.minecraft.class_280;
/*     */ import net.minecraft.class_281;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3300;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.gen.Accessor;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({class_280.class})
/*     */ public abstract class JsonEffectGlShaderMixin
/*     */   implements SamplerAccess
/*     */ {
/*     */   @Shadow
/*     */   @Final
/*     */   private Map<String, IntSupplier> field_1516;
/*     */   
/*     */   public void satin$removeSampler(String name) {
/*  46 */     this.field_1516.remove(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean satin$hasSampler(String name) {
/*  51 */     return this.field_1516.containsKey(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Accessor("samplerNames")
/*     */   public abstract List<String> satin$getSamplerNames();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Accessor("samplerLocations")
/*     */   public abstract List<Integer> satin$getSamplerShaderLocs();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Redirect(at = @At(value = "NEW", target = "net/minecraft/util/Identifier", ordinal = 0), method = {"<init>"})
/*     */   class_2960 constructProgramIdentifier(String arg, class_3300 unused, String id) {
/*  84 */     if (!id.contains(":")) {
/*  85 */       return new class_2960(arg);
/*     */     }
/*  87 */     class_2960 split = new class_2960(id);
/*  88 */     return new class_2960(split.method_12836(), "shaders/program/" + split.method_12832() + ".json");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Redirect(at = @At(value = "NEW", target = "net/minecraft/util/Identifier", ordinal = 0), method = {"loadEffect"})
/*     */   private static class_2960 constructProgramIdentifier(String arg, class_3300 unused, class_281.class_282 shaderType, String id) {
/* 105 */     if (!arg.contains(":")) {
/* 106 */       return new class_2960(arg);
/*     */     }
/* 108 */     class_2960 split = new class_2960(id);
/* 109 */     return new class_2960(split.method_12836(), "shaders/program/" + split.method_12832() + shaderType.method_1284());
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/gl/JsonEffectGlShaderMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */