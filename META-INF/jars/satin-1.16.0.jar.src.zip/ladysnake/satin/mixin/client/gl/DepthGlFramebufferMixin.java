/*    */ package ladysnake.satin.mixin.client.gl;
/*    */ 
/*    */ import com.mojang.blaze3d.platform.GlStateManager;
/*    */ import com.mojang.blaze3d.platform.TextureUtil;
/*    */ import com.mojang.blaze3d.systems.RenderSystem;
/*    */ import ladysnake.satin.api.experimental.ReadableDepthFramebuffer;
/*    */ import net.minecraft.class_276;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_276.class})
/*    */ public abstract class DepthGlFramebufferMixin
/*    */   implements ReadableDepthFramebuffer
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   public boolean field_1478;
/*    */   @Shadow
/*    */   public int field_1482;
/*    */   @Shadow
/*    */   public int field_1481;
/* 48 */   private int satin$stillDepthTexture = -1;
/*    */   
/*    */   @Shadow
/*    */   public abstract void method_1235(boolean paramBoolean);
/*    */   
/*    */   @Inject(method = {"initFbo"}, at = {@At(value = "FIELD", opcode = 181, target = "Lnet/minecraft/client/gl/Framebuffer;depthAttachment:I", shift = At.Shift.AFTER)})
/*    */   private void initFbo(int width, int height, boolean flushErrors, CallbackInfo ci) {
/* 55 */     if (this.field_1478) {
/* 56 */       this.satin$stillDepthTexture = satin$setupDepthTexture();
/*    */     }
/*    */   }
/*    */   
/*    */   private int satin$setupDepthTexture() {
/* 61 */     int shadowMap = GL11.glGenTextures();
/* 62 */     RenderSystem.bindTexture(shadowMap);
/* 63 */     RenderSystem.texParameter(3553, 10240, 9729);
/* 64 */     RenderSystem.texParameter(3553, 10241, 9729);
/* 65 */     RenderSystem.texParameter(3553, 10242, 33071);
/* 66 */     RenderSystem.texParameter(3553, 10243, 33071);
/* 67 */     GlStateManager._texImage2D(3553, 0, 33190, this.field_1482, this.field_1481, 0, 6402, 5121, null);
/* 68 */     return shadowMap;
/*    */   }
/*    */   
/*    */   @Inject(method = {"delete"}, at = {@At(value = "FIELD", opcode = 180, target = "Lnet/minecraft/client/gl/Framebuffer;depthAttachment:I")})
/*    */   private void delete(CallbackInfo ci) {
/* 73 */     if (this.satin$stillDepthTexture > -1) {
/*    */       
/* 75 */       TextureUtil.releaseTextureId(this.satin$stillDepthTexture);
/* 76 */       this.satin$stillDepthTexture = -1;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int getStillDepthMap() {
/* 82 */     return this.satin$stillDepthTexture;
/*    */   }
/*    */ 
/*    */   
/*    */   public void freezeDepthMap() {
/* 87 */     if (this.field_1478) {
/* 88 */       method_1235(false);
/* 89 */       RenderSystem.bindTexture(this.satin$stillDepthTexture);
/* 90 */       GL11.glCopyTexSubImage2D(3553, 0, 0, 0, 0, 0, this.field_1482, this.field_1481);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/gl/DepthGlFramebufferMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */