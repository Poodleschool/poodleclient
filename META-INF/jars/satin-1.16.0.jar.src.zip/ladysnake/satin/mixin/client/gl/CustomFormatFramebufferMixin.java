/*    */ package ladysnake.satin.mixin.client.gl;
/*    */ 
/*    */ import ladysnake.satin.impl.CustomFormatFramebuffers;
/*    */ import net.minecraft.class_276;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyArg;
/*    */ import org.spongepowered.asm.mixin.injection.Slice;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_276.class})
/*    */ public abstract class CustomFormatFramebufferMixin
/*    */ {
/*    */   @Unique
/* 38 */   private int satin$format = 32856;
/*    */ 
/*    */   
/*    */   @Inject(method = {"<init>"}, at = {@At("TAIL")})
/*    */   private void satin$setFormat(boolean useDepth, CallbackInfo ci) {
/* 43 */     CustomFormatFramebuffers.TextureFormat format = CustomFormatFramebuffers.getCustomFormat();
/* 44 */     if (format != null) {
/* 45 */       this.satin$format = format.value;
/* 46 */       CustomFormatFramebuffers.clearCustomFormat();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @ModifyArg(method = {"initFbo"}, slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/client/gl/Framebuffer;setTexFilter(I)V"), to = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/platform/GlStateManager;_glBindFramebuffer(II)V")), at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/platform/GlStateManager;_texImage2D(IIIIIIIILjava/nio/IntBuffer;)V"), index = 2)
/*    */   private int satin$modifyInternalFormat(int internalFormat) {
/* 60 */     return this.satin$format;
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/gl/CustomFormatFramebufferMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */