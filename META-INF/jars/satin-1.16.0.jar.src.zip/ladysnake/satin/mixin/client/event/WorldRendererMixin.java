/*    */ package ladysnake.satin.mixin.client.event;
/*    */ 
/*    */ import ladysnake.satin.api.event.EntitiesPostRenderCallback;
/*    */ import ladysnake.satin.api.event.EntitiesPreRenderCallback;
/*    */ import ladysnake.satin.api.event.PostWorldRenderCallbackV2;
/*    */ import ladysnake.satin.api.experimental.ReadableDepthFramebuffer;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_4184;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4604;
/*    */ import net.minecraft.class_757;
/*    */ import net.minecraft.class_761;
/*    */ import net.minecraft.class_765;
/*    */ import org.joml.Matrix4f;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyVariable;
/*    */ import org.spongepowered.asm.mixin.injection.Slice;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_761.class})
/*    */ public abstract class WorldRendererMixin
/*    */ {
/*    */   @Unique
/*    */   private class_4604 frustum;
/*    */   
/*    */   @ModifyVariable(method = {"render"}, at = @At(value = "CONSTANT", args = {"stringValue=entities"}, ordinal = 0, shift = At.Shift.BEFORE))
/*    */   private class_4604 captureFrustum(class_4604 frustum) {
/* 52 */     this.frustum = frustum;
/* 53 */     return frustum;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"render"}, at = {@At(value = "CONSTANT", args = {"stringValue=entities"}, ordinal = 0)})
/*    */   private void firePreRenderEntities(class_4587 matrix, float tickDelta, long time, boolean renderBlockOutline, class_4184 camera, class_757 renderer, class_765 lmTexManager, Matrix4f matrix4f, CallbackInfo ci) {
/* 63 */     ((EntitiesPreRenderCallback)EntitiesPreRenderCallback.EVENT.invoker()).beforeEntitiesRender(camera, this.frustum, tickDelta);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"render"}, at = {@At(value = "CONSTANT", args = {"stringValue=blockentities"}, ordinal = 0)})
/*    */   private void firePostRenderEntities(class_4587 matrix, float tickDelta, long time, boolean renderBlockOutline, class_4184 camera, class_757 renderer, class_765 lmTexManager, Matrix4f matrix4f, CallbackInfo ci) {
/* 71 */     ((EntitiesPostRenderCallback)EntitiesPostRenderCallback.EVENT.invoker()).onEntitiesRendered(camera, this.frustum, tickDelta);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"render"}, slice = {@Slice(from = @At(value = "FIELD:LAST", opcode = 180, target = "Lnet/minecraft/client/render/WorldRenderer;transparencyPostProcessor:Lnet/minecraft/client/gl/PostEffectProcessor;"))}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/gl/PostEffectProcessor;render(F)V"), @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/RenderSystem;depthMask(Z)V", ordinal = 1, shift = At.Shift.AFTER)})
/*    */   private void hookPostWorldRender(class_4587 matrices, float tickDelta, long nanoTime, boolean renderBlockOutline, class_4184 camera, class_757 renderer, class_765 lmTexManager, Matrix4f matrix4f, CallbackInfo ci) {
/* 83 */     ((ReadableDepthFramebuffer)class_310.method_1551().method_1522()).freezeDepthMap();
/* 84 */     ((PostWorldRenderCallbackV2)PostWorldRenderCallbackV2.EVENT.invoker()).onWorldRendered(matrices, camera, tickDelta, nanoTime);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/event/WorldRendererMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */