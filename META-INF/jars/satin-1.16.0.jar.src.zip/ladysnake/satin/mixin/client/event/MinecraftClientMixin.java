/*    */ package ladysnake.satin.mixin.client.event;
/*    */ 
/*    */ import ladysnake.satin.api.event.ResolutionChangeCallback;
/*    */ import net.minecraft.class_1041;
/*    */ import net.minecraft.class_310;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_310.class})
/*    */ public abstract class MinecraftClientMixin
/*    */ {
/*    */   @Final
/*    */   @Shadow
/*    */   private class_1041 field_1704;
/*    */   
/*    */   @Inject(method = {"onResolutionChanged"}, at = {@At("RETURN")})
/*    */   private void hookResolutionChanged(CallbackInfo info) {
/* 39 */     int width = this.field_1704.method_4489();
/* 40 */     int height = this.field_1704.method_4506();
/* 41 */     ((ResolutionChangeCallback)ResolutionChangeCallback.EVENT.invoker()).onResolutionChanged(width, height);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/event/MinecraftClientMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */