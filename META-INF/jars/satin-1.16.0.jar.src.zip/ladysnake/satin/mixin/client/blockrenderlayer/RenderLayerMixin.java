/*    */ package ladysnake.satin.mixin.client.blockrenderlayer;
/*    */ 
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import ladysnake.satin.impl.BlockRenderLayerRegistry;
/*    */ import net.minecraft.class_1921;
/*    */ import net.minecraft.class_4668;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1921.class})
/*    */ public abstract class RenderLayerMixin
/*    */   extends class_4668
/*    */ {
/*    */   private RenderLayerMixin() {
/* 32 */     super(null, null, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"getBlockLayers"}, at = {@At("RETURN")}, cancellable = true)
/*    */   private static void getBlockLayers(CallbackInfoReturnable<ImmutableList<Object>> info) {
/* 41 */     info.setReturnValue(
/* 42 */         ImmutableList.builder()
/* 43 */         .addAll((Iterable)info.getReturnValue())
/* 44 */         .addAll(BlockRenderLayerRegistry.INSTANCE.getLayers())
/* 45 */         .build());
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/blockrenderlayer/RenderLayerMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */