/*    */ package ladysnake.satin.mixin.client.blockrenderlayer;
/*    */ 
/*    */ import ladysnake.satin.impl.BlockRenderLayerRegistry;
/*    */ import net.minecraft.class_1921;
/*    */ import net.minecraft.class_4184;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_757;
/*    */ import net.minecraft.class_761;
/*    */ import net.minecraft.class_765;
/*    */ import org.joml.Matrix4f;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Slice;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_761.class})
/*    */ public abstract class WorldRendererMixin
/*    */ {
/*    */   @Shadow
/*    */   protected abstract void method_3251(class_1921 paramclass_1921, class_4587 paramclass_4587, double paramDouble1, double paramDouble2, double paramDouble3, Matrix4f paramMatrix4f);
/*    */   
/*    */   @Inject(method = {"render"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;renderLayer(Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/util/math/MatrixStack;DDDLorg/joml/Matrix4f;)V", ordinal = 2, shift = At.Shift.AFTER)}, slice = {@Slice(from = @At(value = "INVOKE_STRING", target = "Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V", args = {"ldc=terrain"}), to = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/DimensionEffects;isDarkened()Z"))}, locals = LocalCapture.CAPTURE_FAILSOFT)
/*    */   private void renderCustom(class_4587 matrices, float tickDelta, long limitTime, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightmapTextureManager, Matrix4f projectionMatrix, CallbackInfo ci) {
/* 66 */     for (class_1921 layer : BlockRenderLayerRegistry.INSTANCE.getLayers())
/* 67 */       method_3251(layer, matrices, (camera.method_19326()).field_1352, (camera.method_19326()).field_1351, (camera.method_19326()).field_1350, projectionMatrix); 
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/mixin/client/blockrenderlayer/WorldRendererMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */