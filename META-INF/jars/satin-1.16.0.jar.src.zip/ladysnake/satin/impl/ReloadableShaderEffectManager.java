/*     */ package ladysnake.satin.impl;
/*     */ 
/*     */ import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import ladysnake.satin.Satin;
/*     */ import ladysnake.satin.api.event.ResolutionChangeCallback;
/*     */ import ladysnake.satin.api.managed.ManagedCoreShader;
/*     */ import ladysnake.satin.api.managed.ManagedShaderEffect;
/*     */ import ladysnake.satin.api.managed.ShaderEffectManager;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_5912;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReloadableShaderEffectManager
/*     */   implements ShaderEffectManager, ResolutionChangeCallback
/*     */ {
/*  41 */   public static final ReloadableShaderEffectManager INSTANCE = new ReloadableShaderEffectManager();
/*  42 */   public static final class_2960 SHADER_RESOURCE_KEY = new class_2960("dissolution:shaders");
/*     */   
/*  44 */   private final Set<ResettableManagedShaderBase<?>> managedShaders = (Set<ResettableManagedShaderBase<?>>)new ReferenceOpenHashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedShaderEffect manage(class_2960 location) {
/*  54 */     return manage(location, s -> {
/*     */         
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedShaderEffect manage(class_2960 location, Consumer<ManagedShaderEffect> initCallback) {
/*  66 */     ResettableManagedShaderEffect ret = new ResettableManagedShaderEffect(location, initCallback);
/*  67 */     this.managedShaders.add(ret);
/*  68 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public ManagedCoreShader manageCoreShader(class_2960 location) {
/*  73 */     return manageCoreShader(location, class_290.field_1580);
/*     */   }
/*     */ 
/*     */   
/*     */   public ManagedCoreShader manageCoreShader(class_2960 location, class_293 vertexFormat) {
/*  78 */     return manageCoreShader(location, vertexFormat, s -> {
/*     */         
/*     */         });
/*     */   }
/*     */   public ManagedCoreShader manageCoreShader(class_2960 location, class_293 vertexFormat, Consumer<ManagedCoreShader> initCallback) {
/*  83 */     ResettableManagedCoreShader ret = new ResettableManagedCoreShader(location, vertexFormat, initCallback);
/*  84 */     this.managedShaders.add(ret);
/*  85 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose(ManagedShaderEffect shader) {
/*  99 */     shader.release();
/* 100 */     this.managedShaders.remove(shader);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose(ManagedCoreShader shader) {
/* 105 */     shader.release();
/* 106 */     this.managedShaders.remove(shader);
/*     */   }
/*     */   
/*     */   public void reload(class_5912 shaderResources) {
/* 110 */     for (ResettableManagedShaderBase<?> ss : this.managedShaders) {
/* 111 */       ss.initializeOrLog(shaderResources);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onResolutionChanged(int newWidth, int newHeight) {
/* 117 */     if (!Satin.areShadersDisabled() && !this.managedShaders.isEmpty())
/* 118 */       for (ResettableManagedShaderBase<?> ss : this.managedShaders) {
/* 119 */         if (ss.isInitialized())
/* 120 */           ss.setup(newWidth, newHeight); 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/ReloadableShaderEffectManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */