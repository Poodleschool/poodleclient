/*     */ package ladysnake.satin.impl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum TextureFormat
/*     */ {
/*  74 */   RGBA8(32856),
/*  75 */   RGBA16(32859),
/*  76 */   RGBA16F(34842),
/*  77 */   RGBA32F(34836);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextureFormat decode(String formatString) {
/*  90 */     switch (formatString) {
/*     */       case "RGBA8":
/*     */       
/*     */       
/*     */       case "RGBA16":
/*     */       
/*     */       case "RGBA16F":
/*     */       
/*     */       case "RGBA32F":
/*     */       
/*     */     } 
/* 101 */     throw new IllegalArgumentException("Unsupported texture format " + formatString);
/*     */   }
/*     */ 
/*     */   
/*     */   TextureFormat(int value) {
/* 106 */     this.value = value;
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/CustomFormatFramebuffers$TextureFormat.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */