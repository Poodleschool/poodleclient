package ladysnake.satin.impl;

import java.util.List;

public interface SamplerAccess {
  void satin$removeSampler(String paramString);
  
  boolean satin$hasSampler(String paramString);
  
  List<String> satin$getSamplerNames();
  
  List<Integer> satin$getSamplerShaderLocs();
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/SamplerAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */