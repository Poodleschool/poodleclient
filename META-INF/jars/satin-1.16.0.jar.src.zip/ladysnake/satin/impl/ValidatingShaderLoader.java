/*     */ package ladysnake.satin.impl;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import javax.annotation.Nullable;
/*     */ import ladysnake.satin.Satin;
/*     */ import ladysnake.satin.api.util.ShaderLinkException;
/*     */ import ladysnake.satin.api.util.ShaderLoader;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_3300;
/*     */ import org.lwjgl.opengl.ARBShaderObjects;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ValidatingShaderLoader
/*     */   implements ShaderLoader
/*     */ {
/*  42 */   public static final ShaderLoader INSTANCE = new ValidatingShaderLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loadShader(class_3300 resourceManager, @Nullable class_2960 vertexLocation, @Nullable class_2960 fragmentLocation) throws IOException {
/*  55 */     int programId = GlStateManager.glCreateProgram();
/*     */     
/*  57 */     int vertexShaderId = 0;
/*  58 */     int fragmentShaderId = 0;
/*     */ 
/*     */     
/*  61 */     if (vertexLocation != null) {
/*  62 */       vertexShaderId = GlStateManager.glCreateShader(35633);
/*  63 */       ARBShaderObjects.glShaderSourceARB(vertexShaderId, fromFile(resourceManager, vertexLocation));
/*  64 */       ARBShaderObjects.glCompileShaderARB(vertexShaderId);
/*  65 */       ARBShaderObjects.glAttachObjectARB(programId, vertexShaderId);
/*  66 */       String log = GL20.glGetShaderInfoLog(vertexShaderId, 1024);
/*  67 */       if (!log.isEmpty()) {
/*  68 */         Satin.LOGGER.error("Could not compile vertex shader {}: {}", vertexLocation, log);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  73 */     if (fragmentLocation != null) {
/*  74 */       fragmentShaderId = GlStateManager.glCreateShader(35632);
/*  75 */       ARBShaderObjects.glShaderSourceARB(fragmentShaderId, fromFile(resourceManager, fragmentLocation));
/*  76 */       ARBShaderObjects.glCompileShaderARB(fragmentShaderId);
/*  77 */       ARBShaderObjects.glAttachObjectARB(programId, fragmentShaderId);
/*  78 */       String log = GL20.glGetShaderInfoLog(fragmentShaderId, 1024);
/*  79 */       if (!log.isEmpty()) {
/*  80 */         Satin.LOGGER.error("Could not compile fragment shader {}: {}", fragmentLocation, log);
/*     */       }
/*     */     } 
/*     */     
/*  84 */     GlStateManager.glLinkProgram(programId);
/*     */     
/*  86 */     if (GL20.glGetProgrami(programId, 35714) == 0) {
/*  87 */       throw new ShaderLinkException("Error linking Shader code: " + GL20.glGetProgramInfoLog(programId, 1024));
/*     */     }
/*     */ 
/*     */     
/*  91 */     if (vertexShaderId != 0) {
/*  92 */       GL20.glDetachShader(programId, vertexShaderId);
/*  93 */       GL20.glDeleteShader(vertexShaderId);
/*     */     } 
/*  95 */     if (fragmentShaderId != 0) {
/*  96 */       GL20.glDetachShader(programId, fragmentShaderId);
/*  97 */       GL20.glDeleteShader(fragmentShaderId);
/*     */     } 
/*     */ 
/*     */     
/* 101 */     GL20.glValidateProgram(programId);
/* 102 */     if (GL20.glGetProgrami(programId, 35715) == 0) {
/* 103 */       Satin.LOGGER.warn("Warning validating Shader code: {}", GL20.glGetProgramInfoLog(programId, 1024));
/*     */     }
/*     */     
/* 106 */     return programId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fromFile(class_3300 resourceManager, class_2960 fileLocation) throws IOException {
/* 117 */     StringBuilder source = new StringBuilder();
/*     */     
/* 119 */     InputStream in = resourceManager.getResourceOrThrow(fileLocation).method_14482(); 
/* 120 */     try { BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)); 
/*     */       try { String line;
/* 122 */         while ((line = reader.readLine()) != null) {
/* 123 */           source.append(line).append('\n');
/*     */         }
/* 125 */         reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (in != null) in.close();  } catch (Throwable throwable) { if (in != null)
/* 126 */         try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  return source.toString();
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/ValidatingShaderLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */