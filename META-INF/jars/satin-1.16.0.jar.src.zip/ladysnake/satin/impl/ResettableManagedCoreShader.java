/*    */ package ladysnake.satin.impl;
/*    */ 
/*    */ import com.google.common.base.Preconditions;
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Function;
/*    */ import ladysnake.satin.Satin;
/*    */ import ladysnake.satin.api.managed.ManagedCoreShader;
/*    */ import ladysnake.satin.api.managed.uniform.SamplerUniform;
/*    */ import net.fabricmc.fabric.impl.client.rendering.FabricShaderProgram;
/*    */ import net.minecraft.class_1921;
/*    */ import net.minecraft.class_293;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_5912;
/*    */ import net.minecraft.class_5944;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResettableManagedCoreShader
/*    */   extends ResettableManagedShaderBase<class_5944>
/*    */   implements ManagedCoreShader
/*    */ {
/*    */   private final Consumer<ManagedCoreShader> initCallback;
/*    */   private final RenderLayerSupplier renderLayerSupplier;
/*    */   private final class_293 vertexFormat;
/* 44 */   private final Map<String, ManagedSamplerUniformV1> managedSamplers = new HashMap<>();
/*    */   
/*    */   public ResettableManagedCoreShader(class_2960 location, class_293 vertexFormat, Consumer<ManagedCoreShader> initCallback) {
/* 47 */     super(location);
/* 48 */     this.vertexFormat = vertexFormat;
/* 49 */     this.initCallback = initCallback;
/* 50 */     this.renderLayerSupplier = RenderLayerSupplier.shader(
/* 51 */         String.format("%s_%d", new Object[] { location, Integer.valueOf(System.identityHashCode(this)) }), vertexFormat, this::getProgram);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected class_5944 parseShader(class_5912 resourceManager, class_310 mc, class_2960 location) throws IOException {
/* 59 */     return (class_5944)new FabricShaderProgram(resourceManager, getLocation(), this.vertexFormat);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setup(int newWidth, int newHeight) {
/* 64 */     Preconditions.checkNotNull(this.shader);
/* 65 */     for (ManagedUniformBase uniform : getManagedUniforms()) {
/* 66 */       setupUniform(uniform, this.shader);
/*    */     }
/* 68 */     this.initCallback.accept(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public class_5944 getProgram() {
/* 73 */     return this.shader;
/*    */   }
/*    */ 
/*    */   
/*    */   public class_1921 getRenderLayer(class_1921 baseLayer) {
/* 78 */     return this.renderLayerSupplier.getRenderLayer(baseLayer);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean setupUniform(ManagedUniformBase uniform, class_5944 shader) {
/* 83 */     return uniform.findUniformTarget(shader);
/*    */   }
/*    */ 
/*    */   
/*    */   public SamplerUniform findSampler(String samplerName) {
/* 88 */     return (SamplerUniform)manageUniform(this.managedSamplers, ManagedSamplerUniformV1::new, samplerName, "sampler");
/*    */   }
/*    */ 
/*    */   
/*    */   protected void logInitError(IOException e) {
/* 93 */     Satin.LOGGER.error("Could not create shader program {}", getLocation(), e);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/ResettableManagedCoreShader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */