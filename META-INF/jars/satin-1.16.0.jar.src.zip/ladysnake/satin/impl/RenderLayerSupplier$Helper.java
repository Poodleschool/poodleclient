/*    */ package ladysnake.satin.impl;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.class_1921;
/*    */ import net.minecraft.class_4668;
/*    */ import net.minecraft.class_5944;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Helper
/*    */   extends class_4668
/*    */ {
/*    */   public static class_4668 makeShader(Supplier<class_5944> shader) {
/* 78 */     return (class_4668)new class_4668.class_5942(shader);
/*    */   }
/*    */   
/*    */   public static void applyShader(class_1921.class_4688.class_4689 builder, class_4668 shader) {
/* 82 */     builder.method_34578((class_4668.class_5942)shader);
/*    */   }
/*    */   
/*    */   private Helper(String name, Runnable beginAction, Runnable endAction) {
/* 86 */     super(name, beginAction, endAction);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/RenderLayerSupplier$Helper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */