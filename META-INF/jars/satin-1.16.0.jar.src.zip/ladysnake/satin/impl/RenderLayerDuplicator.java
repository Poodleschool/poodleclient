/*    */ package ladysnake.satin.impl;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import net.minecraft.class_1921;
/*    */ import net.minecraft.class_293;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RenderLayerDuplicator
/*    */ {
/*    */   public static class_1921 copy(class_1921 existing, String newName, Consumer<class_1921.class_4688.class_4689> op) {
/* 29 */     return copy(existing, newName, null, op);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class_1921 copy(class_1921 existing, String newName, @Nullable class_293 vertexFormat, Consumer<class_1921.class_4688.class_4689> op) {
/* 41 */     checkDefaultImpl(existing);
/* 42 */     return ((SatinRenderLayer)existing).satin$copy(newName, vertexFormat, op);
/*    */   }
/*    */   
/*    */   public static class_1921.class_4688 copyPhaseParameters(class_1921 existing, Consumer<class_1921.class_4688.class_4689> op) {
/* 46 */     checkDefaultImpl(existing);
/* 47 */     return ((SatinRenderLayer)existing).satin$copyPhaseParameters(op);
/*    */   }
/*    */   
/*    */   private static void checkDefaultImpl(class_1921 existing) {
/* 51 */     if (!(existing instanceof SatinRenderLayer))
/* 52 */       throw new IllegalArgumentException("Unrecognized RenderLayer implementation " + existing.getClass() + ". Layer duplication is only applicable to the default (MultiPhase) implementation"); 
/*    */   }
/*    */   
/*    */   public static interface SatinRenderLayer {
/*    */     class_1921 satin$copy(String param1String, @Nullable class_293 param1class_293, Consumer<class_1921.class_4688.class_4689> param1Consumer);
/*    */     
/*    */     class_1921.class_4688 satin$copyPhaseParameters(Consumer<class_1921.class_4688.class_4689> param1Consumer);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/RenderLayerDuplicator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */