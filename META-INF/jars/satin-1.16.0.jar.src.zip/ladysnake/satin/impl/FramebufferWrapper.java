/*     */ package ladysnake.satin.impl;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ import ladysnake.satin.Satin;
/*     */ import ladysnake.satin.api.managed.ManagedFramebuffer;
/*     */ import net.minecraft.class_1041;
/*     */ import net.minecraft.class_1921;
/*     */ import net.minecraft.class_276;
/*     */ import net.minecraft.class_279;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FramebufferWrapper
/*     */   implements ManagedFramebuffer
/*     */ {
/*     */   private final RenderLayerSupplier renderLayerSupplier;
/*     */   private final String name;
/*     */   @Nullable
/*     */   private class_276 wrapped;
/*     */   
/*     */   FramebufferWrapper(String name) {
/*  37 */     this.name = name;
/*  38 */     this.renderLayerSupplier = RenderLayerSupplier.framebuffer(this.name + this.name, () -> beginWrite(false), () -> class_310.method_1551().method_1522().method_1235(false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void findTarget(@Nullable class_279 shaderEffect) {
/*  46 */     if (shaderEffect == null) {
/*  47 */       this.wrapped = null;
/*     */     } else {
/*  49 */       this.wrapped = shaderEffect.method_1264(this.name);
/*  50 */       if (this.wrapped == null) {
/*  51 */         Satin.LOGGER.warn("No target framebuffer found with name {} in shader {}", this.name, shaderEffect.method_1260());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getName() {
/*  57 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public class_276 getFramebuffer() {
/*  63 */     return this.wrapped;
/*     */   }
/*     */ 
/*     */   
/*     */   public void copyDepthFrom(class_276 buffer) {
/*  68 */     if (this.wrapped != null) {
/*  69 */       this.wrapped.method_29329(buffer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginWrite(boolean updateViewport) {
/*  75 */     if (this.wrapped != null) {
/*  76 */       this.wrapped.method_1235(updateViewport);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void draw() {
/*  82 */     class_1041 window = class_310.method_1551().method_22683();
/*  83 */     draw(window.method_4489(), window.method_4506(), true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void draw(int width, int height, boolean disableBlend) {
/*  88 */     if (this.wrapped != null) {
/*  89 */       this.wrapped.method_22594(width, height, disableBlend);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  95 */     clear(class_310.field_1703);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear(boolean swallowErrors) {
/* 100 */     if (this.wrapped != null) {
/* 101 */       this.wrapped.method_1230(swallowErrors);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public class_1921 getRenderLayer(class_1921 baseLayer) {
/* 107 */     return this.renderLayerSupplier.getRenderLayer(baseLayer);
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/FramebufferWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */