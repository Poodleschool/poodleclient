/*     */ package ladysnake.satin.impl;
/*     */ 
/*     */ import it.unimi.dsi.fastutil.ints.IntArrayList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import ladysnake.satin.api.managed.uniform.SamplerUniform;
/*     */ import net.minecraft.class_280;
/*     */ import net.minecraft.class_283;
/*     */ import net.minecraft.class_284;
/*     */ import net.minecraft.class_5944;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ManagedSamplerUniformBase
/*     */   extends ManagedUniformBase
/*     */   implements SamplerUniform
/*     */ {
/*  41 */   protected SamplerAccess[] targets = new SamplerAccess[0];
/*  42 */   protected int[] locations = new int[0];
/*     */   protected Object cachedValue;
/*     */   
/*     */   public ManagedSamplerUniformBase(String name) {
/*  46 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean findUniformTargets(List<class_283> shaders) {
/*  51 */     List<SamplerAccess> targets = new ArrayList<>(shaders.size());
/*  52 */     IntArrayList intArrayList = new IntArrayList(shaders.size());
/*  53 */     for (class_283 shader : shaders) {
/*  54 */       class_280 program = shader.method_1295();
/*  55 */       SamplerAccess access = (SamplerAccess)program;
/*  56 */       if (access.satin$hasSampler(this.name)) {
/*  57 */         targets.add(access);
/*  58 */         intArrayList.add(getSamplerLoc(access));
/*     */       } 
/*     */     } 
/*  61 */     this.targets = targets.<SamplerAccess>toArray(new SamplerAccess[0]);
/*  62 */     this.locations = intArrayList.toArray(new int[0]);
/*  63 */     syncCurrentValues();
/*  64 */     return (this.targets.length > 0);
/*     */   }
/*     */   
/*     */   private int getSamplerLoc(SamplerAccess access) {
/*  68 */     return ((Integer)access.satin$getSamplerShaderLocs().get(access.satin$getSamplerNames().indexOf(this.name))).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean findUniformTarget(class_5944 shader) {
/*  73 */     return findUniformTarget((SamplerAccess)shader);
/*     */   }
/*     */   
/*     */   private boolean findUniformTarget(SamplerAccess access) {
/*  77 */     if (access.satin$hasSampler(this.name)) {
/*  78 */       this.targets = new SamplerAccess[] { access };
/*  79 */       this.locations = new int[] { getSamplerLoc(access) };
/*  80 */       syncCurrentValues();
/*  81 */       return true;
/*     */     } 
/*  83 */     return false;
/*     */   }
/*     */   
/*     */   private void syncCurrentValues() {
/*  87 */     Object value = this.cachedValue;
/*  88 */     if (value != null) {
/*  89 */       this.cachedValue = null;
/*  90 */       set(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract void set(Object paramObject);
/*     */   
/*     */   public void setDirect(int activeTexture) {
/*  98 */     int length = this.locations.length;
/*  99 */     for (int i = 0; i < length; i++) {
/* 100 */       this.targets[i].satin$removeSampler(this.name);
/* 101 */       class_284.method_22095(this.locations[i], activeTexture);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/ManagedSamplerUniformBase.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */