/*    */ package ladysnake.satin.impl;
/*    */ 
/*    */ import it.unimi.dsi.fastutil.objects.ObjectArraySet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.class_1921;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlockRenderLayerRegistry
/*    */ {
/* 26 */   public static final BlockRenderLayerRegistry INSTANCE = new BlockRenderLayerRegistry();
/* 27 */   private final Set<class_1921> renderLayers = (Set<class_1921>)new ObjectArraySet();
/*    */   
/*    */   private volatile boolean registryLocked = false;
/*    */ 
/*    */   
/*    */   public void registerRenderLayer(class_1921 layer) {
/* 33 */     if (this.registryLocked) {
/* 34 */       throw new IllegalStateException(String.format("RenderLayer %s was added too late.", new Object[] { layer }));
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 40 */     this.renderLayers.add(layer);
/*    */   }
/*    */   
/*    */   public Set<class_1921> getLayers() {
/* 44 */     this.registryLocked = true;
/* 45 */     return this.renderLayers;
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/BlockRenderLayerRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */