package ladysnake.satin.impl;

import java.util.function.Consumer;
import net.minecraft.class_1921;
import net.minecraft.class_293;
import org.jetbrains.annotations.Nullable;

public interface SatinRenderLayer {
  class_1921 satin$copy(String paramString, @Nullable class_293 paramclass_293, Consumer<class_1921.class_4688.class_4689> paramConsumer);
  
  class_1921.class_4688 satin$copyPhaseParameters(Consumer<class_1921.class_4688.class_4689> paramConsumer);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/RenderLayerDuplicator$SatinRenderLayer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */