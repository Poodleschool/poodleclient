/*    */ package ladysnake.satin.impl;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Consumer;
/*    */ import java.util.function.Supplier;
/*    */ import ladysnake.satin.mixin.client.render.RenderPhaseAccessor;
/*    */ import net.minecraft.class_1921;
/*    */ import net.minecraft.class_293;
/*    */ import net.minecraft.class_4668;
/*    */ import net.minecraft.class_5944;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderLayerSupplier
/*    */ {
/*    */   private final Consumer<class_1921.class_4688.class_4689> transform;
/* 34 */   private final Map<class_1921, class_1921> renderLayerCache = new HashMap<>();
/*    */   
/*    */   private final String uniqueName;
/*    */   
/*    */   public static RenderLayerSupplier framebuffer(String name, Runnable setupState, Runnable cleanupState) {
/* 39 */     class_4668.class_4678 target = new class_4668.class_4678(name + "_target", setupState, cleanupState);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     return new RenderLayerSupplier(name, builder -> builder.method_23610(target));
/*    */   } @Nullable
/*    */   private final class_293 vertexFormat;
/*    */   public static RenderLayerSupplier shader(String name, class_293 vertexFormat, Supplier<class_5944> shaderSupplier) {
/* 48 */     class_4668 shader = Helper.makeShader(shaderSupplier);
/* 49 */     return new RenderLayerSupplier(name, vertexFormat, builder -> Helper.applyShader(builder, shader));
/*    */   }
/*    */   
/*    */   public RenderLayerSupplier(String name, Consumer<class_1921.class_4688.class_4689> transformer) {
/* 53 */     this(name, null, transformer);
/*    */   }
/*    */   
/*    */   public RenderLayerSupplier(String name, @Nullable class_293 vertexFormat, Consumer<class_1921.class_4688.class_4689> transformer) {
/* 57 */     this.uniqueName = name;
/* 58 */     this.vertexFormat = vertexFormat;
/* 59 */     this.transform = transformer;
/*    */   }
/*    */   
/*    */   public class_1921 getRenderLayer(class_1921 baseLayer) {
/* 63 */     class_1921 existing = this.renderLayerCache.get(baseLayer);
/* 64 */     if (existing != null) {
/* 65 */       return existing;
/*    */     }
/* 67 */     String newName = ((RenderPhaseAccessor)baseLayer).getName() + "_" + ((RenderPhaseAccessor)baseLayer).getName();
/* 68 */     class_1921 newLayer = RenderLayerDuplicator.copy(baseLayer, newName, this.vertexFormat, this.transform);
/* 69 */     this.renderLayerCache.put(baseLayer, newLayer);
/* 70 */     return newLayer;
/*    */   }
/*    */ 
/*    */   
/*    */   private static class Helper
/*    */     extends class_4668
/*    */   {
/*    */     public static class_4668 makeShader(Supplier<class_5944> shader) {
/* 78 */       return (class_4668)new class_4668.class_5942(shader);
/*    */     }
/*    */     
/*    */     public static void applyShader(class_1921.class_4688.class_4689 builder, class_4668 shader) {
/* 82 */       builder.method_34578((class_4668.class_5942)shader);
/*    */     }
/*    */     
/*    */     private Helper(String name, Runnable beginAction, Runnable endAction) {
/* 86 */       super(name, beginAction, endAction);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/RenderLayerSupplier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */