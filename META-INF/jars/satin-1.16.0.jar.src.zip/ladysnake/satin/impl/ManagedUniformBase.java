/*    */ package ladysnake.satin.impl;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.class_283;
/*    */ import net.minecraft.class_5944;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ManagedUniformBase
/*    */ {
/*    */   protected final String name;
/*    */   
/*    */   public ManagedUniformBase(String name) {
/* 29 */     this.name = name;
/*    */   }
/*    */   
/*    */   public abstract boolean findUniformTargets(List<class_283> paramList);
/*    */   
/*    */   public abstract boolean findUniformTarget(class_5944 paramclass_5944);
/*    */   
/*    */   public String getName() {
/* 37 */     return this.name;
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/ManagedUniformBase.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */