/*     */ package ladysnake.satin.impl;
/*     */ 
/*     */ import net.minecraft.class_276;
/*     */ import net.minecraft.class_6367;
/*     */ import org.apiguardian.api.API;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomFormatFramebuffers
/*     */ {
/*     */   public static final String FORMAT_KEY = "satin:format";
/*  32 */   private static final ThreadLocal<TextureFormat> FORMAT = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.EXPERIMENTAL)
/*     */   public static class_276 create(int width, int height, boolean useDepth, boolean getError, TextureFormat format) {
/*     */     try {
/*  42 */       FORMAT.set(format);
/*  43 */       return (class_276)new class_6367(width, height, useDepth, getError);
/*     */     } finally {
/*  45 */       FORMAT.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void prepareCustomFormat(String formatString) {
/*  62 */     FORMAT.set(TextureFormat.decode(formatString));
/*     */   }
/*     */   @Nullable
/*     */   public static TextureFormat getCustomFormat() {
/*  66 */     return FORMAT.get();
/*     */   }
/*     */   
/*     */   public static void clearCustomFormat() {
/*  70 */     FORMAT.remove();
/*     */   }
/*     */   
/*     */   public enum TextureFormat {
/*  74 */     RGBA8(32856),
/*  75 */     RGBA16(32859),
/*  76 */     RGBA16F(34842),
/*  77 */     RGBA32F(34836);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TextureFormat decode(String formatString) {
/*  90 */       switch (formatString) {
/*     */         case "RGBA8":
/*     */         
/*     */         
/*     */         case "RGBA16":
/*     */         
/*     */         case "RGBA16F":
/*     */         
/*     */         case "RGBA32F":
/*     */         
/*     */       } 
/* 101 */       throw new IllegalArgumentException("Unsupported texture format " + formatString);
/*     */     }
/*     */ 
/*     */     
/*     */     TextureFormat(int value) {
/* 106 */       this.value = value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/CustomFormatFramebuffers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */