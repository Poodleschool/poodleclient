/*     */ package ladysnake.satin.impl;
/*     */ 
/*     */ import com.google.common.base.Preconditions;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import javax.annotation.Nullable;
/*     */ import ladysnake.satin.Satin;
/*     */ import ladysnake.satin.api.managed.ManagedFramebuffer;
/*     */ import ladysnake.satin.api.managed.ManagedShaderEffect;
/*     */ import ladysnake.satin.api.managed.uniform.SamplerUniform;
/*     */ import ladysnake.satin.api.managed.uniform.SamplerUniformV2;
/*     */ import ladysnake.satin.api.util.ShaderPrograms;
/*     */ import ladysnake.satin.mixin.client.AccessiblePassesShaderEffect;
/*     */ import net.minecraft.class_1044;
/*     */ import net.minecraft.class_276;
/*     */ import net.minecraft.class_279;
/*     */ import net.minecraft.class_280;
/*     */ import net.minecraft.class_283;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_5912;
/*     */ import org.apiguardian.api.API;
/*     */ import org.joml.Matrix4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResettableManagedShaderEffect
/*     */   extends ResettableManagedShaderBase<class_279>
/*     */   implements ManagedShaderEffect
/*     */ {
/*     */   private final Consumer<ManagedShaderEffect> initCallback;
/*     */   private final Map<String, FramebufferWrapper> managedTargets;
/*  62 */   private final Map<String, ManagedSamplerUniformV2> managedSamplers = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @API(status = API.Status.INTERNAL)
/*     */   public ResettableManagedShaderEffect(class_2960 location, Consumer<ManagedShaderEffect> initCallback) {
/*  75 */     super(location);
/*  76 */     this.initCallback = initCallback;
/*  77 */     this.managedTargets = new HashMap<>();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public class_279 getShaderEffect() {
/*  83 */     return getShaderOrLog();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() throws IOException {
/*  88 */     initialize((class_5912)class_310.method_1551().method_1478());
/*     */   }
/*     */ 
/*     */   
/*     */   protected class_279 parseShader(class_5912 resourceFactory, class_310 mc, class_2960 location) throws IOException {
/*  93 */     return new class_279(mc.method_1531(), mc.method_1478(), mc.method_1522(), location);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setup(int windowWidth, int windowHeight) {
/*  98 */     Preconditions.checkNotNull(this.shader);
/*  99 */     this.shader.method_1259(windowWidth, windowHeight);
/*     */     
/* 101 */     for (ManagedUniformBase uniform : getManagedUniforms()) {
/* 102 */       setupUniform(uniform, this.shader);
/*     */     }
/*     */     
/* 105 */     for (FramebufferWrapper buf : this.managedTargets.values()) {
/* 106 */       buf.findTarget(this.shader);
/*     */     }
/*     */     
/* 109 */     this.initCallback.accept(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(float tickDelta) {
/* 117 */     class_279 sg = getShaderEffect();
/* 118 */     if (sg != null) {
/* 119 */       RenderSystem.disableBlend();
/* 120 */       RenderSystem.disableDepthTest();
/* 121 */       RenderSystem.resetTextureMatrix();
/* 122 */       sg.method_1258(tickDelta);
/* 123 */       class_310.method_1551().method_1522().method_1235(true);
/* 124 */       RenderSystem.disableBlend();
/* 125 */       RenderSystem.blendFunc(770, 771);
/* 126 */       RenderSystem.enableDepthTest();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ManagedFramebuffer getTarget(String name) {
/* 132 */     return this.managedTargets.computeIfAbsent(name, n -> {
/*     */           FramebufferWrapper ret = new FramebufferWrapper(n);
/*     */           if (this.shader != null) {
/*     */             ret.findTarget(this.shader);
/*     */           }
/*     */           return ret;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniformValue(String uniformName, int value) {
/* 146 */     findUniform1i(uniformName).set(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniformValue(String uniformName, int value0, int value1) {
/* 154 */     findUniform2i(uniformName).set(value0, value1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniformValue(String uniformName, int value0, int value1, int value2) {
/* 162 */     findUniform3i(uniformName).set(value0, value1, value2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniformValue(String uniformName, int value0, int value1, int value2, int value3) {
/* 170 */     findUniform4i(uniformName).set(value0, value1, value2, value3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniformValue(String uniformName, float value) {
/* 178 */     findUniform1f(uniformName).set(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniformValue(String uniformName, float value0, float value1) {
/* 186 */     findUniform2f(uniformName).set(value0, value1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniformValue(String uniformName, float value0, float value1, float value2) {
/* 194 */     findUniform3f(uniformName).set(value0, value1, value2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniformValue(String uniformName, float value0, float value1, float value2, float value3) {
/* 202 */     findUniform4f(uniformName).set(value0, value1, value2, value3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniformValue(String uniformName, Matrix4f value) {
/* 210 */     findUniformMat4(uniformName).set(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSamplerUniform(String samplerName, class_1044 texture) {
/* 218 */     findSampler(samplerName).set(texture);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSamplerUniform(String samplerName, class_276 textureFbo) {
/* 226 */     findSampler(samplerName).set(textureFbo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSamplerUniform(String samplerName, int textureName) {
/* 234 */     findSampler(samplerName).set(textureName);
/*     */   }
/*     */ 
/*     */   
/*     */   public SamplerUniformV2 findSampler(String samplerName) {
/* 239 */     return (SamplerUniformV2)manageUniform(this.managedSamplers, ManagedSamplerUniformV2::new, samplerName, "sampler");
/*     */   }
/*     */   
/*     */   public void setupDynamicUniforms(Runnable dynamicSetBlock) {
/* 243 */     setupDynamicUniforms(0, dynamicSetBlock);
/*     */   }
/*     */   
/*     */   public void setupDynamicUniforms(int index, Runnable dynamicSetBlock) {
/* 247 */     AccessiblePassesShaderEffect sg = (AccessiblePassesShaderEffect)getShaderEffect();
/* 248 */     if (sg != null) {
/* 249 */       class_280 sm = ((class_283)sg.getPasses().get(index)).method_1295();
/* 250 */       ShaderPrograms.useShader(sm.method_1270());
/* 251 */       dynamicSetBlock.run();
/* 252 */       ShaderPrograms.useShader(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean setupUniform(ManagedUniformBase uniform, class_279 shader) {
/* 258 */     return uniform.findUniformTargets(((AccessiblePassesShaderEffect)shader).getPasses());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void logInitError(IOException e) {
/* 263 */     Satin.LOGGER.error("Could not create screen shader {}", getLocation(), e);
/*     */   }
/*     */   @Nullable
/*     */   private class_279 getShaderOrLog() {
/* 267 */     if (!isInitialized() && !isErrored()) {
/* 268 */       initializeOrLog((class_5912)class_310.method_1551().method_1478());
/*     */     }
/* 270 */     return this.shader;
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/ResettableManagedShaderEffect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */