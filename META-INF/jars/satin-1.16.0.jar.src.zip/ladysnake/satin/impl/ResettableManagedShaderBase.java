/*     */ package ladysnake.satin.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import javax.annotation.CheckForNull;
/*     */ import ladysnake.satin.Satin;
/*     */ import ladysnake.satin.api.managed.uniform.Uniform1f;
/*     */ import ladysnake.satin.api.managed.uniform.Uniform1i;
/*     */ import ladysnake.satin.api.managed.uniform.Uniform2f;
/*     */ import ladysnake.satin.api.managed.uniform.Uniform2i;
/*     */ import ladysnake.satin.api.managed.uniform.Uniform3f;
/*     */ import ladysnake.satin.api.managed.uniform.Uniform3i;
/*     */ import ladysnake.satin.api.managed.uniform.Uniform4f;
/*     */ import ladysnake.satin.api.managed.uniform.Uniform4i;
/*     */ import ladysnake.satin.api.managed.uniform.UniformFinder;
/*     */ import ladysnake.satin.api.managed.uniform.UniformMat4;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_5912;
/*     */ import org.apiguardian.api.API;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResettableManagedShaderBase<S extends AutoCloseable>
/*     */   implements UniformFinder
/*     */ {
/*     */   private final class_2960 location;
/*  50 */   private final Map<String, ManagedUniform> managedUniforms = new HashMap<>();
/*  51 */   private final List<ManagedUniformBase> allUniforms = new ArrayList<>();
/*     */   private boolean errored;
/*     */   @CheckForNull
/*     */   protected S shader;
/*     */   
/*     */   public ResettableManagedShaderBase(class_2960 location) {
/*  57 */     this.location = location;
/*     */   }
/*     */   
/*     */   @API(status = API.Status.INTERNAL)
/*     */   public void initializeOrLog(class_5912 mgr) {
/*     */     try {
/*  63 */       initialize(mgr);
/*  64 */     } catch (IOException e) {
/*  65 */       this.errored = true;
/*  66 */       logInitError(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize(class_5912 resourceManager) throws IOException {
/*  73 */     release();
/*  74 */     class_310 mc = class_310.method_1551();
/*  75 */     this.shader = parseShader(resourceManager, mc, this.location);
/*  76 */     setup(mc.method_22683().method_4489(), mc.method_22683().method_4506());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/*  82 */     if (isInitialized()) {
/*     */       try {
/*  84 */         assert this.shader != null;
/*  85 */         this.shader.close();
/*  86 */         this.shader = null;
/*  87 */       } catch (Exception e) {
/*  88 */         throw new RuntimeException("Failed to release shader " + this.location, e);
/*     */       } 
/*     */     }
/*  91 */     this.errored = false;
/*     */   }
/*     */   
/*     */   protected Collection<ManagedUniformBase> getManagedUniforms() {
/*  95 */     return this.allUniforms;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInitialized() {
/* 101 */     return (this.shader != null);
/*     */   }
/*     */   
/*     */   public boolean isErrored() {
/* 105 */     return this.errored;
/*     */   }
/*     */   
/*     */   public class_2960 getLocation() {
/* 109 */     return this.location;
/*     */   }
/*     */   
/*     */   protected <U extends ManagedUniformBase> U manageUniform(Map<String, U> uniformMap, Function<String, U> factory, String uniformName, String uniformKind) {
/* 113 */     ManagedUniformBase managedUniformBase1 = (ManagedUniformBase)uniformMap.get(uniformName);
/* 114 */     if (managedUniformBase1 != null) {
/* 115 */       return (U)managedUniformBase1;
/*     */     }
/* 117 */     ManagedUniformBase managedUniformBase2 = (ManagedUniformBase)factory.apply(uniformName);
/* 118 */     if (this.shader != null) {
/* 119 */       boolean found = setupUniform(managedUniformBase2, this.shader);
/* 120 */       if (!found) {
/* 121 */         Satin.LOGGER.warn("No {} found with name {} in shader {}", uniformKind, uniformName, this.location);
/*     */       }
/*     */     } 
/* 124 */     uniformMap.put(uniformName, (U)managedUniformBase2);
/* 125 */     this.allUniforms.add(managedUniformBase2);
/* 126 */     return (U)managedUniformBase2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Uniform1i findUniform1i(String uniformName) {
/* 131 */     return manageUniform((Map)this.managedUniforms, name -> new ManagedUniform(name, 1), uniformName, "uniform");
/*     */   }
/*     */ 
/*     */   
/*     */   public Uniform2i findUniform2i(String uniformName) {
/* 136 */     return manageUniform((Map)this.managedUniforms, name -> new ManagedUniform(name, 2), uniformName, "uniform");
/*     */   }
/*     */ 
/*     */   
/*     */   public Uniform3i findUniform3i(String uniformName) {
/* 141 */     return manageUniform((Map)this.managedUniforms, name -> new ManagedUniform(name, 3), uniformName, "uniform");
/*     */   }
/*     */ 
/*     */   
/*     */   public Uniform4i findUniform4i(String uniformName) {
/* 146 */     return manageUniform((Map)this.managedUniforms, name -> new ManagedUniform(name, 4), uniformName, "uniform");
/*     */   }
/*     */ 
/*     */   
/*     */   public Uniform1f findUniform1f(String uniformName) {
/* 151 */     return manageUniform((Map)this.managedUniforms, name -> new ManagedUniform(name, 1), uniformName, "uniform");
/*     */   }
/*     */ 
/*     */   
/*     */   public Uniform2f findUniform2f(String uniformName) {
/* 156 */     return manageUniform((Map)this.managedUniforms, name -> new ManagedUniform(name, 2), uniformName, "uniform");
/*     */   }
/*     */ 
/*     */   
/*     */   public Uniform3f findUniform3f(String uniformName) {
/* 161 */     return manageUniform((Map)this.managedUniforms, name -> new ManagedUniform(name, 3), uniformName, "uniform");
/*     */   }
/*     */ 
/*     */   
/*     */   public Uniform4f findUniform4f(String uniformName) {
/* 166 */     return (Uniform4f)manageUniform(this.managedUniforms, name -> new ManagedUniform(name, 4), uniformName, "uniform");
/*     */   }
/*     */ 
/*     */   
/*     */   public UniformMat4 findUniformMat4(String uniformName) {
/* 171 */     return manageUniform((Map)this.managedUniforms, name -> new ManagedUniform(name, 16), uniformName, "uniform");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 179 */     return "%s[%s]".formatted(new Object[] { getClass().getSimpleName(), this.location });
/*     */   }
/*     */   
/*     */   protected abstract void logInitError(IOException paramIOException);
/*     */   
/*     */   protected abstract S parseShader(class_5912 paramclass_5912, class_310 paramclass_310, class_2960 paramclass_2960) throws IOException;
/*     */   
/*     */   protected abstract boolean setupUniform(ManagedUniformBase paramManagedUniformBase, S paramS);
/*     */   
/*     */   @API(status = API.Status.INTERNAL)
/*     */   public abstract void setup(int paramInt1, int paramInt2);
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/satin-1.16.0.jar!/ladysnake/satin/impl/ResettableManagedShaderBase.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */