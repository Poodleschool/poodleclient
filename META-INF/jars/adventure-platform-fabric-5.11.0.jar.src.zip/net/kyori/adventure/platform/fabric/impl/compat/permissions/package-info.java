/**
 * Provides hooks to expose permissions API functionality to Adventure API users.
 */
package net.kyori.adventure.platform.fabric.impl.compat.permissions;
