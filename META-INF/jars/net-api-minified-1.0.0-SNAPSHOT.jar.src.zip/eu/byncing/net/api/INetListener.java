package eu.byncing.net.api;

import eu.byncing.net.api.channel.INetChannel;
import eu.byncing.net.api.protocol.packet.EmptyPacket;

public interface INetListener {
  void handleConnected(INetChannel paramINetChannel);
  
  void handleDisconnected(INetChannel paramINetChannel);
  
  void handlePacket(INetChannel paramINetChannel, EmptyPacket paramEmptyPacket);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/INetListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */