/*     */ package eu.byncing.net.api;
/*     */ import eu.byncing.net.api.channel.INetChannel;
/*     */ import eu.byncing.net.api.channel.NettyChannel;
/*     */ import eu.byncing.net.api.protocol.VarInt21FrameDecoder;
/*     */ import eu.byncing.net.api.protocol.VarInt21LengthFieldPrepender;
/*     */ import eu.byncing.net.api.protocol.packet.EmptyPacket;
/*     */ import eu.byncing.net.api.protocol.packet.codec.PacketDecoder;
/*     */ import eu.byncing.net.api.protocol.packet.codec.PacketEncoder;
/*     */ import io.netty.bootstrap.ServerBootstrap;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.SimpleChannelInboundHandler;
/*     */ import io.netty.channel.nio.NioEventLoopGroup;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public class NetServer implements INetStructure {
/*  23 */   private final List<INetListener> listeners = new ArrayList<>();
/*     */   
/*  25 */   private final Collection<INetChannel> channels = new ConcurrentLinkedQueue<>();
/*     */   
/*     */   private Channel channel;
/*     */   
/*     */   public void bind(int port) {
/*  30 */     (new Thread(() -> {
/*     */           NioEventLoopGroup nioEventLoopGroup1 = new NioEventLoopGroup();
/*     */           
/*     */           NioEventLoopGroup nioEventLoopGroup2 = new NioEventLoopGroup();
/*     */           try {
/*     */             ServerBootstrap b = new ServerBootstrap();
/*     */             ((ServerBootstrap)((ServerBootstrap)b.group((EventLoopGroup)nioEventLoopGroup1, (EventLoopGroup)nioEventLoopGroup2).channel(NioServerSocketChannel.class)).childHandler((ChannelHandler)new ChannelInitializer<SocketChannel>()
/*     */                 {
/*     */                   public void initChannel(SocketChannel ch)
/*     */                   {
/*  40 */                     ch.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)new VarInt21FrameDecoder(), (ChannelHandler)new PacketDecoder(), (ChannelHandler)new VarInt21LengthFieldPrepender(), (ChannelHandler)new PacketEncoder(), (ChannelHandler)new SimpleChannelInboundHandler<EmptyPacket>()
/*     */                           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                             
/*     */                             public void handlerAdded(ChannelHandlerContext ctx)
/*     */                             {
/*  49 */                               if (!NetServer.this.isConnected())
/*  50 */                                 return;  NettyChannel channel = new NettyChannel(ctx.channel());
/*  51 */                               NetServer.this.getChannels().add(channel);
/*  52 */                               NetServer.this.listeners.forEach(listener -> listener.handleConnected((INetChannel)channel));
/*     */                             }
/*     */ 
/*     */                             
/*     */                             public void handlerRemoved(ChannelHandlerContext ctx) {
/*  57 */                               if (!NetServer.this.isConnected())
/*  58 */                                 return;  INetChannel channel = NetServer.this.getChannel(ctx.channel());
/*  59 */                               if (channel == null)
/*  60 */                                 return;  NetServer.this.getChannels().remove(channel);
/*  61 */                               NetServer.this.listeners.forEach(listener -> listener.handleDisconnected(channel));
/*     */                             }
/*     */ 
/*     */                             
/*     */                             protected void channelRead0(ChannelHandlerContext ctx, EmptyPacket msg) {
/*  66 */                               if (!NetServer.this.isConnected())
/*  67 */                                 return;  INetChannel channel = NetServer.this.getChannel(ctx.channel());
/*  68 */                               if (channel == null)
/*  69 */                                 return;  NetServer.this.listeners.forEach(listener -> listener.handlePacket(channel, msg));
/*     */                             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                             
/*     */                             public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {}
/*     */                           } });
/*     */                   }
/*     */                 }).option(ChannelOption.SO_BACKLOG, Integer.valueOf(128))).childOption(ChannelOption.SO_KEEPALIVE, Boolean.valueOf(true));
/*     */             ChannelFuture f = b.bind(port).sync();
/*     */             this.channel = f.channel();
/*     */             this.channel.closeFuture().sync();
/*  83 */           } catch (Exception e) {
/*     */             e.printStackTrace();
/*     */           } finally {
/*     */             nioEventLoopGroup2.shutdownGracefully();
/*     */             nioEventLoopGroup1.shutdownGracefully();
/*     */           } 
/*  89 */         })).start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  94 */     if (isConnected()) {
/*  95 */       for (INetChannel channel : this.channels) channel.close(); 
/*  96 */       this.channel.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void sendPacket(EmptyPacket packet) {
/* 102 */     if (isConnected())
/* 103 */       return;  this.channels.forEach(channel -> channel.sendPacket(packet));
/*     */   }
/*     */ 
/*     */   
/*     */   public NetServer addListener(INetListener listener) {
/* 108 */     this.listeners.add(listener);
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConnected() {
/* 114 */     return (this.channel != null && this.channel.isActive());
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<INetListener> getListeners() {
/* 119 */     return this.listeners;
/*     */   }
/*     */   
/*     */   public Collection<INetChannel> getChannels() {
/* 123 */     return this.channels;
/*     */   }
/*     */   
/*     */   private INetChannel getChannel(Channel channel) {
/* 127 */     return this.channels.stream().filter(iNetChannel -> iNetChannel.getSocket().equals(channel)).findFirst().orElse(null);
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/NetServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */