package eu.byncing.net.api;

import eu.byncing.net.api.protocol.packet.EmptyPacket;
import eu.byncing.net.api.protocol.packet.IPacketSender;
import java.io.Closeable;
import java.util.Collection;

public interface INetStructure extends Closeable, IPacketSender {
  void close();
  
  void sendPacket(EmptyPacket paramEmptyPacket);
  
  INetStructure addListener(INetListener paramINetListener);
  
  boolean isConnected();
  
  Collection<INetListener> getListeners();
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/INetStructure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */