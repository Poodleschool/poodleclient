/*     */ package eu.byncing.net.api;
/*     */ import eu.byncing.net.api.channel.INetChannel;
/*     */ import eu.byncing.net.api.channel.NettyChannel;
/*     */ import eu.byncing.net.api.protocol.VarInt21FrameDecoder;
/*     */ import eu.byncing.net.api.protocol.VarInt21LengthFieldPrepender;
/*     */ import eu.byncing.net.api.protocol.packet.EmptyPacket;
/*     */ import eu.byncing.net.api.protocol.packet.codec.PacketDecoder;
/*     */ import eu.byncing.net.api.protocol.packet.codec.PacketEncoder;
/*     */ import io.netty.bootstrap.Bootstrap;
/*     */ import io.netty.channel.Channel;
/*     */ import io.netty.channel.ChannelFuture;
/*     */ import io.netty.channel.ChannelHandler;
/*     */ import io.netty.channel.ChannelHandlerContext;
/*     */ import io.netty.channel.ChannelInitializer;
/*     */ import io.netty.channel.ChannelOption;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.SimpleChannelInboundHandler;
/*     */ import io.netty.channel.nio.NioEventLoopGroup;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ 
/*     */ public class NetClient implements INetStructure {
/*  22 */   private final List<INetListener> listeners = new ArrayList<>();
/*     */   
/*     */   private INetChannel channel;
/*     */   
/*     */   public void connect(String host, int port) {
/*  27 */     (new Thread(() -> {
/*     */           NioEventLoopGroup nioEventLoopGroup = new NioEventLoopGroup();
/*     */           try {
/*     */             Bootstrap b = new Bootstrap();
/*     */             b.group((EventLoopGroup)nioEventLoopGroup);
/*     */             b.channel(NioSocketChannel.class);
/*     */             b.option(ChannelOption.SO_KEEPALIVE, Boolean.valueOf(true));
/*     */             b.handler((ChannelHandler)new ChannelInitializer<SocketChannel>()
/*     */                 {
/*     */                   public void initChannel(SocketChannel ch) {
/*  37 */                     NetClient.this.channel = (INetChannel)new NettyChannel((Channel)ch);
/*  38 */                     ch.pipeline().addLast(new ChannelHandler[] { (ChannelHandler)new VarInt21FrameDecoder(), (ChannelHandler)new PacketDecoder(), (ChannelHandler)new VarInt21LengthFieldPrepender(), (ChannelHandler)new PacketEncoder(), (ChannelHandler)new SimpleChannelInboundHandler<EmptyPacket>()
/*     */                           {
/*     */ 
/*     */ 
/*     */ 
/*     */                             
/*     */                             public void channelActive(ChannelHandlerContext ctx)
/*     */                             {
/*  46 */                               ctx.fireChannelActive();
/*  47 */                               NetClient.this.getListeners().forEach(listener -> listener.handleConnected(NetClient.this.channel));
/*     */                             }
/*     */ 
/*     */                             
/*     */                             public void channelInactive(ChannelHandlerContext ctx) {
/*  52 */                               ctx.fireChannelInactive();
/*  53 */                               NetClient.this.getListeners().forEach(listener -> listener.handleDisconnected(NetClient.this.channel));
/*     */                             }
/*     */ 
/*     */                             
/*     */                             protected void channelRead0(ChannelHandlerContext ctx, EmptyPacket msg) {
/*  58 */                               NetClient.this.listeners.forEach(listener -> listener.handlePacket(NetClient.this.channel, msg));
/*     */                             }
/*     */ 
/*     */ 
/*     */                             
/*     */                             public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {}
/*     */                           } });
/*     */                   }
/*     */                 });
/*     */             ChannelFuture f = b.connect(host, port).sync();
/*     */             f.channel().closeFuture().sync();
/*  69 */           } catch (Exception exception) {
/*     */             exception.printStackTrace();
/*     */           } finally {
/*     */             nioEventLoopGroup.shutdownGracefully();
/*     */           } 
/*  74 */         })).start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/*  79 */     if (isConnected()) this.channel.close();
/*     */   
/*     */   }
/*     */   
/*     */   public void sendPacket(EmptyPacket packet) {
/*  84 */     if (isConnected()) this.channel.sendPacket(packet);
/*     */   
/*     */   }
/*     */   
/*     */   public NetClient addListener(INetListener listener) {
/*  89 */     this.listeners.add(listener);
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConnected() {
/*  95 */     return (this.channel != null && this.channel.isConnected());
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<INetListener> getListeners() {
/* 100 */     return this.listeners;
/*     */   }
/*     */   
/*     */   public INetChannel getChannel() {
/* 104 */     return this.channel;
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/NetClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */