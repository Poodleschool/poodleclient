/*    */ package eu.byncing.net.api.protocol;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.ByteToMessageDecoder;
/*    */ import io.netty.handler.codec.CorruptedFrameException;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class VarInt21FrameDecoder
/*    */   extends ByteToMessageDecoder
/*    */ {
/*    */   private static boolean DIRECT_WARNING;
/*    */   
/*    */   protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
/* 17 */     if (!ctx.channel().isActive()) {
/* 18 */       in.skipBytes(in.readableBytes());
/*    */       return;
/*    */     } 
/* 21 */     in.markReaderIndex();
/* 22 */     byte[] buf = new byte[3];
/* 23 */     for (int i = 0; i < buf.length; i++) {
/* 24 */       if (!in.isReadable()) {
/* 25 */         in.resetReaderIndex();
/*    */         return;
/*    */       } 
/* 28 */       buf[i] = in.readByte();
/* 29 */       if (buf[i] >= 0) {
/* 30 */         int length = ProtocolUtil.readVarInt(Unpooled.wrappedBuffer(buf));
/* 31 */         if (length == 0) throw new CorruptedFrameException("Empty Packet!"); 
/* 32 */         if (in.readableBytes() < length) { in.resetReaderIndex(); }
/*    */         
/* 34 */         else if (in.hasMemoryAddress())
/* 35 */         { out.add(in.slice(in.readerIndex(), length).retain());
/* 36 */           in.skipBytes(length); }
/*    */         else
/* 38 */         { if (!DIRECT_WARNING) {
/* 39 */             DIRECT_WARNING = true;
/* 40 */             System.out.println("Netty is not using direct IO buffers.");
/*    */           } 
/* 42 */           ByteBuf dst = ctx.alloc().directBuffer(length);
/* 43 */           in.readBytes(dst);
/* 44 */           out.add(dst); }
/*    */ 
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/* 50 */     throw new CorruptedFrameException("length wider than 21-bit");
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/protocol/VarInt21FrameDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */