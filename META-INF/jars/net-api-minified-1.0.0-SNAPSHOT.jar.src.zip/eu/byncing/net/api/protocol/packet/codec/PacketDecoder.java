/*    */ package eu.byncing.net.api.protocol.packet.codec;
/*    */ 
/*    */ import eu.byncing.net.api.protocol.packet.EmptyPacket;
/*    */ import eu.byncing.net.api.protocol.packet.buffer.IPacketBuffer;
/*    */ import eu.byncing.net.api.protocol.packet.buffer.PacketBuffer;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.MessageToMessageDecoder;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ public class PacketDecoder
/*    */   extends MessageToMessageDecoder<ByteBuf>
/*    */ {
/*    */   protected void decode(ChannelHandlerContext ctx, ByteBuf msg, List<Object> out) {
/* 16 */     if (!ctx.channel().isActive())
/* 17 */       return;  ByteBuf slice = msg.copy();
/*    */     try {
/* 19 */       PacketBuffer packetBuffer = new PacketBuffer(slice);
/* 20 */       EmptyPacket packet = EmptyPacket.newInstance((IPacketBuffer)packetBuffer);
/* 21 */       if (packet != null)
/* 22 */       { packet.read((IPacketBuffer)packetBuffer);
/* 23 */         out.add(packet); }
/* 24 */       else { msg.skipBytes(msg.readableBytes()); }
/* 25 */        slice = null;
/*    */     } finally {
/* 27 */       if (slice != null) slice.release(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/protocol/packet/codec/PacketDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */