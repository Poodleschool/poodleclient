/*    */ package eu.byncing.net.api.protocol;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.MessageToByteEncoder;
/*    */ 
/*    */ public class VarInt21LengthFieldPrepender
/*    */   extends MessageToByteEncoder<ByteBuf>
/*    */ {
/*    */   protected void encode(ChannelHandlerContext ctx, ByteBuf msg, ByteBuf out) {
/* 11 */     int bodyLen = msg.readableBytes();
/* 12 */     int headerLen = varIntSize(bodyLen);
/* 13 */     out.ensureWritable(headerLen + bodyLen);
/*    */     
/* 15 */     ProtocolUtil.writeVarInt(bodyLen, out);
/* 16 */     out.writeBytes(msg);
/*    */   }
/*    */   
/*    */   private static int varIntSize(int paramInt) {
/* 20 */     if ((paramInt & 0xFFFFFF80) == 0) return 1; 
/* 21 */     if ((paramInt & 0xFFFFC000) == 0) return 2; 
/* 22 */     if ((paramInt & 0xFFE00000) == 0) return 3; 
/* 23 */     if ((paramInt & 0xF0000000) == 0) return 4; 
/* 24 */     return 5;
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/protocol/VarInt21LengthFieldPrepender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */