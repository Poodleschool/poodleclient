/*    */ package eu.byncing.net.api.protocol;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ 
/*    */ 
/*    */ public class ProtocolUtil
/*    */ {
/*    */   public static void writeVarInt(int value, ByteBuf output) {
/*    */     do {
/* 10 */       int part = value & 0x7F;
/* 11 */       value >>>= 7;
/* 12 */       if (value != 0) {
/* 13 */         part |= 0x80;
/*    */       }
/* 15 */       output.writeByte(part);
/* 16 */     } while (value != 0);
/*    */   }
/*    */   
/*    */   public static int readVarInt(ByteBuf input) {
/* 20 */     return readVarInt(input, 5);
/*    */   }
/*    */   
/*    */   public static int readVarInt(ByteBuf input, int maxBytes) {
/* 24 */     int out = 0, bytes = 0;
/*    */     
/*    */     while (true) {
/* 27 */       byte in = input.readByte();
/* 28 */       out |= (in & Byte.MAX_VALUE) << bytes++ * 7;
/* 29 */       if (bytes > maxBytes) throw new RuntimeException("VarInt too big"); 
/* 30 */       if ((in & 0x80) != 128)
/* 31 */         return out; 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/protocol/ProtocolUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */