/*    */ package eu.byncing.net.api.protocol.packet;
/*    */ 
/*    */ import eu.byncing.net.api.protocol.packet.buffer.IPacketBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EmptyPacket
/*    */ {
/*    */   public static <P extends EmptyPacket> P typeInstance(EmptyPacket packet) {
/* 10 */     return (P)packet;
/*    */   }
/*    */   
/*    */   public static <P extends EmptyPacket> P newInstance(IPacketBuffer buffer) {
/* 14 */     String clazz = buffer.readString();
/* 15 */     if (clazz != null && clazz.length() > 0) {
/*    */       try {
/* 17 */         return (P)Class.forName(clazz).getConstructor(new Class[0]).newInstance(new Object[0]);
/* 18 */       } catch (InstantiationException|IllegalAccessException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|ClassNotFoundException e) {
/* 19 */         e.printStackTrace();
/*    */       } 
/*    */     }
/* 22 */     return null;
/*    */   }
/*    */   
/*    */   public abstract void write(IPacketBuffer paramIPacketBuffer);
/*    */   
/*    */   public abstract void read(IPacketBuffer paramIPacketBuffer);
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/protocol/packet/EmptyPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */