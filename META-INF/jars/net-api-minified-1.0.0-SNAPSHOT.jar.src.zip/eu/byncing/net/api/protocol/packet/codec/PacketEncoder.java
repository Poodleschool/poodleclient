/*    */ package eu.byncing.net.api.protocol.packet.codec;
/*    */ 
/*    */ import eu.byncing.net.api.protocol.packet.EmptyPacket;
/*    */ import eu.byncing.net.api.protocol.packet.buffer.IPacketBuffer;
/*    */ import eu.byncing.net.api.protocol.packet.buffer.PacketBuffer;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.channel.ChannelHandlerContext;
/*    */ import io.netty.handler.codec.MessageToByteEncoder;
/*    */ 
/*    */ public class PacketEncoder
/*    */   extends MessageToByteEncoder<EmptyPacket>
/*    */ {
/*    */   protected void encode(ChannelHandlerContext ctx, EmptyPacket msg, ByteBuf out) {
/* 14 */     PacketBuffer packetBuffer = new PacketBuffer(out);
/* 15 */     packetBuffer.writeString(msg.getClass().getName());
/* 16 */     msg.write((IPacketBuffer)packetBuffer);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/protocol/packet/codec/PacketEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */