/*     */ package eu.byncing.net.api.protocol.packet.buffer;
/*     */ 
/*     */ import io.netty.buffer.ByteBuf;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ public class PacketBuffer
/*     */   implements IPacketBuffer
/*     */ {
/*     */   private final ByteBuf buf;
/*     */   
/*     */   public PacketBuffer(ByteBuf buf) {
/*  16 */     this.buf = buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeString(String s) {
/*  21 */     if (s.length() > 32767) {
/*  22 */       throw new RuntimeException("Cannot send string longer than Short.MAX_VALUE (got " + s.length() + " characters)");
/*     */     }
/*  24 */     byte[] b = s.getBytes(StandardCharsets.UTF_8);
/*  25 */     writeInt(b.length);
/*  26 */     this.buf.writeBytes(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public String readString() {
/*  31 */     return readString(32767);
/*     */   }
/*     */ 
/*     */   
/*     */   public String readString(int maxLen) {
/*  36 */     int len = readInt();
/*  37 */     if (len > maxLen * 4) {
/*  38 */       throw new RuntimeException("Cannot receive string longer than " + (maxLen * 4) + " (got " + len + " bytes)");
/*     */     }
/*  40 */     byte[] b = new byte[len];
/*  41 */     this.buf.readBytes(b);
/*  42 */     String s = new String(b, StandardCharsets.UTF_8);
/*  43 */     if (s.length() > maxLen) {
/*  44 */       throw new RuntimeException("Cannot receive string longer than " + maxLen + " (got " + s.length() + " characters)");
/*     */     }
/*     */     
/*  47 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeArray(byte[] b) {
/*  52 */     if (b.length > 32767) {
/*  53 */       throw new RuntimeException("Cannot send byte array longer than Short.MAX_VALUE (got " + b.length + " bytes)");
/*     */     }
/*  55 */     writeInt(b.length);
/*  56 */     this.buf.writeBytes(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] toArray() {
/*  61 */     byte[] ret = new byte[this.buf.readableBytes()];
/*  62 */     this.buf.readBytes(ret);
/*  63 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] readArray() {
/*  68 */     return readArray(this.buf.readableBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] readArray(int limit) {
/*  73 */     int len = readInt();
/*  74 */     if (len > limit) {
/*  75 */       throw new RuntimeException("Cannot receive byte array longer than " + limit + " (got " + len + " bytes)");
/*     */     }
/*  77 */     byte[] ret = new byte[len];
/*  78 */     this.buf.readBytes(ret);
/*  79 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] readIntArray() {
/*  84 */     int len = readInt();
/*  85 */     int[] ret = new int[len];
/*  86 */     for (int i = 0; i < len; ) { ret[i] = readInt(); i++; }
/*  87 */      return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStringArray(List<String> s) {
/*  92 */     writeInt(s.size());
/*  93 */     for (String str : s) {
/*  94 */       writeString(str);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> readStringArray() {
/* 100 */     int len = readInt();
/* 101 */     List<String> ret = new ArrayList<>(len);
/* 102 */     for (int i = 0; i < len; ) { ret.add(readString()); i++; }
/* 103 */      return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt() {
/* 108 */     return readInt(5);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readInt(int maxBytes) {
/* 113 */     int out = 0, bytes = 0;
/*     */     
/*     */     while (true) {
/* 116 */       byte in = this.buf.readByte();
/* 117 */       out |= (in & Byte.MAX_VALUE) << bytes++ * 7;
/* 118 */       if (bytes > maxBytes) throw new RuntimeException("VarInt too big"); 
/* 119 */       if ((in & 0x80) != 128) {
/* 120 */         return out;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeInt(int value) {
/*     */     do {
/* 127 */       int part = value & 0x7F;
/* 128 */       value >>>= 7;
/* 129 */       if (value != 0) part |= 0x80; 
/* 130 */       this.buf.writeByte(part);
/* 131 */     } while (value != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBoolean(boolean bool) {
/* 136 */     int value = 0;
/* 137 */     if (bool) value = 1; 
/* 138 */     writeInt(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean readBoolean() {
/* 143 */     return (readInt() == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readShort() {
/* 148 */     int low = this.buf.readUnsignedShort();
/* 149 */     int high = 0;
/* 150 */     if ((low & 0x8000) != 0) {
/* 151 */       low &= 0x7FFF;
/* 152 */       high = this.buf.readUnsignedByte();
/*     */     } 
/* 154 */     return (high & 0xFF) << 15 | low;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeShort(int toWrite) {
/* 159 */     int low = toWrite & 0x7FFF;
/* 160 */     int high = (toWrite & 0x7F8000) >> 15;
/* 161 */     if (high != 0) low |= 0x8000; 
/* 162 */     this.buf.writeShort(low);
/* 163 */     if (high != 0) {
/* 164 */       this.buf.writeByte(high);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeUUID(UUID value) {
/* 170 */     this.buf.writeLong(value.getMostSignificantBits());
/* 171 */     this.buf.writeLong(value.getLeastSignificantBits());
/*     */   }
/*     */ 
/*     */   
/*     */   public UUID readUUID() {
/* 176 */     return new UUID(this.buf.readLong(), this.buf.readLong());
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEnum(Enum<?> anEnum) {
/* 181 */     writeInt(anEnum.ordinal());
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Enum<E>> E readEnum(Class<E> enumClass) {
/* 186 */     int value = readInt();
/* 187 */     return (value != -1) ? (E)((Enum[])enumClass.getEnumConstants())[value] : null;
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/protocol/packet/buffer/PacketBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */