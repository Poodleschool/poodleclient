package eu.byncing.net.api.protocol.packet.buffer;

import java.util.List;
import java.util.UUID;

public interface IPacketBuffer {
  void writeString(String paramString);
  
  String readString();
  
  String readString(int paramInt);
  
  void writeArray(byte[] paramArrayOfbyte);
  
  byte[] toArray();
  
  byte[] readArray();
  
  byte[] readArray(int paramInt);
  
  int[] readIntArray();
  
  void writeStringArray(List<String> paramList);
  
  List<String> readStringArray();
  
  int readInt();
  
  int readInt(int paramInt);
  
  void writeInt(int paramInt);
  
  void writeBoolean(boolean paramBoolean);
  
  boolean readBoolean();
  
  int readShort();
  
  void writeShort(int paramInt);
  
  void writeUUID(UUID paramUUID);
  
  UUID readUUID();
  
  void writeEnum(Enum<?> paramEnum);
  
  <E extends Enum<E>> E readEnum(Class<E> paramClass);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/protocol/packet/buffer/IPacketBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */