/*    */ package eu.byncing.net.api.channel;
/*    */ 
/*    */ import eu.byncing.net.api.protocol.packet.EmptyPacket;
/*    */ import io.netty.channel.Channel;
/*    */ 
/*    */ public class NettyChannel
/*    */   implements INetChannel {
/*    */   private final Channel channel;
/*    */   
/*    */   public NettyChannel(Channel channel) {
/* 11 */     this.channel = channel;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 16 */     if (!isConnected())
/* 17 */       return;  this.channel.close();
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendPacket(EmptyPacket packet) {
/* 22 */     if (isConnected()) this.channel.writeAndFlush(packet);
/*    */   
/*    */   }
/*    */   
/*    */   public boolean isConnected() {
/* 27 */     return (this.channel != null && this.channel.isActive());
/*    */   }
/*    */ 
/*    */   
/*    */   public Channel getSocket() {
/* 32 */     return this.channel;
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/channel/NettyChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */