package eu.byncing.net.api.channel;

import eu.byncing.net.api.protocol.packet.EmptyPacket;
import eu.byncing.net.api.protocol.packet.IPacketSender;
import io.netty.channel.Channel;
import java.io.Closeable;

public interface INetChannel extends Closeable, IPacketSender {
  void close();
  
  void sendPacket(EmptyPacket paramEmptyPacket);
  
  boolean isConnected();
  
  Channel getSocket();
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/net-api-minified-1.0.0-SNAPSHOT.jar!/eu/byncing/net/api/channel/INetChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */