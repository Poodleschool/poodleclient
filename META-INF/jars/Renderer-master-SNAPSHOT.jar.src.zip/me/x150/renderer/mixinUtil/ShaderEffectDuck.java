package me.x150.renderer.mixinUtil;

import java.util.List;
import net.minecraft.class_276;
import net.minecraft.class_283;

public interface ShaderEffectDuck {
  void renderer$addFakeTarget(String paramString, class_276 paramclass_276);
  
  List<class_283> renderer$getPasses();
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/mixinUtil/ShaderEffectDuck.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */