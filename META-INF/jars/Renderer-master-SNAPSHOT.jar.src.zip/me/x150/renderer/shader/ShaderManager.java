/*   */ package me.x150.renderer.shader;
/*   */ 
/*   */ import ladysnake.satin.api.managed.ManagedShaderEffect;
/*   */ import ladysnake.satin.api.managed.ShaderEffectManager;
/*   */ import net.minecraft.class_2960;
/*   */ 
/*   */ public class ShaderManager {
/* 8 */   public static final ManagedShaderEffect OUTLINE_SHADER = ShaderEffectManager.getInstance()
/* 9 */     .manage(new class_2960("renderer", String.format("shaders/post/%s.json", new Object[] { "outline" })));
/*   */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/shader/ShaderManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */