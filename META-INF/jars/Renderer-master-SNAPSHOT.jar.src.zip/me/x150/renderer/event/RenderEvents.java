/*    */ package me.x150.renderer.event;
/*    */ 
/*    */ import net.fabricmc.fabric.api.event.Event;
/*    */ import net.fabricmc.fabric.api.event.EventFactory;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ public class RenderEvents {
/*  9 */   public static final Event<RenderEvent<class_4587>> WORLD = create();
/* 10 */   public static final Event<RenderEvent<class_332>> HUD = create();
/*    */   
/*    */   private static <T> Event<RenderEvent<T>> create() {
/* 13 */     return EventFactory.createArrayBacked(RenderEvent.class, listeners -> ());
/*    */   }
/*    */   
/*    */   @FunctionalInterface
/*    */   public static interface RenderEvent<T> {
/*    */     void rendered(T param1T);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/event/RenderEvents.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */