package me.x150.renderer.event;

@FunctionalInterface
public interface RenderEvent<T> {
  void rendered(T paramT);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/event/RenderEvents$RenderEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */