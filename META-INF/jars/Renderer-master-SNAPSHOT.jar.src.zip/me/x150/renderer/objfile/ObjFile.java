/*     */ package me.x150.renderer.objfile;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import de.javagl.obj.FloatTuple;
/*     */ import de.javagl.obj.Mtl;
/*     */ import de.javagl.obj.MtlReader;
/*     */ import de.javagl.obj.Obj;
/*     */ import de.javagl.obj.ObjFace;
/*     */ import de.javagl.obj.ObjReader;
/*     */ import de.javagl.obj.ObjSplitting;
/*     */ import de.javagl.obj.ObjUtils;
/*     */ import de.javagl.obj.ReadableObj;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import javax.imageio.ImageIO;
/*     */ import me.x150.renderer.util.BufferUtils;
/*     */ import me.x150.renderer.util.RendererUtils;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_291;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_4588;
/*     */ import net.minecraft.class_5944;
/*     */ import net.minecraft.class_757;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fc;
/*     */ 
/*     */ public class ObjFile
/*     */   implements Closeable
/*     */ {
/*  47 */   final Map<Obj, class_291> buffers = new HashMap<>();
/*  48 */   final Map<String, class_2960> boundTextures = new HashMap<>();
/*     */   
/*     */   private final ResourceProvider provider;
/*     */   
/*     */   private final String name;
/*     */   
/*     */   Map<String, Obj> materialNameObjMap;
/*     */   
/*     */   private List<Mtl> allMaterials;
/*     */   
/*     */   private boolean baked = false;
/*     */   
/*     */   private boolean closed = false;
/*     */ 
/*     */   
/*     */   public ObjFile(String name, ResourceProvider provider) throws IOException {
/*  64 */     this.name = name;
/*  65 */     this.provider = provider;
/*  66 */     read();
/*     */   }
/*     */   
/*     */   private static class_243 transformVec3d(class_243 in) {
/*  70 */     class_4184 camera = (class_310.method_1551()).field_1773.method_19418();
/*  71 */     class_243 camPos = camera.method_19326();
/*  72 */     return in.method_1020(camPos);
/*     */   }
/*     */   
/*     */   private void read() throws IOException {
/*  76 */     InputStream reader = this.provider.open(this.name); 
/*  77 */     try { Obj r = ObjUtils.convertToRenderable((ReadableObj)ObjReader.read(reader));
/*  78 */       this.allMaterials = new ArrayList<>();
/*  79 */       for (String mtlFileName : r.getMtlFileNames()) {
/*  80 */         InputStream openReaderTo = this.provider.open(mtlFileName); 
/*  81 */         try { List<Mtl> read = MtlReader.read(openReaderTo);
/*  82 */           this.allMaterials.addAll(read);
/*  83 */           if (openReaderTo != null) openReaderTo.close();  } catch (Throwable throwable) { if (openReaderTo != null)
/*     */             try { openReaderTo.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/*  85 */       }  this.materialNameObjMap = ObjSplitting.splitByMaterialGroups((ReadableObj)r);
/*     */       
/*  87 */       if (reader != null) reader.close();  } catch (Throwable throwable) { if (reader != null)
/*     */         try { reader.close(); }
/*     */         catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */           throw throwable; }
/*  91 */      } private class_2960 createTex0(String s) { try { InputStream reader = this.provider.open(s); 
/*  92 */       try { class_2960 identifier = RendererUtils.randomIdentifier();
/*  93 */         BufferedImage read1 = ImageIO.read(reader);
/*  94 */         RendererUtils.registerBufferedImageTexture(identifier, read1);
/*  95 */         class_2960 class_29601 = identifier;
/*  96 */         if (reader != null) reader.close();  return class_29601; } catch (Throwable throwable) { if (reader != null) try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/*  97 */     { throw new RuntimeException(e); }
/*     */      }
/*     */ 
/*     */   
/*     */   private void bake() {
/* 102 */     class_287 b = class_289.method_1348().method_1349();
/* 103 */     for (Map.Entry<String, Obj> stringObjEntry : this.materialNameObjMap.entrySet()) {
/* 104 */       class_293 vmf; String materialName = stringObjEntry.getKey();
/* 105 */       Obj objToDraw = stringObjEntry.getValue();
/* 106 */       Mtl material = this.allMaterials.stream().filter(f -> f.getName().equals(materialName)).findFirst().orElse(null);
/* 107 */       boolean hasTexture = (material != null && material.getMapKd() != null);
/* 108 */       if (hasTexture) {
/* 109 */         String mapKd = material.getMapKd();
/* 110 */         this.boundTextures.computeIfAbsent(mapKd, this::createTex0);
/*     */       } 
/*     */       
/* 113 */       if (material != null) {
/* 114 */         vmf = hasTexture ? class_290.field_1577 : class_290.field_1576;
/*     */       } else {
/* 116 */         vmf = class_290.field_1592;
/*     */       } 
/* 118 */       b.method_1328(class_293.class_5596.field_27379, vmf);
/* 119 */       for (int i = 0; i < objToDraw.getNumFaces(); i++) {
/* 120 */         ObjFace face = objToDraw.getFace(i);
/* 121 */         boolean hasNormals = face.containsNormalIndices();
/* 122 */         boolean hasUV = face.containsTexCoordIndices();
/* 123 */         for (int i1 = 0; i1 < face.getNumVertices(); i1++) {
/* 124 */           FloatTuple xyz = objToDraw.getVertex(face.getVertexIndex(i1));
/* 125 */           class_4588 vertex = b.method_22912(xyz.getX(), xyz.getY(), xyz.getZ());
/* 126 */           if (vmf == class_290.field_1577) {
/* 127 */             if (!hasUV) {
/* 128 */               throw new IllegalStateException("Diffuse texture present, vertex doesn't have UV coordinates. File corrupted?");
/*     */             }
/*     */             
/* 131 */             if (!hasNormals) {
/* 132 */               throw new IllegalStateException("Diffuse texture present, vertex doesn't have normal coordinates. File corrupted?");
/*     */             }
/*     */             
/* 135 */             FloatTuple uvs = objToDraw.getTexCoord(face.getTexCoordIndex(i1));
/* 136 */             vertex.method_22913(uvs.getX(), 1.0F - uvs.getY());
/*     */           } 
/* 138 */           if (vmf == class_290.field_1577 || vmf == class_290.field_1576) {
/* 139 */             Objects.requireNonNull(material);
/* 140 */             FloatTuple kd = material.getKd();
/* 141 */             if (kd != null) {
/* 142 */               vertex.method_22915(kd.getX(), kd.getY(), kd.getZ(), 1.0F);
/*     */             } else {
/* 144 */               vertex.method_22915(1.0F, 1.0F, 1.0F, 1.0F);
/*     */             } 
/*     */           } 
/* 147 */           if (vmf == class_290.field_1577) {
/* 148 */             FloatTuple normals = objToDraw.getNormal(face.getNormalIndex(i1));
/* 149 */             vertex.method_22914(normals.getX(), normals.getY(), normals.getZ());
/*     */           } 
/* 151 */           vertex.method_1344();
/*     */         } 
/*     */       } 
/* 154 */       class_287.class_7433 end = b.method_1326();
/* 155 */       this.buffers.put(objToDraw, BufferUtils.createVbo(end, class_291.class_8555.field_44793));
/*     */     } 
/* 157 */     this.baked = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void draw(class_4587 stack, Matrix4f viewMatrix, class_243 origin) {
/* 168 */     if (this.closed) {
/* 169 */       throw new IllegalStateException("Closed");
/*     */     }
/* 171 */     if (!this.baked) {
/* 172 */       bake();
/*     */     }
/* 174 */     class_243 o = transformVec3d(origin);
/* 175 */     Matrix4f projectionMatrix = RenderSystem.getProjectionMatrix();
/* 176 */     Matrix4f m4f = new Matrix4f((Matrix4fc)stack.method_23760().method_23761());
/* 177 */     m4f.translate((float)o.field_1352, (float)o.field_1351, (float)o.field_1350);
/* 178 */     m4f.mul((Matrix4fc)viewMatrix);
/*     */     
/* 180 */     RendererUtils.setupRender();
/* 181 */     RenderSystem.enableCull();
/* 182 */     for (Map.Entry<String, Obj> stringObjEntry : this.materialNameObjMap.entrySet()) {
/* 183 */       Supplier<class_5944> shader; String materialName = stringObjEntry.getKey();
/* 184 */       Obj obj = stringObjEntry.getValue();
/* 185 */       Mtl material = this.allMaterials.stream().filter(f -> f.getName().equals(materialName)).findFirst().orElse(null);
/* 186 */       boolean hasTexture = (material != null && material.getMapKd() != null);
/* 187 */       if (hasTexture) {
/* 188 */         String mapKd = material.getMapKd();
/* 189 */         class_2960 identifier = this.boundTextures.get(mapKd);
/* 190 */         RenderSystem.setShaderTexture(0, identifier);
/*     */       } 
/*     */       
/* 193 */       if (material != null) {
/* 194 */         shader = hasTexture ? class_757::method_34549 : class_757::method_34540;
/*     */       } else {
/* 196 */         shader = class_757::method_34539;
/*     */       } 
/* 198 */       class_291 vertexBuffer = this.buffers.get(obj);
/* 199 */       vertexBuffer.method_1353();
/* 200 */       vertexBuffer.method_34427(m4f, projectionMatrix, shader.get());
/*     */     } 
/* 202 */     class_291.method_1354();
/* 203 */     RendererUtils.endRender();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 211 */     for (class_291 buffer : this.buffers.values()) {
/* 212 */       buffer.close();
/*     */     }
/* 214 */     this.buffers.clear();
/* 215 */     for (class_2960 value : this.boundTextures.values()) {
/* 216 */       class_310.method_1551().method_1531().method_4615(value);
/*     */     }
/* 218 */     this.boundTextures.clear();
/* 219 */     this.allMaterials.clear();
/* 220 */     this.closed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface ResourceProvider
/*     */   {
/*     */     static ResourceProvider ofPath(Path parent) {
/* 235 */       return name -> {
/*     */           Path resolve = parent.resolve(name);
/*     */           return Files.newInputStream(resolve, new java.nio.file.OpenOption[0]);
/*     */         };
/*     */     }
/*     */     
/*     */     InputStream open(String param1String) throws IOException;
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/objfile/ObjFile.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */