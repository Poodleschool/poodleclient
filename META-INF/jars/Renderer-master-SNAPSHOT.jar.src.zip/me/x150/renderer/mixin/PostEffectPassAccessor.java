package me.x150.renderer.mixin;

import net.minecraft.class_276;
import net.minecraft.class_283;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_283.class})
public interface PostEffectPassAccessor {
  @Mutable
  @Accessor("input")
  void renderer_setInput(class_276 paramclass_276);
  
  @Mutable
  @Accessor("output")
  void renderer_setOutput(class_276 paramclass_276);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/mixin/PostEffectPassAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */