/*    */ package me.x150.renderer.mixin;
/*    */ 
/*    */ import java.util.List;
/*    */ import me.x150.renderer.util.RenderProfiler;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_340;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ @Mixin({class_340.class})
/*    */ public class DebugHudMixin
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_310 field_2079;
/*    */   
/*    */   @Inject(method = {"getLeftText"}, at = {@At("RETURN")})
/*    */   void addLeftText(CallbackInfoReturnable<List<String>> cir) {
/* 24 */     int currentFps = this.field_2079.method_47599();
/* 25 */     float currentFrameTime = 1.0E9F / currentFps;
/* 26 */     for (RenderProfiler.Entry allTickTime : RenderProfiler.getAllTickTimes()) {
/* 27 */       long t = allTickTime.end() - allTickTime.start();
/* 28 */       ((List<String>)cir.getReturnValue())
/* 29 */         .add(String.format("[Renderer bench] %s: %07d ns (%02.2f%% of frame)", new Object[] { allTickTime.name(), Long.valueOf(t), 
/* 30 */               Float.valueOf((float)t / currentFrameTime * 100.0F) }));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/mixin/DebugHudMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */