/*    */ package me.x150.renderer.mixin;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import me.x150.renderer.mixinUtil.ShaderEffectDuck;
/*    */ import net.minecraft.class_276;
/*    */ import net.minecraft.class_279;
/*    */ import net.minecraft.class_283;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({class_279.class})
/*    */ public class PostEffectProcessorMixin
/*    */   implements ShaderEffectDuck {
/*    */   @Unique
/* 22 */   private final List<String> renderer$fakedBuffers = new ArrayList<>();
/*    */   
/*    */   @Shadow
/*    */   @Final
/*    */   private Map<String, class_276> field_1495;
/*    */   
/*    */   @Shadow
/*    */   @Final
/*    */   private List<class_283> field_1497;
/*    */   
/*    */   public List<class_283> renderer$getPasses() {
/* 33 */     return this.field_1497;
/*    */   }
/*    */ 
/*    */   
/*    */   public void renderer$addFakeTarget(String name, class_276 buffer) {
/* 38 */     class_276 previousFramebuffer = this.field_1495.get(name);
/* 39 */     if (previousFramebuffer == buffer) {
/*    */       return;
/*    */     }
/* 42 */     if (previousFramebuffer != null) {
/* 43 */       for (class_283 pass : this.field_1497) {
/*    */         
/* 45 */         if (pass.field_1536 == previousFramebuffer) {
/* 46 */           ((PostEffectPassAccessor)pass).renderer_setInput(buffer);
/*    */         }
/* 48 */         if (pass.field_1538 == previousFramebuffer) {
/* 49 */           ((PostEffectPassAccessor)pass).renderer_setOutput(buffer);
/*    */         }
/*    */       } 
/* 52 */       this.field_1495.remove(name);
/* 53 */       this.renderer$fakedBuffers.remove(name);
/*    */     } 
/*    */     
/* 56 */     this.field_1495.put(name, buffer);
/* 57 */     this.renderer$fakedBuffers.add(name);
/*    */   }
/*    */   
/*    */   @Inject(method = {"close"}, at = {@At("HEAD")})
/*    */   void renderer_deleteFakeBuffers(CallbackInfo ci) {
/* 62 */     for (String fakedBufferName : this.renderer$fakedBuffers)
/* 63 */       this.field_1495.remove(fakedBufferName); 
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/mixin/PostEffectProcessorMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */