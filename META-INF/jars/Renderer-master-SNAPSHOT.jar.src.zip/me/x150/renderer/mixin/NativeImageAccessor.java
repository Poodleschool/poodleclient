package me.x150.renderer.mixin;

import net.minecraft.class_1011;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1011.class})
public interface NativeImageAccessor {
  @Accessor("pointer")
  long getPointer();
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/mixin/NativeImageAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */