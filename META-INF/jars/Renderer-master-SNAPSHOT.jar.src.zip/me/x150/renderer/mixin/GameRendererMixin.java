/*    */ package me.x150.renderer.mixin;
/*    */ 
/*    */ import com.mojang.blaze3d.systems.RenderSystem;
/*    */ import me.x150.renderer.event.RenderEvents;
/*    */ import me.x150.renderer.render.Renderer3d;
/*    */ import me.x150.renderer.util.RenderProfiler;
/*    */ import me.x150.renderer.util.RendererUtils;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_757;
/*    */ import org.joml.Matrix4fc;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ @Mixin({class_757.class})
/*    */ public abstract class GameRendererMixin
/*    */ {
/*    */   @Inject(at = {@At(value = "FIELD", target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z", opcode = 180, ordinal = 0)}, method = {"renderWorld"})
/*    */   void renderer_postWorldRender(float tickDelta, long limitTime, class_4587 matrix, CallbackInfo ci) {
/* 22 */     RenderProfiler.begin("World");
/*    */     
/* 24 */     RendererUtils.lastProjMat.set((Matrix4fc)RenderSystem.getProjectionMatrix());
/* 25 */     RendererUtils.lastModMat.set((Matrix4fc)RenderSystem.getModelViewMatrix());
/* 26 */     RendererUtils.lastWorldSpaceMatrix.set((Matrix4fc)matrix.method_23760().method_23761());
/* 27 */     ((RenderEvents.RenderEvent)RenderEvents.WORLD.invoker()).rendered(matrix);
/* 28 */     Renderer3d.renderFadingBlocks(matrix);
/*    */     
/* 30 */     RenderProfiler.pop();
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/mixin/GameRendererMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */