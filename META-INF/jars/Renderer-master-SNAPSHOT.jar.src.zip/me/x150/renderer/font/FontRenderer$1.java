/*    */ package me.x150.renderer.font;
/*    */ 
/*    */ import it.unimi.dsi.fastutil.chars.Char2IntArrayMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends Char2IntArrayMap
/*    */ {
/*    */   null() {
/* 51 */     put('0', 0);
/* 52 */     put('1', 170);
/* 53 */     put('2', 43520);
/* 54 */     put('3', 43690);
/* 55 */     put('4', 11141120);
/* 56 */     put('5', 11141290);
/* 57 */     put('6', 16755200);
/* 58 */     put('7', 11184810);
/* 59 */     put('8', 5592405);
/* 60 */     put('9', 5592575);
/* 61 */     put('A', 5635925);
/* 62 */     put('B', 5636095);
/* 63 */     put('C', 16733525);
/* 64 */     put('D', 16733695);
/* 65 */     put('E', 16777045);
/* 66 */     put('F', 16777215);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/font/FontRenderer$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */