/*     */ package me.x150.renderer.font;
/*     */ 
/*     */ import com.google.common.base.Preconditions;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import it.unimi.dsi.fastutil.chars.Char2IntArrayMap;
/*     */ import it.unimi.dsi.fastutil.chars.Char2ObjectArrayMap;
/*     */ import it.unimi.dsi.fastutil.objects.Object2ObjectMap;
/*     */ import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectArrayList;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectIterator;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectList;
/*     */ import it.unimi.dsi.fastutil.objects.ObjectListIterator;
/*     */ import java.awt.Font;
/*     */ import java.io.Closeable;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import lombok.NonNull;
/*     */ import me.x150.renderer.client.RendererMain;
/*     */ import me.x150.renderer.util.BufferUtils;
/*     */ import me.x150.renderer.util.Colors;
/*     */ import me.x150.renderer.util.RendererUtils;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_757;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.joml.Matrix4f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FontRenderer
/*     */   implements Closeable
/*     */ {
/*  50 */   private static final Char2IntArrayMap colorCodes = new Char2IntArrayMap()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private static final ExecutorService ASYNC_WORKER = Executors.newCachedThreadPool();
/*  69 */   private final Object2ObjectMap<class_2960, ObjectList<DrawEntry>> GLYPH_PAGE_CACHE = (Object2ObjectMap<class_2960, ObjectList<DrawEntry>>)new Object2ObjectOpenHashMap();
/*     */   private final float originalSize;
/*  71 */   private final ObjectList<GlyphMap> maps = (ObjectList<GlyphMap>)new ObjectArrayList();
/*  72 */   private final Char2ObjectArrayMap<Glyph> allGlyphs = new Char2ObjectArrayMap();
/*     */   private final int charsPerPage;
/*     */   private final int padding;
/*     */   private final String prebakeGlyphs;
/*  76 */   private int scaleMul = 0;
/*     */   private Font[] fonts;
/*  78 */   private int previousGameScale = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   private Future<Void> prebakeGlyphsFuture;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */ 
/*     */   
/*     */   public FontRenderer(@NonNull Font[] fonts, float sizePx, int charactersPerPage, int paddingBetweenCharacters, @Nullable String prebakeCharacters) {
/*  91 */     if (fonts == null) throw new NullPointerException("fonts is marked non-null but is null"); 
/*  92 */     Preconditions.checkArgument((sizePx > 0.0F), "sizePx <= 0");
/*  93 */     Preconditions.checkArgument((fonts.length > 0), "fonts.length <= 0");
/*  94 */     Preconditions.checkArgument((charactersPerPage > 4), "Unreasonable charactersPerPage count");
/*  95 */     Preconditions.checkArgument((paddingBetweenCharacters > 0), "paddingBetweenCharacters <= 0");
/*  96 */     this.originalSize = sizePx;
/*  97 */     this.charsPerPage = charactersPerPage;
/*  98 */     this.padding = paddingBetweenCharacters;
/*  99 */     this.prebakeGlyphs = prebakeCharacters;
/* 100 */     init(fonts, sizePx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FontRenderer(Font[] fonts, float sizePx) {
/* 110 */     this(fonts, sizePx, 256, 5, null);
/*     */   }
/*     */   
/*     */   private static int floorNearestMulN(int x, int n) {
/* 114 */     return n * (int)Math.floor(x / n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stripControlCodes(String text) {
/* 124 */     char[] chars = text.toCharArray();
/* 125 */     StringBuilder f = new StringBuilder();
/* 126 */     for (int i = 0; i < chars.length; i++) {
/* 127 */       char c = chars[i];
/* 128 */       if (c == '§') {
/* 129 */         i++;
/*     */       } else {
/*     */         
/* 132 */         f.append(c);
/*     */       } 
/* 134 */     }  return f.toString();
/*     */   }
/*     */   
/*     */   private void sizeCheck() {
/* 138 */     int gs = RendererUtils.getGuiScale();
/* 139 */     if (gs != this.previousGameScale) {
/* 140 */       close();
/* 141 */       init(this.fonts, this.originalSize);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void init(Font[] fonts, float sizePx) {
/* 146 */     if (this.initialized) throw new IllegalStateException("Double call to init()"); 
/* 147 */     this.initialized = true;
/* 148 */     this.previousGameScale = RendererUtils.getGuiScale();
/* 149 */     this.scaleMul = this.previousGameScale;
/* 150 */     this.fonts = new Font[fonts.length];
/* 151 */     for (int i = 0; i < fonts.length; i++) {
/* 152 */       this.fonts[i] = fonts[i].deriveFont(sizePx * this.scaleMul);
/*     */     }
/* 154 */     if (this.prebakeGlyphs != null && !this.prebakeGlyphs.isEmpty()) {
/* 155 */       this.prebakeGlyphsFuture = prebake();
/*     */     }
/*     */   }
/*     */   
/*     */   private Future<Void> prebake() {
/* 160 */     return ASYNC_WORKER.submit(() -> {
/*     */           for (char c : this.prebakeGlyphs.toCharArray()) {
/*     */             if (Thread.interrupted())
/*     */               break; 
/*     */             locateGlyph1(c);
/*     */           } 
/*     */           return null;
/*     */         });
/*     */   }
/*     */   private GlyphMap generateMap(char from, char to) {
/* 170 */     RendererMain.LOGGER.debug("[Font renderer {}] Generating glyph page '{}' ({}) to '{}' ({}), {} characters", new Object[] { Integer.valueOf(hashCode()), Character.valueOf(from), Integer.valueOf(from), Character.valueOf(to), Integer.valueOf(to), Integer.valueOf(to - from) });
/* 171 */     GlyphMap gm = new GlyphMap(from, to, this.fonts, RendererUtils.randomIdentifier(), this.padding);
/* 172 */     this.maps.add(gm);
/* 173 */     return gm;
/*     */   }
/*     */   
/*     */   private Glyph locateGlyph0(char glyph) {
/* 177 */     for (ObjectListIterator<GlyphMap> objectListIterator = this.maps.iterator(); objectListIterator.hasNext(); ) { GlyphMap map = objectListIterator.next();
/* 178 */       if (map.contains(glyph)) {
/* 179 */         return map.getGlyph(glyph);
/*     */       } }
/*     */     
/* 182 */     int base = floorNearestMulN(glyph, this.charsPerPage);
/* 183 */     GlyphMap glyphMap = generateMap((char)base, (char)(base + this.charsPerPage));
/* 184 */     return glyphMap.getGlyph(glyph);
/*     */   }
/*     */   
/*     */   private Glyph locateGlyph1(char glyph) {
/* 188 */     return (Glyph)this.allGlyphs.computeIfAbsent(glyph, this::locateGlyph0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawString(class_4587 stack, String s, float x, float y, float r, float g, float b, float a) {
/* 204 */     if (this.prebakeGlyphsFuture != null && !this.prebakeGlyphsFuture.isDone()) {
/*     */       try {
/* 206 */         this.prebakeGlyphsFuture.get();
/* 207 */       } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 212 */     sizeCheck();
/* 213 */     float r2 = r, g2 = g, b2 = b;
/* 214 */     stack.method_22903();
/* 215 */     stack.method_46416(x, y, 0.0F);
/* 216 */     stack.method_22905(1.0F / this.scaleMul, 1.0F / this.scaleMul, 1.0F);
/*     */     
/* 218 */     RenderSystem.enableBlend();
/* 219 */     RenderSystem.defaultBlendFunc();
/* 220 */     RenderSystem.disableCull();
/* 221 */     GL11.glTexParameteri(3553, 10241, 9729);
/* 222 */     GL11.glTexParameteri(3553, 10240, 9729);
/*     */     
/* 224 */     RenderSystem.setShader(class_757::method_34543);
/* 225 */     class_287 bb = class_289.method_1348().method_1349();
/* 226 */     Matrix4f mat = stack.method_23760().method_23761();
/* 227 */     char[] chars = s.toCharArray();
/* 228 */     float xOffset = 0.0F;
/* 229 */     float yOffset = 0.0F;
/* 230 */     boolean inSel = false;
/* 231 */     int lineStart = 0;
/* 232 */     synchronized (this.GLYPH_PAGE_CACHE) {
/* 233 */       for (int i = 0; i < chars.length; i++) {
/* 234 */         char c = chars[i];
/* 235 */         if (inSel) {
/* 236 */           inSel = false;
/* 237 */           char c1 = Character.toUpperCase(c);
/* 238 */           if (colorCodes.containsKey(c1)) {
/* 239 */             int ii = colorCodes.get(c1);
/* 240 */             int[] col = Colors.RGBIntToRGB(ii);
/* 241 */             r2 = col[0] / 255.0F;
/* 242 */             g2 = col[1] / 255.0F;
/* 243 */             b2 = col[2] / 255.0F;
/* 244 */           } else if (c1 == 'R') {
/* 245 */             r2 = r;
/* 246 */             g2 = g;
/* 247 */             b2 = b;
/*     */           }
/*     */         
/*     */         }
/* 251 */         else if (c == '§') {
/* 252 */           inSel = true;
/*     */         }
/* 254 */         else if (c == '\n') {
/* 255 */           yOffset += getStringHeight(s.substring(lineStart, i)) * this.scaleMul;
/* 256 */           xOffset = 0.0F;
/* 257 */           lineStart = i + 1;
/*     */         } else {
/*     */           
/* 260 */           Glyph glyph = locateGlyph1(c);
/* 261 */           if (glyph.value() != ' ') {
/* 262 */             class_2960 i1 = (glyph.owner()).bindToTexture;
/* 263 */             DrawEntry entry = new DrawEntry(xOffset, yOffset, r2, g2, b2, glyph);
/* 264 */             ((ObjectList)this.GLYPH_PAGE_CACHE.computeIfAbsent(i1, integer -> new ObjectArrayList())).add(entry);
/*     */           } 
/* 266 */           xOffset += glyph.width();
/*     */         } 
/* 268 */       }  for (ObjectIterator<class_2960> objectIterator = this.GLYPH_PAGE_CACHE.keySet().iterator(); objectIterator.hasNext(); ) { class_2960 identifier = objectIterator.next();
/* 269 */         RenderSystem.setShaderTexture(0, identifier);
/* 270 */         List<DrawEntry> objects = (List<DrawEntry>)this.GLYPH_PAGE_CACHE.get(identifier);
/*     */         
/* 272 */         bb.method_1328(class_293.class_5596.field_27382, class_290.field_1575);
/*     */         
/* 274 */         for (DrawEntry object : objects) {
/* 275 */           float xo = object.atX;
/* 276 */           float yo = object.atY;
/* 277 */           float cr = object.r;
/* 278 */           float cg = object.g;
/* 279 */           float cb = object.b;
/* 280 */           Glyph glyph = object.toDraw;
/* 281 */           GlyphMap owner = glyph.owner();
/* 282 */           float w = glyph.width();
/* 283 */           float h = glyph.height();
/* 284 */           float u1 = glyph.u() / owner.width;
/* 285 */           float v1 = glyph.v() / owner.height;
/* 286 */           float u2 = (glyph.u() + glyph.width()) / owner.width;
/* 287 */           float v2 = (glyph.v() + glyph.height()) / owner.height;
/*     */           
/* 289 */           bb.method_22918(mat, xo + 0.0F, yo + h, 0.0F).method_22913(u1, v2).method_22915(cr, cg, cb, a).method_1344();
/* 290 */           bb.method_22918(mat, xo + w, yo + h, 0.0F).method_22913(u2, v2).method_22915(cr, cg, cb, a).method_1344();
/* 291 */           bb.method_22918(mat, xo + w, yo + 0.0F, 0.0F).method_22913(u2, v1).method_22915(cr, cg, cb, a).method_1344();
/* 292 */           bb.method_22918(mat, xo + 0.0F, yo + 0.0F, 0.0F).method_22913(u1, v1).method_22915(cr, cg, cb, a).method_1344();
/*     */         } 
/* 294 */         BufferUtils.draw(bb); }
/*     */ 
/*     */       
/* 297 */       this.GLYPH_PAGE_CACHE.clear();
/*     */     } 
/* 299 */     stack.method_22909();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawCenteredString(class_4587 stack, String s, float x, float y, float r, float g, float b, float a) {
/* 315 */     drawString(stack, s, x - getStringWidth(s) / 2.0F, y, r, g, b, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getStringWidth(String text) {
/* 325 */     char[] c = stripControlCodes(text).toCharArray();
/* 326 */     float currentLine = 0.0F;
/* 327 */     float maxPreviousLines = 0.0F;
/* 328 */     for (char c1 : c) {
/* 329 */       if (c1 == '\n') {
/* 330 */         maxPreviousLines = Math.max(currentLine, maxPreviousLines);
/* 331 */         currentLine = 0.0F;
/*     */       } else {
/*     */         
/* 334 */         Glyph glyph = locateGlyph1(c1);
/* 335 */         currentLine += glyph.width() / this.scaleMul;
/*     */       } 
/* 337 */     }  return Math.max(currentLine, maxPreviousLines);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getStringHeight(String text) {
/* 347 */     char[] c = stripControlCodes(text).toCharArray();
/* 348 */     if (c.length == 0) {
/* 349 */       c = new char[] { ' ' };
/*     */     }
/* 351 */     float currentLine = 0.0F;
/* 352 */     float previous = 0.0F;
/* 353 */     for (char c1 : c) {
/* 354 */       if (c1 == '\n') {
/* 355 */         if (currentLine == 0.0F)
/*     */         {
/* 357 */           currentLine = locateGlyph1(' ').height() / this.scaleMul;
/*     */         }
/* 359 */         previous += currentLine;
/* 360 */         currentLine = 0.0F;
/*     */       } else {
/*     */         
/* 363 */         Glyph glyph = locateGlyph1(c1);
/* 364 */         currentLine = Math.max(glyph.height() / this.scaleMul, currentLine);
/*     */       } 
/* 366 */     }  return currentLine + previous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close()
/*     */   {
/*     */     try {
/* 375 */       if (this.prebakeGlyphsFuture != null && !this.prebakeGlyphsFuture.isDone() && !this.prebakeGlyphsFuture.isCancelled()) {
/*     */         
/* 377 */         this.prebakeGlyphsFuture.cancel(true);
/* 378 */         this.prebakeGlyphsFuture.get();
/* 379 */         this.prebakeGlyphsFuture = null;
/*     */       } 
/* 381 */       for (ObjectListIterator<GlyphMap> objectListIterator = this.maps.iterator(); objectListIterator.hasNext(); ) { GlyphMap map = objectListIterator.next();
/* 382 */         map.destroy(); }
/*     */       
/* 384 */       this.maps.clear();
/* 385 */       this.allGlyphs.clear();
/* 386 */       this.initialized = false;
/*     */     } catch (Throwable $ex) {
/*     */       throw $ex;
/* 389 */     }  } static final class DrawEntry extends Record { private final float atX; private final float atY; private final float r; private final float g; private final float b; private final Glyph toDraw; DrawEntry(float atX, float atY, float r, float g, float b, Glyph toDraw) { this.atX = atX; this.atY = atY; this.r = r; this.g = g; this.b = b; this.toDraw = toDraw; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lme/x150/renderer/font/FontRenderer$DrawEntry;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #389	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 389 */       //   0	7	0	this	Lme/x150/renderer/font/FontRenderer$DrawEntry; } public float atX() { return this.atX; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lme/x150/renderer/font/FontRenderer$DrawEntry;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #389	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lme/x150/renderer/font/FontRenderer$DrawEntry; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lme/x150/renderer/font/FontRenderer$DrawEntry;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #389	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lme/x150/renderer/font/FontRenderer$DrawEntry;
/* 389 */       //   0	8	1	o	Ljava/lang/Object; } public float atY() { return this.atY; } public float r() { return this.r; } public float g() { return this.g; } public float b() { return this.b; } public Glyph toDraw() { return this.toDraw; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/font/FontRenderer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */