/*     */ package me.x150.renderer.font;
/*     */ 
/*     */ import it.unimi.dsi.fastutil.chars.Char2ObjectArrayMap;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_2960;
/*     */ 
/*     */ class GlyphMap {
/*     */   final char fromIncl;
/*     */   final char toExcl;
/*     */   final Font[] font;
/*     */   final class_2960 bindToTexture;
/*     */   
/*  23 */   public GlyphMap(char fromIncl, char toExcl, Font[] font, class_2960 bindToTexture, int pixelPadding) { this.glyphs = new Char2ObjectArrayMap();
/*     */ 
/*     */     
/*  26 */     this.generated = false; this.fromIncl = fromIncl; this.toExcl = toExcl;
/*     */     this.font = font;
/*     */     this.bindToTexture = bindToTexture;
/*  29 */     this.pixelPadding = pixelPadding; } final int pixelPadding; private final Char2ObjectArrayMap<Glyph> glyphs; int width; int height; boolean generated; public Glyph getGlyph(char c) { if (!this.generated) {
/*  30 */       generate();
/*     */     }
/*  32 */     return (Glyph)this.glyphs.get(c); }
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  36 */     class_310.method_1551().method_1531().method_4615(this.bindToTexture);
/*  37 */     this.glyphs.clear();
/*  38 */     this.width = -1;
/*  39 */     this.height = -1;
/*  40 */     this.generated = false;
/*     */   }
/*     */   
/*     */   public boolean contains(char c) {
/*  44 */     return (c >= this.fromIncl && c < this.toExcl);
/*     */   }
/*     */   
/*     */   private Font getFontForGlyph(char c) {
/*  48 */     for (Font font1 : this.font) {
/*  49 */       if (font1.canDisplay(c)) {
/*  50 */         return font1;
/*     */       }
/*     */     } 
/*  53 */     return this.font[0];
/*     */   }
/*     */   
/*     */   public void generate() {
/*  57 */     if (this.generated) {
/*     */       return;
/*     */     }
/*  60 */     int range = this.toExcl - this.fromIncl - 1;
/*  61 */     int charsVert = (int)(Math.ceil(Math.sqrt(range)) * 1.5D);
/*  62 */     this.glyphs.clear();
/*  63 */     int generatedChars = 0;
/*  64 */     int charNX = 0;
/*  65 */     int maxX = 0, maxY = 0;
/*  66 */     int currentX = 0, currentY = 0;
/*  67 */     int currentRowMaxY = 0;
/*  68 */     List<Glyph> glyphs1 = new ArrayList<>();
/*  69 */     AffineTransform af = new AffineTransform();
/*  70 */     FontRenderContext frc = new FontRenderContext(af, true, false);
/*  71 */     while (generatedChars <= range) {
/*  72 */       char currentChar = (char)(this.fromIncl + generatedChars);
/*  73 */       Font font = getFontForGlyph(currentChar);
/*  74 */       Rectangle2D stringBounds = font.getStringBounds(String.valueOf(currentChar), frc);
/*     */       
/*  76 */       int width = (int)Math.ceil(stringBounds.getWidth());
/*  77 */       int height = (int)Math.ceil(stringBounds.getHeight());
/*  78 */       generatedChars++;
/*  79 */       maxX = Math.max(maxX, currentX + width);
/*  80 */       maxY = Math.max(maxY, currentY + height);
/*  81 */       if (charNX >= charsVert) {
/*  82 */         currentX = 0;
/*  83 */         currentY += currentRowMaxY + this.pixelPadding;
/*  84 */         charNX = 0;
/*  85 */         currentRowMaxY = 0;
/*     */       } 
/*  87 */       currentRowMaxY = Math.max(currentRowMaxY, height);
/*  88 */       glyphs1.add(new Glyph(currentX, currentY, width, height, currentChar, this));
/*  89 */       currentX += width + this.pixelPadding;
/*  90 */       charNX++;
/*     */     } 
/*  92 */     BufferedImage bi = new BufferedImage(Math.max(maxX + this.pixelPadding, 1), Math.max(maxY + this.pixelPadding, 1), 2);
/*     */     
/*  94 */     this.width = bi.getWidth();
/*  95 */     this.height = bi.getHeight();
/*  96 */     Graphics2D g2d = bi.createGraphics();
/*  97 */     g2d.setColor(new Color(255, 255, 255, 0));
/*  98 */     g2d.fillRect(0, 0, this.width, this.height);
/*  99 */     g2d.setColor(Color.WHITE);
/*     */     
/* 101 */     g2d.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
/* 102 */     g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
/* 103 */     g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*     */     
/* 105 */     for (Glyph glyph : glyphs1) {
/* 106 */       g2d.setFont(getFontForGlyph(glyph.value()));
/* 107 */       FontMetrics fontMetrics = g2d.getFontMetrics();
/* 108 */       g2d.drawString(String.valueOf(glyph.value()), glyph.u(), glyph.v() + fontMetrics.getAscent());
/* 109 */       this.glyphs.put(glyph.value(), glyph);
/*     */     } 
/* 111 */     RendererUtils.registerBufferedImageTexture(this.bindToTexture, bi);
/* 112 */     this.generated = true;
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/font/GlyphMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */