/*     */ package me.x150.renderer.render;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import me.x150.renderer.util.BufferUtils;
/*     */ import me.x150.renderer.util.Colors;
/*     */ import me.x150.renderer.util.RendererUtils;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_757;
/*     */ import org.joml.Math;
/*     */ import org.joml.Matrix4f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Renderer2d
/*     */ {
/*  33 */   private static final class_310 client = class_310.method_1551();
/*  34 */   private static final float[][] roundedCache = new float[][] { new float[3], new float[3], new float[3], new float[3] };
/*     */   
/*     */   static void beginScissor(double x, double y, double endX, double endY) {
/*  37 */     double width = endX - x;
/*  38 */     double height = endY - y;
/*  39 */     width = Math.max(0.0D, width);
/*  40 */     height = Math.max(0.0D, height);
/*  41 */     float d = (float)client.method_22683().method_4495();
/*  42 */     int ay = (int)((client.method_22683().method_4502() - y + height) * d);
/*  43 */     RenderSystem.enableScissor((int)(x * d), ay, (int)(width * d), (int)(height * d));
/*     */   }
/*     */   
/*     */   static void endScissor() {
/*  47 */     RenderSystem.disableScissor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderTexture(class_4587 matrices, double x0, double y0, double width, double height, float u, float v, double regionWidth, double regionHeight, double textureWidth, double textureHeight) {
/*  68 */     double x1 = x0 + width;
/*  69 */     double y1 = y0 + height;
/*  70 */     double z = 0.0D;
/*  71 */     renderTexturedQuad(matrices
/*  72 */         .method_23760().method_23761(), x0, x1, y0, y1, z, (u + 0.0F) / (float)textureWidth, (u + (float)regionWidth) / (float)textureWidth, (v + 0.0F) / (float)textureHeight, (v + (float)regionHeight) / (float)textureHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void renderTexturedQuad(Matrix4f matrix, double x0, double x1, double y0, double y1, double z, float u0, float u1, float v0, float v1) {
/*  86 */     class_287 buffer = class_289.method_1348().method_1349();
/*  87 */     buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1585);
/*  88 */     buffer.method_22918(matrix, (float)x0, (float)y1, (float)z).method_22913(u0, v1).method_1344();
/*  89 */     buffer.method_22918(matrix, (float)x1, (float)y1, (float)z).method_22913(u1, v1).method_1344();
/*  90 */     buffer.method_22918(matrix, (float)x1, (float)y0, (float)z).method_22913(u1, v0).method_1344();
/*  91 */     buffer.method_22918(matrix, (float)x0, (float)y0, (float)z).method_22913(u0, v0).method_1344();
/*     */     
/*  93 */     RenderSystem.setShader(class_757::method_34542);
/*  94 */     BufferUtils.draw(buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderTexture(class_4587 matrices, double x, double y, double width, double height) {
/* 108 */     renderTexture(matrices, x, y, width, height, 0.0F, 0.0F, width, height, width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderTexture(class_4587 matrices, class_2960 texture, double x, double y, double width, double height) {
/* 123 */     RenderSystem.setShaderTexture(0, texture);
/* 124 */     renderTexture(matrices, x, y, width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderEllipse(class_4587 matrices, Color ellipseColor, double originX, double originY, double radX, double radY, int segments) {
/* 140 */     segments = class_3532.method_15340(segments, 4, 360);
/*     */     
/* 142 */     Matrix4f matrix = matrices.method_23760().method_23761();
/*     */     
/* 144 */     float[] colorFloat = Renderer3d.getColor(ellipseColor);
/*     */     
/* 146 */     class_287 buffer = class_289.method_1348().method_1349();
/* 147 */     buffer.method_1328(class_293.class_5596.field_27381, class_290.field_1576); int i;
/* 148 */     for (i = 0; i < 360; i = (int)(i + Math.min(360.0D / segments, (360 - i)))) {
/* 149 */       double radians = Math.toRadians(i);
/* 150 */       double sin = Math.sin(radians) * radX;
/* 151 */       double cos = Math.cos(radians) * radY;
/* 152 */       buffer.method_22918(matrix, (float)(originX + sin), (float)(originY + cos), 0.0F)
/* 153 */         .method_22915(colorFloat[0], colorFloat[1], colorFloat[2], colorFloat[3])
/* 154 */         .method_1344();
/*     */     } 
/* 156 */     RendererUtils.setupRender();
/* 157 */     RenderSystem.setShader(class_757::method_34540);
/* 158 */     BufferUtils.draw(buffer);
/* 159 */     RendererUtils.endRender();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderCircle(class_4587 matrices, Color circleColor, double originX, double originY, double rad, int segments) {
/* 174 */     renderEllipse(matrices, circleColor, originX, originY, rad, rad, segments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderEllipseOutline(class_4587 matrices, Color ellipseColor, double originX, double originY, double radX, double radY, double width, double height, int segments) {
/* 192 */     segments = class_3532.method_15340(segments, 4, 360);
/* 193 */     width = class_3532.method_15350(width, 0.0D, radX);
/* 194 */     height = class_3532.method_15350(height, 0.0D, radY);
/*     */     
/* 196 */     Matrix4f matrix = matrices.method_23760().method_23761();
/*     */     
/* 198 */     float[] colorFloat = Renderer3d.getColor(ellipseColor);
/*     */     
/* 200 */     class_287 buffer = class_289.method_1348().method_1349();
/* 201 */     buffer.method_1328(class_293.class_5596.field_27380, class_290.field_1576);
/* 202 */     for (int i = 0; i <= segments; i++) {
/* 203 */       double radians = Math.toRadians(i / segments * 360.0D);
/* 204 */       double sin = Math.sin(radians) * (radX - width);
/* 205 */       double cos = Math.cos(radians) * (radY - height);
/* 206 */       double sin1 = Math.sin(radians) * radX;
/* 207 */       double cos1 = Math.cos(radians) * radY;
/* 208 */       buffer.method_22918(matrix, (float)(originX + sin), (float)(originY + cos), 0.0F)
/* 209 */         .method_22915(colorFloat[0], colorFloat[1], colorFloat[2], colorFloat[3])
/* 210 */         .method_1344();
/* 211 */       buffer.method_22918(matrix, (float)(originX + sin1), (float)(originY + cos1), 0.0F)
/* 212 */         .method_22915(colorFloat[0], colorFloat[1], colorFloat[2], colorFloat[3])
/* 213 */         .method_1344();
/*     */     } 
/* 215 */     RendererUtils.setupRender();
/* 216 */     RenderSystem.setShader(class_757::method_34540);
/* 217 */     BufferUtils.draw(buffer);
/* 218 */     RendererUtils.endRender();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderQuad(class_4587 matrices, Color color, double x1, double y1, double x2, double y2) {
/* 233 */     if (x1 < x2) {
/* 234 */       double j = x1;
/* 235 */       x1 = x2;
/* 236 */       x2 = j;
/*     */     } 
/*     */     
/* 239 */     if (y1 < y2) {
/* 240 */       double j = y1;
/* 241 */       y1 = y2;
/* 242 */       y2 = j;
/*     */     } 
/* 244 */     Matrix4f matrix = matrices.method_23760().method_23761();
/* 245 */     float[] colorFloat = Renderer3d.getColor(color);
/*     */     
/* 247 */     class_287 buffer = class_289.method_1348().method_1349();
/* 248 */     buffer.method_1328(class_293.class_5596.field_27382, class_290.field_1576);
/* 249 */     buffer.method_22918(matrix, (float)x1, (float)y2, 0.0F)
/* 250 */       .method_22915(colorFloat[0], colorFloat[1], colorFloat[2], colorFloat[3])
/* 251 */       .method_1344();
/* 252 */     buffer.method_22918(matrix, (float)x2, (float)y2, 0.0F)
/* 253 */       .method_22915(colorFloat[0], colorFloat[1], colorFloat[2], colorFloat[3])
/* 254 */       .method_1344();
/* 255 */     buffer.method_22918(matrix, (float)x2, (float)y1, 0.0F)
/* 256 */       .method_22915(colorFloat[0], colorFloat[1], colorFloat[2], colorFloat[3])
/* 257 */       .method_1344();
/* 258 */     buffer.method_22918(matrix, (float)x1, (float)y1, 0.0F)
/* 259 */       .method_22915(colorFloat[0], colorFloat[1], colorFloat[2], colorFloat[3])
/* 260 */       .method_1344();
/*     */     
/* 262 */     RendererUtils.setupRender();
/* 263 */     RenderSystem.setShader(class_757::method_34540);
/* 264 */     BufferUtils.draw(buffer);
/* 265 */     RendererUtils.endRender();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void renderRoundedQuadInternal(Matrix4f matrix, float cr, float cg, float cb, float ca, float fromX, float fromY, float toX, float toY, float radC1, float radC2, float radC3, float radC4, float samples) {
/* 270 */     class_287 bufferBuilder = class_289.method_1348().method_1349();
/* 271 */     bufferBuilder.method_1328(class_293.class_5596.field_27381, class_290.field_1576);
/*     */     
/* 273 */     _populateRC(toX - radC4, toY - radC4, radC4, 0);
/* 274 */     _populateRC(toX - radC2, fromY + radC2, radC2, 1);
/* 275 */     _populateRC(fromX + radC1, fromY + radC1, radC1, 2);
/* 276 */     _populateRC(fromX + radC3, toY - radC3, radC3, 3);
/* 277 */     for (int i = 0; i < 4; i++) {
/* 278 */       float[] current = roundedCache[i];
/* 279 */       float rad = current[2]; float r;
/* 280 */       for (r = i * 90.0F; r <= (i + 1) * 90.0F; r += 90.0F / samples) {
/* 281 */         float rad1 = Math.toRadians(r);
/* 282 */         float sin = Math.sin(rad1) * rad;
/* 283 */         float cos = Math.cos(rad1) * rad;
/*     */         
/* 285 */         bufferBuilder.method_22918(matrix, current[0] + sin, current[1] + cos, 0.0F).method_22915(cr, cg, cb, ca).method_1344();
/*     */       } 
/*     */     } 
/* 288 */     BufferUtils.draw(bufferBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderRoundedQuad(class_4587 matrices, Color c, double fromX, double fromY, double toX, double toY, float radTL, float radTR, float radBL, float radBR, float samples) {
/* 307 */     Matrix4f matrix = matrices.method_23760().method_23761();
/* 308 */     float[] color1 = Renderer3d.getColor(c);
/* 309 */     float r = color1[0];
/* 310 */     float g = color1[1];
/* 311 */     float b = color1[2];
/* 312 */     float a = color1[3];
/* 313 */     RendererUtils.setupRender();
/* 314 */     RenderSystem.setShader(class_757::method_34540);
/*     */     
/* 316 */     renderRoundedQuadInternal(matrix, r, g, b, a, (float)fromX, (float)fromY, (float)toX, (float)toY, radTL, radTR, radBL, radBR, samples);
/*     */     
/* 318 */     RendererUtils.endRender();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderRoundedQuad(class_4587 stack, Color c, double x, double y, double x1, double y1, float rad, float samples) {
/* 334 */     renderRoundedQuad(stack, c, x, y, x1, y1, rad, rad, rad, rad, samples);
/*     */   }
/*     */   
/*     */   private static void _populateRC(float a, float b, float c, int i) {
/* 338 */     roundedCache[i][0] = a;
/* 339 */     roundedCache[i][1] = b;
/* 340 */     roundedCache[i][2] = c;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void renderRoundedOutlineInternal(Matrix4f matrix, float cr, float cg, float cb, float ca, float fromX, float fromY, float toX, float toY, float radC1, float radC2, float radC3, float radC4, float width, float samples) {
/* 345 */     class_287 bufferBuilder = class_289.method_1348().method_1349();
/* 346 */     bufferBuilder.method_1328(class_293.class_5596.field_27380, class_290.field_1576);
/*     */     
/* 348 */     _populateRC(toX - radC4, toY - radC4, radC4, 0);
/* 349 */     _populateRC(toX - radC2, fromY + radC2, radC2, 1);
/* 350 */     _populateRC(fromX + radC1, fromY + radC1, radC1, 2);
/* 351 */     _populateRC(fromX + radC3, toY - radC3, radC3, 3);
/* 352 */     for (int i = 0; i < 4; i++) {
/* 353 */       float[] arrayOfFloat = roundedCache[i];
/* 354 */       float f1 = arrayOfFloat[2]; float r;
/* 355 */       for (r = i * 90.0F; r <= (i + 1) * 90.0F; r += 90.0F / samples) {
/* 356 */         float rad1 = Math.toRadians(r);
/* 357 */         float sin1 = Math.sin(rad1);
/* 358 */         float sin = sin1 * f1;
/* 359 */         float cos1 = Math.cos(rad1);
/* 360 */         float cos = cos1 * f1;
/* 361 */         bufferBuilder.method_22918(matrix, arrayOfFloat[0] + sin, arrayOfFloat[1] + cos, 0.0F).method_22915(cr, cg, cb, ca).method_1344();
/* 362 */         bufferBuilder.method_22918(matrix, arrayOfFloat[0] + sin + sin1 * width, arrayOfFloat[1] + cos + cos1 * width, 0.0F)
/* 363 */           .method_22915(cr, cg, cb, ca)
/* 364 */           .method_1344();
/*     */       } 
/*     */     } 
/*     */     
/* 368 */     float[] current = roundedCache[0];
/* 369 */     float rad = current[2];
/* 370 */     bufferBuilder.method_22918(matrix, current[0], current[1] + rad, 0.0F).method_22915(cr, cg, cb, ca).method_1344();
/* 371 */     bufferBuilder.method_22918(matrix, current[0], current[1] + rad + width, 0.0F).method_22915(cr, cg, cb, ca).method_1344();
/* 372 */     BufferUtils.draw(bufferBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderRoundedOutline(class_4587 matrices, Color c, double fromX, double fromY, double toX, double toY, float radTL, float radTR, float radBL, float radBR, float outlineWidth, float samples) {
/* 393 */     Matrix4f matrix = matrices.method_23760().method_23761();
/* 394 */     float[] color1 = Renderer3d.getColor(c);
/* 395 */     float r = color1[0];
/* 396 */     float g = color1[1];
/* 397 */     float b = color1[2];
/* 398 */     float a = color1[3];
/* 399 */     RendererUtils.setupRender();
/* 400 */     RenderSystem.setShader(class_757::method_34540);
/*     */     
/* 402 */     renderRoundedOutlineInternal(matrix, r, g, b, a, (float)fromX, (float)fromY, (float)toX, (float)toY, radTL, radTR, radBL, radBR, outlineWidth, samples);
/*     */     
/* 404 */     RendererUtils.endRender();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderRoundedOutline(class_4587 matrices, Color c, double fromX, double fromY, double toX, double toY, float rad, float width, float samples) {
/* 421 */     renderRoundedOutline(matrices, c, fromX, fromY, toX, toY, rad, rad, rad, rad, width, samples);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderLine(class_4587 stack, Color color, double x, double y, double x1, double y1) {
/* 435 */     float[] colorFloat = Colors.intArrayToFloatArray(Colors.ARGBIntToRGBA(color.getRGB()));
/* 436 */     Matrix4f m = stack.method_23760().method_23761();
/*     */     
/* 438 */     class_287 bufferBuilder = class_289.method_1348().method_1349();
/* 439 */     bufferBuilder.method_1328(class_293.class_5596.field_29344, class_290.field_1576);
/* 440 */     bufferBuilder.method_22918(m, (float)x, (float)y, 0.0F)
/* 441 */       .method_22915(colorFloat[0], colorFloat[1], colorFloat[2], colorFloat[3])
/* 442 */       .method_1344();
/* 443 */     bufferBuilder.method_22918(m, (float)x1, (float)y1, 0.0F)
/* 444 */       .method_22915(colorFloat[0], colorFloat[1], colorFloat[2], colorFloat[3])
/* 445 */       .method_1344();
/*     */     
/* 447 */     RendererUtils.setupRender();
/* 448 */     RenderSystem.setShader(class_757::method_34540);
/* 449 */     BufferUtils.draw(bufferBuilder);
/* 450 */     RendererUtils.endRender();
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/render/Renderer2d.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */