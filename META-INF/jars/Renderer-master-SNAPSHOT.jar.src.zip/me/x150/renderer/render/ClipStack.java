/*    */ package me.x150.renderer.render;
/*    */ 
/*    */ import java.util.Stack;
/*    */ import me.x150.renderer.util.Rectangle;
/*    */ import net.minecraft.class_3532;
/*    */ import net.minecraft.class_4587;
/*    */ import org.joml.Matrix4f;
/*    */ import org.joml.Matrix4fc;
/*    */ import org.joml.Vector4f;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClipStack
/*    */ {
/* 16 */   static final Stack<Rectangle> clipStack = new Stack<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void addWindow(class_4587 stack, Rectangle rect) {
/* 27 */     Matrix4f matrix = stack.method_23760().method_23761();
/* 28 */     Vector4f start = new Vector4f((float)rect.getX(), (float)rect.getY(), 0.0F, 1.0F);
/* 29 */     Vector4f end = new Vector4f((float)rect.getX1(), (float)rect.getY1(), 0.0F, 1.0F);
/* 30 */     start.mul((Matrix4fc)matrix);
/* 31 */     end.mul((Matrix4fc)matrix);
/* 32 */     double x0 = start.x();
/* 33 */     double y0 = start.y();
/* 34 */     double x1 = end.x();
/* 35 */     double y1 = end.y();
/* 36 */     Rectangle transformed = new Rectangle(x0, y0, x1, y1);
/* 37 */     if (clipStack.empty()) {
/* 38 */       clipStack.push(transformed);
/* 39 */       Renderer2d.beginScissor(transformed.getX(), transformed.getY(), transformed.getX1(), transformed.getY1());
/*    */     } else {
/* 41 */       Rectangle lastClip = clipStack.peek();
/* 42 */       double lx0 = lastClip.getX();
/* 43 */       double ly0 = lastClip.getY();
/* 44 */       double lx1 = lastClip.getX1();
/* 45 */       double ly1 = lastClip.getY1();
/* 46 */       double nx0 = class_3532.method_15350(transformed.getX(), lx0, lx1);
/* 47 */       double ny0 = class_3532.method_15350(transformed.getY(), ly0, ly1);
/* 48 */       double nx1 = class_3532.method_15350(transformed.getX1(), nx0, lx1);
/* 49 */       double ny1 = class_3532.method_15350(transformed.getY1(), ny0, ly1);
/* 50 */       clipStack.push(new Rectangle(nx0, ny0, nx1, ny1));
/* 51 */       Renderer2d.beginScissor(nx0, ny0, nx1, ny1);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void use(class_4587 stack, Rectangle clippingRect, Runnable renderAction) {
/* 65 */     addWindow(stack, clippingRect);
/* 66 */     renderAction.run();
/* 67 */     popWindow();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void popWindow() {
/* 74 */     clipStack.pop();
/* 75 */     if (clipStack.empty()) {
/* 76 */       Renderer2d.endScissor();
/*    */     } else {
/* 78 */       Rectangle r = clipStack.peek();
/* 79 */       Renderer2d.beginScissor(r.getX(), r.getY(), r.getX1(), r.getY1());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void renderOutsideClipStack(Runnable e) {
/* 89 */     if (clipStack.empty()) {
/* 90 */       e.run();
/*    */     } else {
/* 92 */       Renderer2d.endScissor();
/* 93 */       e.run();
/* 94 */       Rectangle r = clipStack.peek();
/* 95 */       Renderer2d.beginScissor(r.getX(), r.getY(), r.getX1(), r.getY1());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/render/ClipStack.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */