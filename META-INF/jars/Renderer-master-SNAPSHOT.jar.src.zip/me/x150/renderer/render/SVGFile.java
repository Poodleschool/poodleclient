/*     */ package me.x150.renderer.render;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.StringReader;
/*     */ import me.x150.renderer.client.RendererMain;
/*     */ import me.x150.renderer.util.RendererUtils;
/*     */ import net.minecraft.class_1011;
/*     */ import net.minecraft.class_1043;
/*     */ import net.minecraft.class_1044;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_4587;
/*     */ import org.apache.batik.transcoder.TranscoderInput;
/*     */ import org.apache.batik.transcoder.TranscoderOutput;
/*     */ import org.apache.batik.transcoder.image.PNGTranscoder;
/*     */ import org.intellij.lang.annotations.Language;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SVGFile
/*     */   implements Closeable
/*     */ {
/*     */   final String svgSource;
/*     */   final int originalWidth;
/*     */   final int originalHeight;
/*  37 */   int memoizedGuiScale = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class_2960 id;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SVGFile(@Language("SVG") String svgSource, int width, int height) {
/*  48 */     this.svgSource = svgSource;
/*  49 */     this.originalWidth = width;
/*  50 */     this.originalHeight = height;
/*     */   }
/*     */   
/*     */   private void _redraw(float width, float height) {
/*  54 */     if (this.id != null) {
/*  55 */       close();
/*     */     }
/*  57 */     this.id = RendererUtils.randomIdentifier();
/*  58 */     RendererMain.LOGGER.debug("Drawing SVG to identifier {}:{}, dimensions are {}x{}", new Object[] { this.id.method_12836(), this.id.method_12832(), Float.valueOf(width), Float.valueOf(height) });
/*  59 */     PNGTranscoder transcoder = new PNGTranscoder();
/*  60 */     transcoder.addTranscodingHint(PNGTranscoder.KEY_WIDTH, Float.valueOf(width));
/*  61 */     transcoder.addTranscodingHint(PNGTranscoder.KEY_HEIGHT, Float.valueOf(height));
/*  62 */     TranscoderInput transcoderInput = new TranscoderInput(new StringReader(this.svgSource));
/*  63 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  64 */     TranscoderOutput transcoderOutput = new TranscoderOutput(out);
/*     */     try {
/*  66 */       transcoder.transcode(transcoderInput, transcoderOutput);
/*  67 */       byte[] t = out.toByteArray();
/*  68 */       class_1043 tex = new class_1043(class_1011.method_4309(new ByteArrayInputStream(t)));
/*  69 */       if (RenderSystem.isOnRenderThread()) { class_310.method_1551().method_1531().method_4616(this.id, (class_1044)tex); }
/*  70 */       else { RenderSystem.recordRenderCall(() -> class_310.method_1551().method_1531().method_4616(this.id, (class_1044)tex)); }
/*     */ 
/*     */     
/*  73 */     } catch (Throwable t) {
/*  74 */       RendererMain.LOGGER.error("Failed to render SVG", t);
/*     */       
/*  76 */       this.id = new class_2960("missingno");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(class_4587 stack, double x, double y, float renderWidth, float renderHeight) {
/*  90 */     int guiScale = RendererUtils.getGuiScale();
/*  91 */     if (this.memoizedGuiScale != guiScale || this.id == null) {
/*  92 */       this.memoizedGuiScale = guiScale;
/*  93 */       _redraw((this.originalWidth * this.memoizedGuiScale), (this.originalHeight * this.memoizedGuiScale));
/*     */     } 
/*  95 */     Renderer2d.renderTexture(stack, this.id, x, y, renderWidth, renderHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 106 */     if (this.id == null) {
/* 107 */       throw new IllegalStateException("Already closed");
/*     */     }
/* 109 */     if (this.id.method_12836().equals("renderer"))
/*     */     {
/* 111 */       class_310.method_1551().method_1531().method_4615(this.id);
/*     */     }
/* 113 */     this.id = null;
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/render/SVGFile.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */