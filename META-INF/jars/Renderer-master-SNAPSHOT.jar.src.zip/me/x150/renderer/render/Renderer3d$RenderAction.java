package me.x150.renderer.render;

import net.minecraft.class_287;
import org.joml.Matrix4f;

interface RenderAction {
  void run(class_287 paramclass_287, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, Matrix4f paramMatrix4f);
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/render/Renderer3d$RenderAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */