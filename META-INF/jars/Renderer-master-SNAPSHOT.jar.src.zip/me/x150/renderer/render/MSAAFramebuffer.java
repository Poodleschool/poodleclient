/*     */ package me.x150.renderer.render;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.class_276;
/*     */ import net.minecraft.class_310;
/*     */ import org.lwjgl.opengl.GL30;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MSAAFramebuffer
/*     */   extends class_276
/*     */ {
/*     */   public static final int MIN_SAMPLES = 2;
/*  26 */   public static final int MAX_SAMPLES = GL30.glGetInteger(36183);
/*     */   
/*  28 */   private static final Map<Integer, MSAAFramebuffer> INSTANCES = new HashMap<>();
/*  29 */   private static final List<MSAAFramebuffer> ACTIVE_INSTANCES = new ArrayList<>();
/*     */   
/*     */   private final int samples;
/*     */   private int rboColor;
/*     */   private int rboDepth;
/*     */   private boolean inUse;
/*     */   
/*     */   private MSAAFramebuffer(int samples) {
/*  37 */     super(true);
/*  38 */     if (samples < 2 || samples > MAX_SAMPLES) {
/*  39 */       throw new IllegalArgumentException(
/*  40 */           String.format("The number of samples should be >= %s and <= %s.", new Object[] { Integer.valueOf(2), Integer.valueOf(MAX_SAMPLES) }));
/*     */     }
/*  42 */     if ((samples & samples - 1) != 0) {
/*  43 */       throw new IllegalArgumentException("The number of samples must be a power of two.");
/*     */     }
/*     */     
/*  46 */     this.samples = samples;
/*  47 */     method_1236(1.0F, 1.0F, 1.0F, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean framebufferInUse() {
/*  56 */     return !ACTIVE_INSTANCES.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MSAAFramebuffer getInstance(int samples) {
/*  66 */     return INSTANCES.computeIfAbsent(Integer.valueOf(samples), x -> new MSAAFramebuffer(samples));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void use(int samples, Runnable drawAction) {
/*  77 */     use(samples, class_310.method_1551().method_1522(), drawAction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void use(int samples, class_276 mainBuffer, Runnable drawAction) {
/*  89 */     RenderSystem.assertOnRenderThreadOrInit();
/*  90 */     MSAAFramebuffer msaaBuffer = getInstance(samples);
/*  91 */     msaaBuffer.method_1234(mainBuffer.field_1482, mainBuffer.field_1481, true);
/*     */     
/*  93 */     GlStateManager._glBindFramebuffer(36008, mainBuffer.field_1476);
/*  94 */     GlStateManager._glBindFramebuffer(36009, msaaBuffer.field_1476);
/*  95 */     GlStateManager._glBlitFrameBuffer(0, 0, msaaBuffer.field_1482, msaaBuffer.field_1481, 0, 0, msaaBuffer.field_1482, msaaBuffer.field_1481, 16384, 9729);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     msaaBuffer.method_1235(true);
/* 109 */     drawAction.run();
/* 110 */     msaaBuffer.method_1240();
/*     */     
/* 112 */     GlStateManager._glBindFramebuffer(36008, msaaBuffer.field_1476);
/* 113 */     GlStateManager._glBindFramebuffer(36009, mainBuffer.field_1476);
/* 114 */     GlStateManager._glBlitFrameBuffer(0, 0, msaaBuffer.field_1482, msaaBuffer.field_1481, 0, 0, msaaBuffer.field_1482, msaaBuffer.field_1481, 16384, 9729);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     msaaBuffer.method_1230(true);
/* 128 */     mainBuffer.method_1235(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_1234(int width, int height, boolean getError) {
/* 133 */     if (this.field_1482 != width || this.field_1481 != height) {
/* 134 */       super.method_1234(width, height, getError);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_1231(int width, int height, boolean getError) {
/* 140 */     RenderSystem.assertOnRenderThreadOrInit();
/* 141 */     int maxSize = RenderSystem.maxSupportedTextureSize();
/* 142 */     if (width <= 0 || width > maxSize || height <= 0 || height > maxSize) {
/* 143 */       throw new IllegalArgumentException("Window " + width + "x" + height + " size out of bounds (max. size: " + maxSize + ")");
/*     */     }
/*     */ 
/*     */     
/* 147 */     this.field_1480 = width;
/* 148 */     this.field_1477 = height;
/* 149 */     this.field_1482 = width;
/* 150 */     this.field_1481 = height;
/*     */     
/* 152 */     this.field_1476 = GlStateManager.glGenFramebuffers();
/* 153 */     GlStateManager._glBindFramebuffer(36160, this.field_1476);
/*     */     
/* 155 */     this.rboColor = GlStateManager.glGenRenderbuffers();
/* 156 */     GlStateManager._glBindRenderbuffer(36161, this.rboColor);
/* 157 */     GL30.glRenderbufferStorageMultisample(36161, this.samples, 32856, width, height);
/* 158 */     GlStateManager._glBindRenderbuffer(36161, 0);
/*     */     
/* 160 */     this.rboDepth = GlStateManager.glGenRenderbuffers();
/* 161 */     GlStateManager._glBindRenderbuffer(36161, this.rboDepth);
/* 162 */     GL30.glRenderbufferStorageMultisample(36161, this.samples, 6402, width, height);
/* 163 */     GlStateManager._glBindRenderbuffer(36161, 0);
/*     */     
/* 165 */     GL30.glFramebufferRenderbuffer(36160, 36064, 36161, this.rboColor);
/*     */     
/* 167 */     GL30.glFramebufferRenderbuffer(36160, 36096, 36161, this.rboDepth);
/*     */ 
/*     */     
/* 170 */     this.field_1475 = class_310.method_1551().method_1522().method_30277();
/* 171 */     this.field_1474 = class_310.method_1551().method_1522().method_30278();
/*     */     
/* 173 */     method_1239();
/* 174 */     method_1230(getError);
/* 175 */     method_1242();
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_1238() {
/* 180 */     RenderSystem.assertOnRenderThreadOrInit();
/* 181 */     method_1242();
/* 182 */     method_1240();
/*     */     
/* 184 */     if (this.field_1476 > -1) {
/* 185 */       GlStateManager._glBindFramebuffer(36160, 0);
/* 186 */       GlStateManager._glDeleteFramebuffers(this.field_1476);
/* 187 */       this.field_1476 = -1;
/*     */     } 
/*     */     
/* 190 */     if (this.rboColor > -1) {
/* 191 */       GlStateManager._glDeleteRenderbuffers(this.rboColor);
/* 192 */       this.rboColor = -1;
/*     */     } 
/*     */     
/* 195 */     if (this.rboDepth > -1) {
/* 196 */       GlStateManager._glDeleteRenderbuffers(this.rboDepth);
/* 197 */       this.rboDepth = -1;
/*     */     } 
/*     */     
/* 200 */     this.field_1475 = -1;
/* 201 */     this.field_1474 = -1;
/* 202 */     this.field_1482 = -1;
/* 203 */     this.field_1481 = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_1235(boolean setViewport) {
/* 208 */     super.method_1235(setViewport);
/* 209 */     if (!this.inUse) {
/* 210 */       ACTIVE_INSTANCES.add(this);
/* 211 */       this.inUse = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_1240() {
/* 217 */     super.method_1240();
/* 218 */     if (this.inUse) {
/* 219 */       this.inUse = false;
/* 220 */       ACTIVE_INSTANCES.remove(this);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/render/MSAAFramebuffer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */