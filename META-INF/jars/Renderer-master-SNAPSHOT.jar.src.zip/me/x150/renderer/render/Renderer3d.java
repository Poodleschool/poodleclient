/*     */ package me.x150.renderer.render;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import me.x150.renderer.util.AlphaOverride;
/*     */ import me.x150.renderer.util.BufferUtils;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5944;
/*     */ import net.minecraft.class_757;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ import org.joml.Matrix4f;
/*     */ 
/*     */ 
/*     */ public class Renderer3d
/*     */ {
/*  28 */   static final List<FadingBlock> fades = new CopyOnWriteArrayList<>();
/*  29 */   private static final class_310 client = class_310.method_1551();
/*     */ 
/*     */   
/*     */   private static boolean renderThroughWalls = false;
/*     */ 
/*     */   
/*     */   public static void renderThroughWalls() {
/*  36 */     renderThroughWalls = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void stopRenderThroughWalls() {
/*  43 */     renderThroughWalls = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean rendersThroughWalls() {
/*  52 */     return renderThroughWalls;
/*     */   }
/*     */   
/*     */   private static void setupRender() {
/*  56 */     RenderSystem.enableBlend();
/*  57 */     RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/*  58 */     RenderSystem.enableDepthTest();
/*  59 */     RenderSystem.depthFunc(renderThroughWalls ? 519 : 515);
/*     */   }
/*     */   
/*     */   private static void endRender() {
/*  63 */     RenderSystem.enableCull();
/*  64 */     RenderSystem.disableBlend();
/*     */   }
/*     */   
/*     */   static float transformColor(float f) {
/*  68 */     return AlphaOverride.compute(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderFadingBlock(Color outlineColor, Color fillColor, class_243 start, class_243 dimensions, long lifeTimeMs) {
/*  81 */     FadingBlock fb = new FadingBlock(outlineColor, fillColor, start, dimensions, System.currentTimeMillis(), lifeTimeMs);
/*     */ 
/*     */     
/*  84 */     fades.removeIf(fadingBlock -> (fadingBlock.start.equals(start) && fadingBlock.dimensions.equals(dimensions)));
/*  85 */     fades.add(fb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public static void renderFadingBlocks(class_4587 stack) {
/*  95 */     fades.removeIf(FadingBlock::isDead);
/*  96 */     for (FadingBlock fade : fades) {
/*  97 */       if (fade == null) {
/*     */         continue;
/*     */       }
/* 100 */       long lifetimeLeft = fade.getLifeTimeLeft();
/* 101 */       double progress = lifetimeLeft / fade.lifeTime;
/* 102 */       progress = class_3532.method_15350(progress, 0.0D, 1.0D);
/* 103 */       double ip = 1.0D - progress;
/* 104 */       Color out = modifyColor(fade.outline, -1, -1, -1, (int)(fade.outline.getAlpha() * progress));
/* 105 */       Color fill = modifyColor(fade.fill, -1, -1, -1, (int)(fade.fill.getAlpha() * progress));
/* 106 */       renderEdged(stack, fill, out, fade.start.method_1019((new class_243(0.2D, 0.2D, 0.2D)).method_1021(ip)), fade.dimensions
/* 107 */           .method_1020((new class_243(0.4D, 0.4D, 0.4D)).method_1021(ip)));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class_243 transformVec3d(class_243 in) {
/* 112 */     class_4184 camera = client.field_1773.method_19418();
/* 113 */     class_243 camPos = camera.method_19326();
/* 114 */     return in.method_1020(camPos);
/*     */   }
/*     */   
/*     */   static float[] getColor(Color c) {
/* 118 */     return new float[] { c.getRed() / 255.0F, c.getGreen() / 255.0F, c.getBlue() / 255.0F, transformColor(c
/* 119 */           .getAlpha() / 255.0F) };
/*     */   }
/*     */   
/*     */   private static void useBuffer(class_293.class_5596 mode, class_293 format, Supplier<class_5944> shader, Consumer<class_287> runner) {
/* 123 */     class_289 t = class_289.method_1348();
/* 124 */     class_287 bb = t.method_1349();
/*     */     
/* 126 */     bb.method_1328(mode, format);
/*     */     
/* 128 */     runner.accept(bb);
/*     */     
/* 130 */     setupRender();
/* 131 */     RenderSystem.setShader(shader);
/* 132 */     BufferUtils.draw(bb);
/* 133 */     endRender();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderOutline(class_4587 stack, Color color, class_243 start, class_243 dimensions) {
/* 145 */     Matrix4f m = stack.method_23760().method_23761();
/* 146 */     genericAABBRender(class_293.class_5596.field_29344, class_290.field_1576, class_757::method_34540, m, start, dimensions, color, (buffer, x1, y1, z1, x2, y2, z2, red, green, blue, alpha, matrix) -> {
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderEdged(class_4587 stack, Color colorFill, Color colorOutline, class_243 start, class_243 dimensions) {
/* 199 */     Matrix4f matrix = stack.method_23760().method_23761();
/* 200 */     float[] fill = getColor(colorFill);
/* 201 */     float[] outline = getColor(colorOutline);
/*     */     
/* 203 */     class_243 vec3d = transformVec3d(start);
/* 204 */     class_243 end = vec3d.method_1019(dimensions);
/* 205 */     float x1 = (float)vec3d.field_1352;
/* 206 */     float y1 = (float)vec3d.field_1351;
/* 207 */     float z1 = (float)vec3d.field_1350;
/* 208 */     float x2 = (float)end.field_1352;
/* 209 */     float y2 = (float)end.field_1351;
/* 210 */     float z2 = (float)end.field_1350;
/* 211 */     float redFill = fill[0];
/* 212 */     float greenFill = fill[1];
/* 213 */     float blueFill = fill[2];
/* 214 */     float alphaFill = fill[3];
/* 215 */     float redOutline = outline[0];
/* 216 */     float greenOutline = outline[1];
/* 217 */     float blueOutline = outline[2];
/* 218 */     float alphaOutline = outline[3];
/* 219 */     useBuffer(class_293.class_5596.field_27382, class_290.field_1576, class_757::method_34540, buffer -> {
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(redFill, greenFill, blueFill, alphaFill).method_1344();
/*     */         });
/* 251 */     useBuffer(class_293.class_5596.field_29344, class_290.field_1576, class_757::method_34540, buffer -> {
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(redOutline, greenOutline, blueOutline, alphaOutline).method_1344();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void genericAABBRender(class_293.class_5596 mode, class_293 format, Supplier<class_5944> shader, Matrix4f stack, class_243 start, class_243 dimensions, Color color, RenderAction action) {
/* 286 */     float red = color.getRed() / 255.0F;
/* 287 */     float green = color.getGreen() / 255.0F;
/* 288 */     float blue = color.getBlue() / 255.0F;
/* 289 */     float alpha = transformColor(color.getAlpha() / 255.0F);
/* 290 */     class_243 vec3d = transformVec3d(start);
/* 291 */     class_243 end = vec3d.method_1019(dimensions);
/* 292 */     float x1 = (float)vec3d.field_1352;
/* 293 */     float y1 = (float)vec3d.field_1351;
/* 294 */     float z1 = (float)vec3d.field_1350;
/* 295 */     float x2 = (float)end.field_1352;
/* 296 */     float y2 = (float)end.field_1351;
/* 297 */     float z2 = (float)end.field_1350;
/* 298 */     useBuffer(mode, format, shader, bufferBuilder -> action.run(bufferBuilder, x1, y1, z1, x2, y2, z2, red, green, blue, alpha, stack));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderFilled(class_4587 stack, Color color, class_243 start, class_243 dimensions) {
/* 311 */     Matrix4f s = stack.method_23760().method_23761();
/* 312 */     genericAABBRender(class_293.class_5596.field_27382, class_290.field_1576, class_757::method_34540, s, start, dimensions, color, (buffer, x1, y1, z1, x2, y2, z2, red, green, blue, alpha, matrix) -> {
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y2, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x2, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z2).method_22915(red, green, blue, alpha).method_1344();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderLine(class_4587 matrices, Color color, class_243 start, class_243 end) {
/* 363 */     Matrix4f s = matrices.method_23760().method_23761();
/* 364 */     genericAABBRender(class_293.class_5596.field_29344, class_290.field_1576, class_757::method_34540, s, start, end
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 370 */         .method_1020(start), color, (buffer, x, y, z, x1, y1, z1, red, green, blue, alpha, matrix) -> {
/*     */           buffer.method_22918(matrix, x, y, z).method_22915(red, green, blue, alpha).method_1344();
/*     */           buffer.method_22918(matrix, x1, y1, z1).method_22915(red, green, blue, alpha).method_1344();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color modifyColor(Color original, int redOverwrite, int greenOverwrite, int blueOverwrite, int alphaOverwrite) {
/* 388 */     return new Color(
/* 389 */         (redOverwrite == -1) ? original.getRed() : redOverwrite, 
/* 390 */         (greenOverwrite == -1) ? original.getGreen() : greenOverwrite, 
/* 391 */         (blueOverwrite == -1) ? original.getBlue() : blueOverwrite, 
/* 392 */         (alphaOverwrite == -1) ? original.getAlpha() : alphaOverwrite);
/*     */   }
/*     */   static final class FadingBlock extends Record { private final Color outline; private final Color fill;
/*     */     private final class_243 start;
/*     */     private final class_243 dimensions;
/*     */     private final long created;
/*     */     private final long lifeTime;
/*     */     
/* 400 */     FadingBlock(Color outline, Color fill, class_243 start, class_243 dimensions, long created, long lifeTime) { this.outline = outline; this.fill = fill; this.start = start; this.dimensions = dimensions; this.created = created; this.lifeTime = lifeTime; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lme/x150/renderer/render/Renderer3d$FadingBlock;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #400	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 400 */       //   0	7	0	this	Lme/x150/renderer/render/Renderer3d$FadingBlock; } public Color outline() { return this.outline; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lme/x150/renderer/render/Renderer3d$FadingBlock;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #400	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lme/x150/renderer/render/Renderer3d$FadingBlock; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lme/x150/renderer/render/Renderer3d$FadingBlock;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #400	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lme/x150/renderer/render/Renderer3d$FadingBlock;
/* 400 */       //   0	8	1	o	Ljava/lang/Object; } public Color fill() { return this.fill; } public class_243 start() { return this.start; } public class_243 dimensions() { return this.dimensions; } public long created() { return this.created; } public long lifeTime() { return this.lifeTime; }
/*     */      long getLifeTimeLeft() {
/* 402 */       return Math.max(0L, this.created - System.currentTimeMillis() + this.lifeTime);
/*     */     }
/*     */     
/*     */     boolean isDead() {
/* 406 */       return (getLifeTimeLeft() == 0L);
/*     */     } }
/*     */ 
/*     */   
/*     */   static interface RenderAction {
/*     */     void run(class_287 param1class_287, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, float param1Float8, float param1Float9, float param1Float10, Matrix4f param1Matrix4f);
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/render/Renderer3d.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */