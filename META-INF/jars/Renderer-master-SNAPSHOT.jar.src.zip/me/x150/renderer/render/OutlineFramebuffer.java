/*     */ package me.x150.renderer.render;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import java.util.Objects;
/*     */ import me.x150.renderer.mixinUtil.ShaderEffectDuck;
/*     */ import me.x150.renderer.shader.ShaderManager;
/*     */ import net.minecraft.class_276;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutlineFramebuffer
/*     */   extends class_276
/*     */ {
/*     */   private static OutlineFramebuffer instance;
/*     */   
/*     */   private OutlineFramebuffer(int width, int height) {
/*  23 */     super(false);
/*  24 */     RenderSystem.assertOnRenderThreadOrInit();
/*  25 */     method_1234(width, height, true);
/*  26 */     method_1236(0.0F, 0.0F, 0.0F, 0.0F);
/*     */   }
/*     */   
/*     */   private static OutlineFramebuffer obtain() {
/*  30 */     if (instance == null)
/*     */     {
/*  32 */       instance = new OutlineFramebuffer((class_310.method_1551().method_1522()).field_1482, (class_310.method_1551().method_1522()).field_1481);
/*     */     }
/*  34 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void use(Runnable r) {
/*  43 */     class_276 mainBuffer = class_310.method_1551().method_1522();
/*  44 */     RenderSystem.assertOnRenderThreadOrInit();
/*  45 */     OutlineFramebuffer buffer = obtain();
/*  46 */     if (buffer.field_1482 != mainBuffer.field_1482 || buffer.field_1481 != mainBuffer.field_1481) {
/*  47 */       buffer.method_1234(mainBuffer.field_1482, mainBuffer.field_1481, false);
/*     */     }
/*     */     
/*  50 */     GlStateManager._glBindFramebuffer(36009, buffer.field_1476);
/*     */     
/*  52 */     buffer.method_1235(true);
/*  53 */     r.run();
/*  54 */     buffer.method_1240();
/*     */     
/*  56 */     GlStateManager._glBindFramebuffer(36009, mainBuffer.field_1476);
/*     */     
/*  58 */     mainBuffer.method_1235(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void draw(float radius, Color outlineColor, Color innerColor) {
/*  69 */     class_276 mainBuffer = class_310.method_1551().method_1522();
/*  70 */     OutlineFramebuffer buffer = obtain();
/*     */     
/*  72 */     ((ShaderEffectDuck)Objects.requireNonNull(ShaderManager.OUTLINE_SHADER
/*  73 */         .getShaderEffect())).renderer$addFakeTarget("inp", buffer);
/*     */     
/*  75 */     class_276 out = ShaderManager.OUTLINE_SHADER.getShaderEffect().method_1264("out");
/*     */     
/*  77 */     ShaderManager.OUTLINE_SHADER.setUniformValue("Radius", radius);
/*  78 */     ShaderManager.OUTLINE_SHADER.setUniformValue("OutlineColor", outlineColor.getRed() / 255.0F, outlineColor
/*  79 */         .getGreen() / 255.0F, outlineColor.getBlue() / 255.0F, outlineColor.getAlpha() / 255.0F);
/*  80 */     ShaderManager.OUTLINE_SHADER.setUniformValue("InnerColor", innerColor.getRed() / 255.0F, innerColor
/*  81 */         .getGreen() / 255.0F, innerColor.getBlue() / 255.0F, innerColor.getAlpha() / 255.0F);
/*     */     
/*  83 */     ShaderManager.OUTLINE_SHADER.render(class_310.method_1551().method_1488());
/*     */     
/*  85 */     buffer.method_1230(false);
/*     */     
/*  87 */     mainBuffer.method_1235(false);
/*     */     
/*  89 */     RenderSystem.enableBlend();
/*  90 */     RenderSystem.blendFuncSeparate(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE_MINUS_SRC_ALPHA, GlStateManager.class_4535.ZERO, GlStateManager.class_4534.ONE);
/*     */     
/*  92 */     RenderSystem.backupProjectionMatrix();
/*  93 */     out.method_22594(out.field_1482, out.field_1481, false);
/*  94 */     RenderSystem.restoreProjectionMatrix();
/*  95 */     RenderSystem.defaultBlendFunc();
/*  96 */     RenderSystem.disableBlend();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useAndDraw(Runnable r, float radius, Color outline, Color inner) {
/* 109 */     use(r);
/* 110 */     draw(radius, outline, inner);
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/render/OutlineFramebuffer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */