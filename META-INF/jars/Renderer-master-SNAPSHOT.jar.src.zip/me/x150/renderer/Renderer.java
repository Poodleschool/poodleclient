package me.x150.renderer;

import net.fabricmc.api.ModInitializer;

public class Renderer implements ModInitializer {
  public void onInitialize() {}
}


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/Renderer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */