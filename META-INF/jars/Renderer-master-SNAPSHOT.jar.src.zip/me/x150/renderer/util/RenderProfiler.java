/*    */ package me.x150.renderer.util;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Stack;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenderProfiler
/*    */ {
/* 11 */   static final Stack<Entry> s = new Stack<>();
/* 12 */   static final Map<String, Entry> latestTickTimes = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void begin(String sec) {
/* 20 */     long start = System.nanoTime();
/* 21 */     s.push(new Entry(sec, start, start));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void pop() {
/* 28 */     Entry pop = s.pop();
/* 29 */     latestTickTimes.put(pop.name, new Entry(pop.name, pop.start, System.nanoTime()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Entry[] getAllTickTimes() {
/* 38 */     Entry[] e = new Entry[latestTickTimes.size()];
/* 39 */     String[] ks = (String[])latestTickTimes.keySet().toArray(x$0 -> new String[x$0]);
/* 40 */     for (int i = 0; i < ks.length; i++) {
/* 41 */       e[i] = latestTickTimes.get(ks[i]);
/*    */     }
/* 43 */     latestTickTimes.clear();
/* 44 */     return e;
/*    */   }
/*    */   public static final class Entry extends Record { private final String name; private final long start; private final long end;
/* 47 */     public Entry(String name, long start, long end) { this.name = name; this.start = start; this.end = end; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lme/x150/renderer/util/RenderProfiler$Entry;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #47	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 47 */       //   0	7	0	this	Lme/x150/renderer/util/RenderProfiler$Entry; } public String name() { return this.name; } public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lme/x150/renderer/util/RenderProfiler$Entry;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #47	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lme/x150/renderer/util/RenderProfiler$Entry; } public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lme/x150/renderer/util/RenderProfiler$Entry;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #47	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lme/x150/renderer/util/RenderProfiler$Entry;
/* 47 */       //   0	8	1	o	Ljava/lang/Object; } public long start() { return this.start; } public long end() { return this.end; }
/*    */      }
/*    */ 
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/util/RenderProfiler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */