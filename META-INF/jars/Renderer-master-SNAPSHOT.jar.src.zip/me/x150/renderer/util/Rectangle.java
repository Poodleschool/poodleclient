/*    */ package me.x150.renderer.util;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class Rectangle {
/*    */   private final double x;
/*    */   private final double y;
/*    */   private final double x1;
/*    */   private final double y1;
/*    */   
/*    */   public double getX() {
/* 12 */     return this.x; } public double getY() { return this.y; } public double getX1() { return this.x1; } public double getY1() { return this.y1; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Rectangle(double minX, double minY, double maxX, double maxY) {
/* 23 */     double nx0 = Math.min(minX, maxX);
/* 24 */     double nx1 = Math.max(minX, maxX);
/* 25 */     double ny0 = Math.min(minY, maxY);
/* 26 */     double ny1 = Math.max(minY, maxY);
/* 27 */     this.x = nx0;
/* 28 */     this.y = ny0;
/* 29 */     this.x1 = nx1;
/* 30 */     this.y1 = ny1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean contains(double x, double y) {
/* 41 */     return (x >= this.x && x <= this.x1 && y >= this.y && y <= this.y1);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 46 */     return String.format(Locale.ENGLISH, "%s{x=%f, y=%f, x1=%f, y1=%f}", new Object[] { getClass().getSimpleName(), Double.valueOf(this.x), Double.valueOf(this.y), 
/* 47 */           Double.valueOf(this.x1), Double.valueOf(this.y1) });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean overlaps(Rectangle that) {
/* 57 */     return (this.x1 >= that.x && this.y1 >= that.y && this.x <= that.x1 && this.y <= that.y1);
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/util/Rectangle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */