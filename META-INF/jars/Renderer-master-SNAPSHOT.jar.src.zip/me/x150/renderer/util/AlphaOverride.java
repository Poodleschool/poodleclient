/*    */ package me.x150.renderer.util;
/*    */ 
/*    */ import java.util.Stack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AlphaOverride
/*    */ {
/*  9 */   private static final Stack<Float> alphaMultipliers = new Stack<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void pushAlphaMul(float val) {
/* 17 */     alphaMultipliers.push(Float.valueOf(val));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void popAlphaMul() {
/* 24 */     alphaMultipliers.pop();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static float compute(float initialAlpha) {
/* 34 */     float alpha = initialAlpha;
/* 35 */     for (Float alphaMultiplier : alphaMultipliers) {
/* 36 */       alpha *= alphaMultiplier.floatValue();
/*    */     }
/* 38 */     return alpha;
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/util/AlphaOverride.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */