/*     */ package me.x150.renderer.util;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.Random;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.IntStream;
/*     */ import lombok.NonNull;
/*     */ import net.minecraft.class_1043;
/*     */ import net.minecraft.class_1044;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fc;
/*     */ import org.joml.Vector3f;
/*     */ import org.joml.Vector4f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RendererUtils
/*     */ {
/*     */   @Internal
/*  38 */   public static final Matrix4f lastProjMat = new Matrix4f();
/*     */   @Internal
/*  40 */   public static final Matrix4f lastModMat = new Matrix4f();
/*     */   @Internal
/*  42 */   public static final Matrix4f lastWorldSpaceMatrix = new Matrix4f();
/*     */   
/*  44 */   private static final FastMStack empty = new FastMStack();
/*  45 */   private static final class_310 client = class_310.method_1551();
/*     */   private static final char RND_START = 'a';
/*     */   private static final char RND_END = 'z';
/*  48 */   private static final Random RND = new Random();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setupRender() {
/*  54 */     RenderSystem.disableCull();
/*  55 */     RenderSystem.enableBlend();
/*  56 */     RenderSystem.defaultBlendFunc();
/*  57 */     RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void endRender() {
/*  64 */     RenderSystem.disableBlend();
/*  65 */     RenderSystem.enableCull();
/*  66 */     RenderSystem.depthFunc(515);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int lerp(int from, int to, double delta) {
/*  78 */     return (int)Math.floor(from + (to - from) * class_3532.method_15350(delta, 0.0D, 1.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double lerp(double from, double to, double delta) {
/*  90 */     return from + (to - from) * class_3532.method_15350(delta, 0.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_, _, _ -> new", pure = true)
/*     */   public static Color lerp(@NonNull Color a, @NonNull Color b, double c) {
/* 102 */     if (a == null) throw new NullPointerException("a is marked non-null but is null");  if (b == null) throw new NullPointerException("b is marked non-null but is null"); 
/* 103 */     return new Color(lerp(a.getRed(), b.getRed(), c), lerp(a.getGreen(), b.getGreen(), c), 
/* 104 */         lerp(a.getBlue(), b.getBlue(), c), lerp(a.getAlpha(), b.getAlpha(), c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_, _, _, _, _ -> new", pure = true)
/*     */   public static Color modify(@NonNull Color original, int redOverwrite, int greenOverwrite, int blueOverwrite, int alphaOverwrite) {
/* 119 */     if (original == null) throw new NullPointerException("original is marked non-null but is null"); 
/* 120 */     return new Color(
/* 121 */         (redOverwrite == -1) ? original.getRed() : redOverwrite, 
/* 122 */         (greenOverwrite == -1) ? original.getGreen() : greenOverwrite, 
/* 123 */         (blueOverwrite == -1) ? original.getBlue() : blueOverwrite, 
/* 124 */         (alphaOverwrite == -1) ? original.getAlpha() : alphaOverwrite);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_, _ -> new", pure = true)
/*     */   public static class_243 translateVec3dWithMatrixStack(@NonNull class_4587 stack, @NonNull class_243 in) {
/* 136 */     if (stack == null) throw new NullPointerException("stack is marked non-null but is null");  if (in == null) throw new NullPointerException("in is marked non-null but is null"); 
/* 137 */     Matrix4f matrix = stack.method_23760().method_23761();
/* 138 */     Vector4f vec = new Vector4f((float)in.field_1352, (float)in.field_1351, (float)in.field_1350, 1.0F);
/* 139 */     vec.mul((Matrix4fc)matrix);
/* 140 */     return new class_243(vec.x(), vec.y(), vec.z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerBufferedImageTexture(@NonNull class_2960 i, @NonNull BufferedImage bi) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ifnonnull -> 14
/*     */     //   4: new java/lang/NullPointerException
/*     */     //   7: dup
/*     */     //   8: ldc 'i is marked non-null but is null'
/*     */     //   10: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   13: athrow
/*     */     //   14: aload_1
/*     */     //   15: ifnonnull -> 28
/*     */     //   18: new java/lang/NullPointerException
/*     */     //   21: dup
/*     */     //   22: ldc 'bi is marked non-null but is null'
/*     */     //   24: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   27: athrow
/*     */     //   28: aload_1
/*     */     //   29: invokevirtual getWidth : ()I
/*     */     //   32: istore_2
/*     */     //   33: aload_1
/*     */     //   34: invokevirtual getHeight : ()I
/*     */     //   37: istore_3
/*     */     //   38: new net/minecraft/class_1011
/*     */     //   41: dup
/*     */     //   42: getstatic net/minecraft/class_1011$class_1012.field_4997 : Lnet/minecraft/class_1011$class_1012;
/*     */     //   45: iload_2
/*     */     //   46: iload_3
/*     */     //   47: iconst_0
/*     */     //   48: invokespecial <init> : (Lnet/minecraft/class_1011$class_1012;IIZ)V
/*     */     //   51: astore #4
/*     */     //   53: aload #4
/*     */     //   55: checkcast me/x150/renderer/mixin/NativeImageAccessor
/*     */     //   58: invokeinterface getPointer : ()J
/*     */     //   63: lstore #5
/*     */     //   65: lload #5
/*     */     //   67: aload #4
/*     */     //   69: invokevirtual method_4307 : ()I
/*     */     //   72: aload #4
/*     */     //   74: invokevirtual method_4323 : ()I
/*     */     //   77: imul
/*     */     //   78: invokestatic memIntBuffer : (JI)Ljava/nio/IntBuffer;
/*     */     //   81: astore #7
/*     */     //   83: iconst_0
/*     */     //   84: istore #8
/*     */     //   86: aload_1
/*     */     //   87: invokevirtual getRaster : ()Ljava/awt/image/WritableRaster;
/*     */     //   90: astore #10
/*     */     //   92: aload_1
/*     */     //   93: invokevirtual getColorModel : ()Ljava/awt/image/ColorModel;
/*     */     //   96: astore #11
/*     */     //   98: aload #10
/*     */     //   100: invokevirtual getNumBands : ()I
/*     */     //   103: istore #12
/*     */     //   105: aload #10
/*     */     //   107: invokevirtual getDataBuffer : ()Ljava/awt/image/DataBuffer;
/*     */     //   110: invokevirtual getDataType : ()I
/*     */     //   113: istore #13
/*     */     //   115: iload #13
/*     */     //   117: tableswitch default -> 191, 0 -> 156, 1 -> 163, 2 -> 191, 3 -> 170, 4 -> 177, 5 -> 184
/*     */     //   156: iload #12
/*     */     //   158: newarray byte
/*     */     //   160: goto -> 206
/*     */     //   163: iload #12
/*     */     //   165: newarray short
/*     */     //   167: goto -> 206
/*     */     //   170: iload #12
/*     */     //   172: newarray int
/*     */     //   174: goto -> 206
/*     */     //   177: iload #12
/*     */     //   179: newarray float
/*     */     //   181: goto -> 206
/*     */     //   184: iload #12
/*     */     //   186: newarray double
/*     */     //   188: goto -> 206
/*     */     //   191: new java/lang/IllegalArgumentException
/*     */     //   194: dup
/*     */     //   195: iload #13
/*     */     //   197: <illegal opcode> makeConcatWithConstants : (I)Ljava/lang/String;
/*     */     //   202: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   205: athrow
/*     */     //   206: astore #9
/*     */     //   208: iconst_0
/*     */     //   209: istore #14
/*     */     //   211: iload #14
/*     */     //   213: iload_3
/*     */     //   214: if_icmpge -> 316
/*     */     //   217: iconst_0
/*     */     //   218: istore #15
/*     */     //   220: iload #15
/*     */     //   222: iload_2
/*     */     //   223: if_icmpge -> 310
/*     */     //   226: aload #10
/*     */     //   228: iload #15
/*     */     //   230: iload #14
/*     */     //   232: aload #9
/*     */     //   234: invokevirtual getDataElements : (IILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   237: pop
/*     */     //   238: aload #11
/*     */     //   240: aload #9
/*     */     //   242: invokevirtual getAlpha : (Ljava/lang/Object;)I
/*     */     //   245: istore #16
/*     */     //   247: aload #11
/*     */     //   249: aload #9
/*     */     //   251: invokevirtual getRed : (Ljava/lang/Object;)I
/*     */     //   254: istore #17
/*     */     //   256: aload #11
/*     */     //   258: aload #9
/*     */     //   260: invokevirtual getGreen : (Ljava/lang/Object;)I
/*     */     //   263: istore #18
/*     */     //   265: aload #11
/*     */     //   267: aload #9
/*     */     //   269: invokevirtual getBlue : (Ljava/lang/Object;)I
/*     */     //   272: istore #19
/*     */     //   274: iload #16
/*     */     //   276: bipush #24
/*     */     //   278: ishl
/*     */     //   279: iload #19
/*     */     //   281: bipush #16
/*     */     //   283: ishl
/*     */     //   284: ior
/*     */     //   285: iload #18
/*     */     //   287: bipush #8
/*     */     //   289: ishl
/*     */     //   290: ior
/*     */     //   291: iload #17
/*     */     //   293: ior
/*     */     //   294: istore #20
/*     */     //   296: aload #7
/*     */     //   298: iload #20
/*     */     //   300: invokevirtual put : (I)Ljava/nio/IntBuffer;
/*     */     //   303: pop
/*     */     //   304: iinc #15, 1
/*     */     //   307: goto -> 220
/*     */     //   310: iinc #14, 1
/*     */     //   313: goto -> 211
/*     */     //   316: new net/minecraft/class_1043
/*     */     //   319: dup
/*     */     //   320: aload #4
/*     */     //   322: invokespecial <init> : (Lnet/minecraft/class_1011;)V
/*     */     //   325: astore #14
/*     */     //   327: aload #14
/*     */     //   329: invokevirtual method_4524 : ()V
/*     */     //   332: invokestatic isOnRenderThread : ()Z
/*     */     //   335: ifeq -> 353
/*     */     //   338: invokestatic method_1551 : ()Lnet/minecraft/class_310;
/*     */     //   341: invokevirtual method_1531 : ()Lnet/minecraft/class_1060;
/*     */     //   344: aload_0
/*     */     //   345: aload #14
/*     */     //   347: invokevirtual method_4616 : (Lnet/minecraft/class_2960;Lnet/minecraft/class_1044;)V
/*     */     //   350: goto -> 364
/*     */     //   353: aload_0
/*     */     //   354: aload #14
/*     */     //   356: <illegal opcode> execute : (Lnet/minecraft/class_2960;Lnet/minecraft/class_1043;)Lnet/minecraft/class_4573;
/*     */     //   361: invokestatic recordRenderCall : (Lnet/minecraft/class_4573;)V
/*     */     //   364: goto -> 372
/*     */     //   367: astore_2
/*     */     //   368: aload_2
/*     */     //   369: invokevirtual printStackTrace : ()V
/*     */     //   372: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #151	-> 0
/*     */     //   #156	-> 28
/*     */     //   #157	-> 33
/*     */     //   #158	-> 38
/*     */     //   #159	-> 53
/*     */     //   #160	-> 65
/*     */     //   #161	-> 83
/*     */     //   #163	-> 86
/*     */     //   #164	-> 92
/*     */     //   #165	-> 98
/*     */     //   #166	-> 105
/*     */     //   #167	-> 115
/*     */     //   #168	-> 156
/*     */     //   #169	-> 163
/*     */     //   #170	-> 170
/*     */     //   #171	-> 177
/*     */     //   #172	-> 184
/*     */     //   #173	-> 191
/*     */     //   #177	-> 208
/*     */     //   #178	-> 217
/*     */     //   #179	-> 226
/*     */     //   #180	-> 238
/*     */     //   #181	-> 247
/*     */     //   #182	-> 256
/*     */     //   #183	-> 265
/*     */     //   #184	-> 274
/*     */     //   #185	-> 296
/*     */     //   #178	-> 304
/*     */     //   #177	-> 310
/*     */     //   #188	-> 316
/*     */     //   #189	-> 327
/*     */     //   #190	-> 332
/*     */     //   #191	-> 338
/*     */     //   #193	-> 353
/*     */     //   #197	-> 364
/*     */     //   #195	-> 367
/*     */     //   #196	-> 368
/*     */     //   #198	-> 372
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   247	57	16	a	I
/*     */     //   256	48	17	r	I
/*     */     //   265	39	18	g	I
/*     */     //   274	30	19	b	I
/*     */     //   296	8	20	abgr	I
/*     */     //   220	90	15	x	I
/*     */     //   211	105	14	y	I
/*     */     //   33	331	2	ow	I
/*     */     //   38	326	3	oh	I
/*     */     //   53	311	4	image	Lnet/minecraft/class_1011;
/*     */     //   65	299	5	ptr	J
/*     */     //   83	281	7	backingBuffer	Ljava/nio/IntBuffer;
/*     */     //   86	278	8	off	I
/*     */     //   208	156	9	_d	Ljava/lang/Object;
/*     */     //   92	272	10	_ra	Ljava/awt/image/WritableRaster;
/*     */     //   98	266	11	_cm	Ljava/awt/image/ColorModel;
/*     */     //   105	259	12	nbands	I
/*     */     //   115	249	13	dataType	I
/*     */     //   327	37	14	tex	Lnet/minecraft/class_1043;
/*     */     //   368	4	2	e	Ljava/lang/Throwable;
/*     */     //   0	373	0	i	Lnet/minecraft/class_2960;
/*     */     //   0	373	1	bi	Ljava/awt/image/BufferedImage;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   28	364	367	java/lang/Throwable
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class_4587 getEmptyMatrixStack() {
/* 206 */     if (!empty.method_22911()) {
/* 207 */       throw new IllegalStateException("Supposed \"empty\" stack is not actually empty; someone does not clean up after themselves.");
/*     */     }
/*     */     
/* 210 */     empty.method_34426();
/* 211 */     return empty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract("-> new")
/*     */   public static class_243 getCrosshairVector() {
/* 221 */     class_4184 camera = client.field_1773.method_19418();
/*     */     
/* 223 */     float pi = 3.1415927F;
/* 224 */     float yawRad = (float)Math.toRadians(-camera.method_19330());
/* 225 */     float pitchRad = (float)Math.toRadians(-camera.method_19329());
/* 226 */     float f1 = class_3532.method_15362(yawRad - pi);
/* 227 */     float f2 = class_3532.method_15374(yawRad - pi);
/* 228 */     float f3 = -class_3532.method_15362(pitchRad);
/* 229 */     float f4 = class_3532.method_15374(pitchRad);
/*     */     
/* 231 */     return (new class_243((f2 * f3), f4, (f1 * f3))).method_1019(camera.method_19326());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_ -> new", pure = true)
/*     */   public static class_243 worldSpaceToScreenSpace(@NonNull class_243 pos) {
/* 253 */     if (pos == null) throw new NullPointerException("pos is marked non-null but is null"); 
/* 254 */     class_4184 camera = (client.method_1561()).field_4686;
/* 255 */     int displayHeight = client.method_22683().method_4507();
/* 256 */     int[] viewport = new int[4];
/* 257 */     GL11.glGetIntegerv(2978, viewport);
/* 258 */     Vector3f target = new Vector3f();
/*     */     
/* 260 */     double deltaX = pos.field_1352 - (camera.method_19326()).field_1352;
/* 261 */     double deltaY = pos.field_1351 - (camera.method_19326()).field_1351;
/* 262 */     double deltaZ = pos.field_1350 - (camera.method_19326()).field_1350;
/*     */     
/* 264 */     Vector4f transformedCoordinates = (new Vector4f((float)deltaX, (float)deltaY, (float)deltaZ, 1.0F)).mul((Matrix4fc)lastWorldSpaceMatrix);
/*     */ 
/*     */     
/* 267 */     Matrix4f matrixProj = new Matrix4f((Matrix4fc)lastProjMat);
/* 268 */     Matrix4f matrixModel = new Matrix4f((Matrix4fc)lastModMat);
/*     */     
/* 270 */     matrixProj.mul((Matrix4fc)matrixModel)
/* 271 */       .project(transformedCoordinates.x(), transformedCoordinates.y(), transformedCoordinates.z(), viewport, target);
/*     */ 
/*     */     
/* 274 */     return new class_243(target.x / client.method_22683().method_4495(), (displayHeight - target.y) / client
/* 275 */         .method_22683().method_4495(), target.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean screenSpaceCoordinateIsVisible(class_243 pos) {
/* 285 */     return (pos != null && pos.field_1350 > -1.0D && pos.field_1350 < 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_ -> new", pure = true)
/*     */   public static class_243 screenSpaceToWorldSpace(double x, double y, double d) {
/* 306 */     class_4184 camera = (client.method_1561()).field_4686;
/* 307 */     int displayHeight = client.method_22683().method_4502();
/* 308 */     int displayWidth = client.method_22683().method_4486();
/* 309 */     int[] viewport = new int[4];
/* 310 */     GL11.glGetIntegerv(2978, viewport);
/* 311 */     Vector3f target = new Vector3f();
/*     */     
/* 313 */     Matrix4f matrixProj = new Matrix4f((Matrix4fc)lastProjMat);
/* 314 */     Matrix4f matrixModel = new Matrix4f((Matrix4fc)lastModMat);
/*     */     
/* 316 */     matrixProj.mul((Matrix4fc)matrixModel)
/* 317 */       .mul((Matrix4fc)lastWorldSpaceMatrix)
/* 318 */       .unproject((float)x / displayWidth * viewport[2], (float)(displayHeight - y) / displayHeight * viewport[3], (float)d, viewport, target);
/*     */ 
/*     */     
/* 321 */     return (new class_243(target.x, target.y, target.z)).method_1019(camera.method_19326());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getGuiScale() {
/* 330 */     return (int)class_310.method_1551().method_22683().method_4495();
/*     */   }
/*     */   
/*     */   private static String randomString(int length) {
/* 334 */     return IntStream.range(0, length)
/* 335 */       .<CharSequence>mapToObj(operand -> String.valueOf((char)RND.nextInt(97, 123)))
/* 336 */       .collect(Collectors.joining());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "-> new", pure = true)
/*     */   public static class_2960 randomIdentifier() {
/* 346 */     return new class_2960("renderer", "temp/" + randomString(32));
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/util/RendererUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */