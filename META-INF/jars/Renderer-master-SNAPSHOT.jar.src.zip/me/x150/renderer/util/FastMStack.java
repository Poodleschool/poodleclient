/*     */ package me.x150.renderer.util;
/*     */ 
/*     */ import it.unimi.dsi.fastutil.objects.ObjectArrayList;
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodType;
/*     */ import net.minecraft.class_4587;
/*     */ import org.joml.Matrix3f;
/*     */ import org.joml.Matrix3fc;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fc;
/*     */ import org.joml.Quaternionf;
/*     */ import org.joml.Quaternionfc;
/*     */ 
/*     */ 
/*     */ public class FastMStack
/*     */   extends class_4587
/*     */ {
/*     */   private static final MethodHandle MATRIXSTACK_ENTRY_CTOR;
/*     */   
/*     */   static {
/*     */     try {
/*  23 */       MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(class_4587.class_4665.class, 
/*  24 */           MethodHandles.lookup());
/*  25 */       MATRIXSTACK_ENTRY_CTOR = lookup.findConstructor(class_4587.class_4665.class, 
/*  26 */           MethodType.methodType(void.class, Matrix4f.class, new Class[] { Matrix3f.class }));
/*  27 */     } catch (IllegalAccessException|NoSuchMethodException e) {
/*  28 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*  32 */   private final ObjectArrayList<Entry> fEntries = new ObjectArrayList(8);
/*     */   private Entry top;
/*     */   
/*     */   public FastMStack() {
/*  36 */     this.fEntries.add(this.top = new Entry(new Matrix4f(), new Matrix3f()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_46416(float x, float y, float z) {
/*  41 */     this.top.positionMatrix.translate(x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_22905(float x, float y, float z) {
/*  46 */     this.top.positionMatrix.scale(x, y, z);
/*  47 */     if (x == y && y == z) {
/*     */ 
/*     */       
/*  50 */       if (x != 0.0F) {
/*  51 */         this.top.normalMatrix.scale(Math.signum(x));
/*     */       }
/*     */       return;
/*     */     } 
/*  55 */     float inverseX = 1.0F / x;
/*  56 */     float inverseY = 1.0F / y;
/*  57 */     float inverseZ = 1.0F / z;
/*     */     
/*  59 */     float scalar = (float)(1.0D / Math.cbrt((inverseX * inverseY * inverseZ)));
/*  60 */     this.top.normalMatrix.scale(scalar * inverseX, scalar * inverseY, scalar * inverseZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_22907(Quaternionf quaternion) {
/*  65 */     this.top.positionMatrix.rotate((Quaternionfc)quaternion);
/*  66 */     this.top.normalMatrix.rotate((Quaternionfc)quaternion);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_49278(Quaternionf quaternion, float originX, float originY, float originZ) {
/*  71 */     this.top.positionMatrix.rotateAround((Quaternionfc)quaternion, originX, originY, originZ);
/*  72 */     this.top.normalMatrix.rotate((Quaternionfc)quaternion);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_34425(Matrix4f matrix) {
/*  77 */     this.top.positionMatrix.mul((Matrix4fc)matrix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_22903() {
/*  82 */     this.fEntries.add(this.top = new Entry(new Matrix4f((Matrix4fc)this.top.positionMatrix), new Matrix3f((Matrix3fc)this.top.normalMatrix)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_22909() {
/*  87 */     if (this.fEntries.size() == 1) {
/*  88 */       throw new IllegalStateException("Trying to pop an empty stack");
/*     */     }
/*  90 */     this.fEntries.pop();
/*  91 */     this.top = (Entry)this.fEntries.top();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class_4587.class_4665 method_23760() {
/*     */     try {
/*  98 */       return MATRIXSTACK_ENTRY_CTOR.invoke(this.top.positionMatrix, this.top.normalMatrix);
/*     */     } catch (Throwable $ex) {
/*     */       throw $ex;
/*     */     } 
/*     */   } public boolean method_22911() {
/* 103 */     return (this.fEntries.size() == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_34426() {
/* 108 */     this.top.positionMatrix.identity();
/* 109 */     this.top.normalMatrix.identity();
/*     */   }
/*     */   static final class Entry extends Record { private final Matrix4f positionMatrix; private final Matrix3f normalMatrix;
/* 112 */     Entry(Matrix4f positionMatrix, Matrix3f normalMatrix) { this.positionMatrix = positionMatrix; this.normalMatrix = normalMatrix; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lme/x150/renderer/util/FastMStack$Entry;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #112	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 112 */       //   0	7	0	this	Lme/x150/renderer/util/FastMStack$Entry; } public Matrix4f positionMatrix() { return this.positionMatrix; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lme/x150/renderer/util/FastMStack$Entry;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #112	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lme/x150/renderer/util/FastMStack$Entry; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lme/x150/renderer/util/FastMStack$Entry;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #112	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lme/x150/renderer/util/FastMStack$Entry;
/* 112 */       //   0	8	1	o	Ljava/lang/Object; } public Matrix3f normalMatrix() { return this.normalMatrix; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/util/FastMStack.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */