/*     */ package me.x150.renderer.util;
/*     */ 
/*     */ import com.google.common.base.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Colors
/*     */ {
/*     */   public static int ARGBToInt(int r, int g, int b, int a) {
/*  21 */     Preconditions.checkArgument(validateColorRange(r), "Expected r to be 0-255, received " + r);
/*  22 */     Preconditions.checkArgument(validateColorRange(g), "Expected g to be 0-255, received " + g);
/*  23 */     Preconditions.checkArgument(validateColorRange(b), "Expected b to be 0-255, received " + b);
/*  24 */     Preconditions.checkArgument(validateColorRange(a), "Expected a to be 0-255, received " + a);
/*  25 */     return a << 24 | r << 16 | g << 8 | b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int RGBAToInt(int r, int g, int b, int a) {
/*  39 */     Preconditions.checkArgument(validateColorRange(r), "Expected r to be 0-255, received " + r);
/*  40 */     Preconditions.checkArgument(validateColorRange(g), "Expected g to be 0-255, received " + g);
/*  41 */     Preconditions.checkArgument(validateColorRange(b), "Expected b to be 0-255, received " + b);
/*  42 */     Preconditions.checkArgument(validateColorRange(a), "Expected a to be 0-255, received " + a);
/*  43 */     return r << 24 | g << 16 | b << 8 | a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] RGBAIntToRGBA(int in) {
/*  53 */     int red = in >> 24 & 0xFF;
/*  54 */     int green = in >> 16 & 0xFF;
/*  55 */     int blue = in >> 8 & 0xFF;
/*  56 */     int alpha = in & 0xFF;
/*  57 */     return new int[] { red, green, blue, alpha };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] ARGBIntToRGBA(int in) {
/*  67 */     int alpha = in >> 24 & 0xFF;
/*  68 */     int red = in >> 16 & 0xFF;
/*  69 */     int green = in >> 8 & 0xFF;
/*  70 */     int blue = in & 0xFF;
/*  71 */     return new int[] { red, green, blue, alpha };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] RGBIntToRGB(int in) {
/*  81 */     int red = in >> 16 & 0xFF;
/*  82 */     int green = in >> 8 & 0xFF;
/*  83 */     int blue = in & 0xFF;
/*  84 */     return new int[] { red, green, blue };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float[] intArrayToFloatArray(int[] in) {
/*  93 */     Preconditions.checkArgument((in.length == 4), "Expected int[] of size 4, got " + in.length);
/*  94 */     for (int i = 0; i < in.length; i++) {
/*  95 */       Preconditions.checkArgument(validateColorRange(in[i]), "Expected in[" + i + "] to be 0-255, got " + in[i]);
/*     */     }
/*  97 */     return new float[] { in[0] / 255.0F, in[1] / 255.0F, in[2] / 255.0F, in[3] / 255.0F };
/*     */   }
/*     */   
/*     */   private static boolean validateColorRange(int in) {
/* 101 */     return (in >= 0 && in <= 255);
/*     */   }
/*     */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/util/Colors.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */