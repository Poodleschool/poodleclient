/*    */ package me.x150.renderer.util;
/*    */ 
/*    */ import com.google.common.base.Preconditions;
/*    */ import net.minecraft.class_286;
/*    */ import net.minecraft.class_287;
/*    */ import net.minecraft.class_291;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BufferUtils
/*    */ {
/*    */   public static void draw(class_287 builder) {
/* 16 */     class_286.method_43433(builder.method_1326());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class_291 createVbo(class_287.class_7433 builder, class_291.class_8555 expectedUsage) {
/* 27 */     class_291 buffer = new class_291(expectedUsage);
/* 28 */     buffer.method_1353();
/* 29 */     buffer.method_1352(builder);
/* 30 */     class_291.method_1354();
/* 31 */     return buffer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void uploadToVbo(class_287.class_7433 builder, class_291 buffer) {
/* 41 */     Preconditions.checkArgument(!buffer.method_43444(), "VBO is closed");
/* 42 */     buffer.method_1353();
/* 43 */     buffer.method_1352(builder);
/* 44 */     class_291.method_1354();
/*    */   }
/*    */ }


/* Location:              /Users/iangoss/Downloads/navine-3.2.8.jar!/META-INF/jars/Renderer-master-SNAPSHOT.jar!/me/x150/renderer/util/BufferUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */